import{c8 as t}from"./index-ef304653.js";const e=t(!0);export{e as N};
