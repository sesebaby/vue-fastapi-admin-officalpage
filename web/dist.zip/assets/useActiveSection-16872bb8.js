import{k as p,aw as c,a2 as s,l as r,d as f,u as b,a as h,aK as x,e as _,n as C,j as d,F as w,H as $}from"./index-02bf86a2.js";const z=p("divider",`
 position: relative;
 display: flex;
 width: 100%;
 box-sizing: border-box;
 font-size: 16px;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
`,[c("vertical",`
 margin-top: 24px;
 margin-bottom: 24px;
 `,[c("no-title",`
 display: flex;
 align-items: center;
 `)]),s("title",`
 display: flex;
 align-items: center;
 margin-left: 12px;
 margin-right: 12px;
 white-space: nowrap;
 font-weight: var(--n-font-weight);
 `),r("title-position-left",[s("line",[r("left",{width:"28px"})])]),r("title-position-right",[s("line",[r("right",{width:"28px"})])]),r("dashed",[s("line",`
 background-color: #0000;
 height: 0px;
 width: 100%;
 border-style: dashed;
 border-width: 1px 0 0;
 `)]),r("vertical",`
 display: inline-block;
 height: 1em;
 margin: 0 8px;
 vertical-align: middle;
 width: 1px;
 `),s("line",`
 border: none;
 transition: background-color .3s var(--n-bezier), border-color .3s var(--n-bezier);
 height: 1px;
 width: 100%;
 margin: 0;
 `),c("dashed",[s("line",{backgroundColor:"var(--n-color)"})]),r("dashed",[s("line",{borderColor:"var(--n-color)"})]),r("vertical",{backgroundColor:"var(--n-color)"})]),y=Object.assign(Object.assign({},h.props),{titlePlacement:{type:String,default:"center"},dashed:Boolean,vertical:Boolean}),P=f({name:"Divider",props:y,setup(t){const{mergedClsPrefixRef:o,inlineThemeDisabled:i}=b(t),l=h("Divider","-divider",z,x,t,o),a=_(()=>{const{common:{cubicBezierEaseInOut:e},self:{color:g,textColor:u,fontWeight:m}}=l.value;return{"--n-bezier":e,"--n-color":g,"--n-text-color":u,"--n-font-weight":m}}),n=i?C("divider",void 0,a,t):void 0;return{mergedClsPrefix:o,cssVars:i?void 0:a,themeClass:n==null?void 0:n.themeClass,onRender:n==null?void 0:n.onRender}},render(){var t;const{$slots:o,titlePlacement:i,vertical:l,dashed:a,cssVars:n,mergedClsPrefix:e}=this;return(t=this.onRender)===null||t===void 0||t.call(this),d("div",{role:"separator",class:[`${e}-divider`,this.themeClass,{[`${e}-divider--vertical`]:l,[`${e}-divider--no-title`]:!o.default,[`${e}-divider--dashed`]:a,[`${e}-divider--title-position-${i}`]:o.default&&i}],style:n},l?null:d("div",{class:`${e}-divider__line ${e}-divider__line--left`}),!l&&o.default?d(w,null,d("div",{class:`${e}-divider__title`},this.$slots),d("div",{class:`${e}-divider__line ${e}-divider__line--right`})):null)}}),v=$("home");function R(){return{activeSection:v,setActiveSection:i=>{typeof i=="string"&&i&&(v.value=i)},getActiveSection:()=>v.value}}export{P as _,R as u};
