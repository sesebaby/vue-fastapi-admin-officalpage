import{c7 as t}from"./index-e0ea051e.js";const e=t(!0);export{e as N};
