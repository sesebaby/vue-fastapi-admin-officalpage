var M=(e,o,n)=>new Promise((t,s)=>{var i=a=>{try{l(n.next(a))}catch(c){s(c)}},g=a=>{try{l(n.throw(a))}catch(c){s(c)}},l=a=>a.done?t(a.value):Promise.resolve(a.value).then(i,g);l((n=n.apply(e,o)).next())});import{aL as ie,$ as z,k as f,l as $,d as j,e as S,aM as N,j as r,ax as U,aN as Z,aO as Q,aP as ee,aQ as te,u as T,a as P,aR as ne,f as O,n as H,at as se,aS as q,aT as oe,aU as ae,F as A,aV as le,aW as ce,aX as re,G as D,a6 as de,aY as ge,ap as ue,aA as pe,_ as he,aZ as fe,o as me,q as x,y as _,s as b,E as G,B as X,aH as Y,w as E,x as V,z as F}from"./index-e0ea051e.js";import{N as ye}from"./Space-ef9ee132.js";let K=!1;function ve(){if(ie&&window.CSS&&!K&&(K=!0,"registerProperty"in(window==null?void 0:window.CSS)))try{CSS.registerProperty({name:"--n-color-start",syntax:"<color>",inherits:!1,initialValue:"#0000"}),CSS.registerProperty({name:"--n-color-end",syntax:"<color>",inherits:!1,initialValue:"#0000"})}catch(e){}}const be=z([f("progress",{display:"inline-block"},[f("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),$("line",`
 width: 100%;
 display: block;
 `,[f("progress-content",`
 display: flex;
 align-items: center;
 `,[f("progress-graph",{flex:1})]),f("progress-custom-content",{marginLeft:"14px"}),f("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[$("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),$("circle, dashboard",{width:"120px"},[f("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),f("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),f("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),$("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[f("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),f("progress-content",{position:"relative"}),f("progress-graph",{position:"relative"},[f("progress-graph-circle",[z("svg",{verticalAlign:"bottom"}),f("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[$("empty",{opacity:0})]),f("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),f("progress-graph-line",[$("indicator-inside",[f("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[f("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),f("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),$("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[f("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),f("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),f("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[f("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[$("processing",[z("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),z("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),xe={success:r(Z,null),error:r(Q,null),warning:r(ee,null),info:r(te,null)},_e=j({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:o}){const n=S(()=>N(e.height)),t=S(()=>e.railBorderRadius!==void 0?N(e.railBorderRadius):e.height!==void 0?N(e.height,{c:.5}):""),s=S(()=>e.fillBorderRadius!==void 0?N(e.fillBorderRadius):e.railBorderRadius!==void 0?N(e.railBorderRadius):e.height!==void 0?N(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:i,railColor:g,railStyle:l,percentage:a,unit:c,indicatorTextColor:p,status:h,showIndicator:m,fillColor:d,processing:v,clsPrefix:u}=e;return r("div",{class:`${u}-progress-content`,role:"none"},r("div",{class:`${u}-progress-graph`,"aria-hidden":!0},r("div",{class:[`${u}-progress-graph-line`,{[`${u}-progress-graph-line--indicator-${i}`]:!0}]},r("div",{class:`${u}-progress-graph-line-rail`,style:[{backgroundColor:g,height:n.value,borderRadius:t.value},l]},r("div",{class:[`${u}-progress-graph-line-fill`,v&&`${u}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:d,height:n.value,lineHeight:n.value,borderRadius:s.value}},i==="inside"?r("div",{class:`${u}-progress-graph-line-indicator`,style:{color:p}},o.default?o.default():`${a}${c}`):null)))),m&&i==="outside"?r("div",null,o.default?r("div",{class:`${u}-progress-custom-content`,style:{color:p},role:"none"},o.default()):h==="default"?r("div",{role:"none",class:`${u}-progress-icon ${u}-progress-icon--as-text`,style:{color:p}},a,c):r("div",{class:`${u}-progress-icon`,"aria-hidden":!0},r(U,{clsPrefix:u},{default:()=>xe[h]}))):null)}}}),Se={success:r(Z,null),error:r(Q,null),warning:r(ee,null),info:r(te,null)},ke=j({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:o}){function n(t,s,i){const{gapDegree:g,viewBoxWidth:l,strokeWidth:a}=e,c=50,p=0,h=c,m=0,d=2*c,v=50+a/2,u=`M ${v},${v} m ${p},${h}
      a ${c},${c} 0 1 1 ${m},${-d}
      a ${c},${c} 0 1 1 ${-m},${d}`,k=Math.PI*2*c,w={stroke:i,strokeDasharray:`${t/100*(k-g)}px ${l*8}px`,strokeDashoffset:`-${g/2}px`,transformOrigin:s?"center":void 0,transform:s?`rotate(${s}deg)`:void 0};return{pathString:u,pathStyle:w}}return()=>{const{fillColor:t,railColor:s,strokeWidth:i,offsetDegree:g,status:l,percentage:a,showIndicator:c,indicatorTextColor:p,unit:h,gapOffsetDegree:m,clsPrefix:d}=e,{pathString:v,pathStyle:u}=n(100,0,s),{pathString:k,pathStyle:w}=n(a,g,t),y=100+i;return r("div",{class:`${d}-progress-content`,role:"none"},r("div",{class:`${d}-progress-graph`,"aria-hidden":!0},r("div",{class:`${d}-progress-graph-circle`,style:{transform:m?`rotate(${m}deg)`:void 0}},r("svg",{viewBox:`0 0 ${y} ${y}`},r("g",null,r("path",{class:`${d}-progress-graph-circle-rail`,d:v,"stroke-width":i,"stroke-linecap":"round",fill:"none",style:u})),r("g",null,r("path",{class:[`${d}-progress-graph-circle-fill`,a===0&&`${d}-progress-graph-circle-fill--empty`],d:k,"stroke-width":i,"stroke-linecap":"round",fill:"none",style:w}))))),c?r("div",null,o.default?r("div",{class:`${d}-progress-custom-content`,role:"none"},o.default()):l!=="default"?r("div",{class:`${d}-progress-icon`,"aria-hidden":!0},r(U,{clsPrefix:d},{default:()=>Se[l]})):r("div",{class:`${d}-progress-text`,style:{color:p},role:"none"},r("span",{class:`${d}-progress-text__percentage`},a),r("span",{class:`${d}-progress-text__unit`},h))):null)}}});function J(e,o,n=100){return`m ${n/2} ${n/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const we=j({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:o}){const n=S(()=>e.percentage.map((s,i)=>`${Math.PI*s/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*i)-e.circleGap*i)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:t,strokeWidth:s,circleGap:i,showIndicator:g,fillColor:l,railColor:a,railStyle:c,percentage:p,clsPrefix:h}=e;return r("div",{class:`${h}-progress-content`,role:"none"},r("div",{class:`${h}-progress-graph`,"aria-hidden":!0},r("div",{class:`${h}-progress-graph-circle`},r("svg",{viewBox:`0 0 ${t} ${t}`},p.map((m,d)=>r("g",{key:d},r("path",{class:`${h}-progress-graph-circle-rail`,d:J(t/2-s/2*(1+2*d)-i*d,s,t),"stroke-width":s,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:a[d]},c[d]]}),r("path",{class:[`${h}-progress-graph-circle-fill`,m===0&&`${h}-progress-graph-circle-fill--empty`],d:J(t/2-s/2*(1+2*d)-i*d,s,t),"stroke-width":s,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:n.value[d],strokeDashoffset:0,stroke:l[d]}})))))),g&&o.default?r("div",null,r("div",{class:`${h}-progress-text`},o.default())):null)}}}),$e=Object.assign(Object.assign({},P.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),Ce=j({name:"Progress",props:$e,setup(e){const o=S(()=>e.indicatorPlacement||e.indicatorPosition),n=S(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:t,inlineThemeDisabled:s}=T(e),i=P("Progress","-progress",be,ne,e,t),g=S(()=>{const{status:a}=e,{common:{cubicBezierEaseInOut:c},self:{fontSize:p,fontSizeCircle:h,railColor:m,railHeight:d,iconSizeCircle:v,iconSizeLine:u,textColorCircle:k,textColorLineInner:w,textColorLineOuter:y,lineBgProcessing:C,fontWeightCircle:B,[O("iconColor",a)]:R,[O("fillColor",a)]:I}}=i.value;return{"--n-bezier":c,"--n-fill-color":I,"--n-font-size":p,"--n-font-size-circle":h,"--n-font-weight-circle":B,"--n-icon-color":R,"--n-icon-size-circle":v,"--n-icon-size-line":u,"--n-line-bg-processing":C,"--n-rail-color":m,"--n-rail-height":d,"--n-text-color-circle":k,"--n-text-color-line-inner":w,"--n-text-color-line-outer":y}}),l=s?H("progress",S(()=>e.status[0]),g,e):void 0;return{mergedClsPrefix:t,mergedIndicatorPlacement:o,gapDeg:n,cssVars:s?void 0:g,themeClass:l==null?void 0:l.themeClass,onRender:l==null?void 0:l.onRender}},render(){const{type:e,cssVars:o,indicatorTextColor:n,showIndicator:t,status:s,railColor:i,railStyle:g,color:l,percentage:a,viewBoxWidth:c,strokeWidth:p,mergedIndicatorPlacement:h,unit:m,borderRadius:d,fillBorderRadius:v,height:u,processing:k,circleGap:w,mergedClsPrefix:y,gapDeg:C,gapOffsetDegree:B,themeClass:R,$slots:I,onRender:L}=this;return L==null||L(),r("div",{class:[R,`${y}-progress`,`${y}-progress--${e}`,`${y}-progress--${s}`],style:o,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":a,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?r(ke,{clsPrefix:y,status:s,showIndicator:t,indicatorTextColor:n,railColor:i,fillColor:l,railStyle:g,offsetDegree:this.offsetDegree,percentage:a,viewBoxWidth:c,strokeWidth:p,gapDegree:C===void 0?e==="dashboard"?75:0:C,gapOffsetDegree:B,unit:m},I):e==="line"?r(_e,{clsPrefix:y,status:s,showIndicator:t,indicatorTextColor:n,railColor:i,fillColor:l,railStyle:g,percentage:a,processing:k,indicatorPlacement:h,unit:m,fillBorderRadius:v,railBorderRadius:d,height:u},I):e==="multiple-circle"?r(we,{clsPrefix:y,strokeWidth:p,railColor:i,fillColor:l,railStyle:g,viewBoxWidth:c,percentage:a,showIndicator:t,circleGap:w},I):null)}});function ze(e){const{heightSmall:o,heightMedium:n,heightLarge:t,borderRadius:s}=e;return{color:"#eee",colorEnd:"#ddd",borderRadius:s,heightSmall:o,heightMedium:n,heightLarge:t}}const Pe={name:"Skeleton",common:se,self:ze},Be=z([f("skeleton",`
 height: 1em;
 width: 100%;
 transition:
 --n-color-start .3s var(--n-bezier),
 --n-color-end .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 animation: 2s skeleton-loading infinite cubic-bezier(0.36, 0, 0.64, 1);
 background-color: var(--n-color-start);
 `),z("@keyframes skeleton-loading",`
 0% {
 background: var(--n-color-start);
 }
 40% {
 background: var(--n-color-end);
 }
 80% {
 background: var(--n-color-start);
 }
 100% {
 background: var(--n-color-start);
 }
 `)]),Re=Object.assign(Object.assign({},P.props),{text:Boolean,round:Boolean,circle:Boolean,height:[String,Number],width:[String,Number],size:String,repeat:{type:Number,default:1},animated:{type:Boolean,default:!0},sharp:{type:Boolean,default:!0}}),je=j({name:"Skeleton",inheritAttrs:!1,props:Re,setup(e){ve();const{mergedClsPrefixRef:o}=T(e),n=P("Skeleton","-skeleton",Be,Pe,e,o);return{mergedClsPrefix:o,style:S(()=>{var t,s;const i=n.value,{common:{cubicBezierEaseInOut:g}}=i,l=i.self,{color:a,colorEnd:c,borderRadius:p}=l;let h;const{circle:m,sharp:d,round:v,width:u,height:k,size:w,text:y,animated:C}=e;w!==void 0&&(h=l[O("height",w)]);const B=m?(t=u!=null?u:k)!==null&&t!==void 0?t:h:u,R=(s=m&&u!=null?u:k)!==null&&s!==void 0?s:h;return{display:y?"inline-block":"",verticalAlign:y?"-0.125em":"",borderRadius:m?"50%":v?"4096px":d?"":p,width:typeof B=="number"?q(B):B,height:typeof R=="number"?q(R):R,animation:C?"":"none","--n-bezier":g,"--n-color-start":a,"--n-color-end":c}})}},render(){const{repeat:e,style:o,mergedClsPrefix:n,$attrs:t}=this,s=r("div",oe({class:`${n}-skeleton`,style:o},t));return e>1?r(A,null,ae(e,null).map(i=>[s,`
`])):s}}),Ne=z([z("@keyframes spin-rotate",`
 from {
 transform: rotate(0);
 }
 to {
 transform: rotate(360deg);
 }
 `),f("spin-container",`
 position: relative;
 `,[f("spin-body",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[le()])]),f("spin-body",`
 display: inline-flex;
 align-items: center;
 justify-content: center;
 flex-direction: column;
 `),f("spin",`
 display: inline-flex;
 height: var(--n-size);
 width: var(--n-size);
 font-size: var(--n-size);
 color: var(--n-color);
 `,[$("rotate",`
 animation: spin-rotate 2s linear infinite;
 `)]),f("spin-description",`
 display: inline-block;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 margin-top: 8px;
 `),f("spin-content",`
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 pointer-events: all;
 `,[$("spinning",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: none;
 opacity: var(--n-opacity-spinning);
 `)])]),Ie={small:20,medium:18,large:16},De=Object.assign(Object.assign({},P.props),{contentClass:String,contentStyle:[Object,String],description:String,stroke:String,size:{type:[String,Number],default:"medium"},show:{type:Boolean,default:!0},strokeWidth:Number,rotate:{type:Boolean,default:!0},spinning:{type:Boolean,validator:()=>!0,default:void 0},delay:Number}),Oe=j({name:"Spin",props:De,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:n}=T(e),t=P("Spin","-spin",Ne,ce,e,o),s=S(()=>{const{size:a}=e,{common:{cubicBezierEaseInOut:c},self:p}=t.value,{opacitySpinning:h,color:m,textColor:d}=p,v=typeof a=="number"?q(a):p[O("size",a)];return{"--n-bezier":c,"--n-opacity-spinning":h,"--n-size":v,"--n-color":m,"--n-text-color":d}}),i=n?H("spin",S(()=>{const{size:a}=e;return typeof a=="number"?String(a):a[0]}),s,e):void 0,g=re(e,["spinning","show"]),l=D(!1);return de(a=>{let c;if(g.value){const{delay:p}=e;if(p){c=window.setTimeout(()=>{l.value=!0},p),a(()=>{clearTimeout(c)});return}}l.value=g.value}),{mergedClsPrefix:o,active:l,mergedStrokeWidth:S(()=>{const{strokeWidth:a}=e;if(a!==void 0)return a;const{size:c}=e;return Ie[typeof c=="number"?"medium":c]}),cssVars:n?void 0:s,themeClass:i==null?void 0:i.themeClass,onRender:i==null?void 0:i.onRender}},render(){var e,o;const{$slots:n,mergedClsPrefix:t,description:s}=this,i=n.icon&&this.rotate,g=(s||n.description)&&r("div",{class:`${t}-spin-description`},s||((e=n.description)===null||e===void 0?void 0:e.call(n))),l=n.icon?r("div",{class:[`${t}-spin-body`,this.themeClass]},r("div",{class:[`${t}-spin`,i&&`${t}-spin--rotate`],style:n.default?"":this.cssVars},n.icon()),g):r("div",{class:[`${t}-spin-body`,this.themeClass]},r(ge,{clsPrefix:t,style:n.default?"":this.cssVars,stroke:this.stroke,"stroke-width":this.mergedStrokeWidth,class:`${t}-spin`}),g);return(o=this.onRender)===null||o===void 0||o.call(this),n.default?r("div",{class:[`${t}-spin-container`,this.themeClass],style:this.cssVars},r("div",{class:[`${t}-spin-content`,this.active&&`${t}-spin-content--spinning`,this.contentClass],style:this.contentStyle},n),r(ue,{name:"fade-in-transition"},{default:()=>this.active?l:null})):l}}),We=f("text",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
`,[$("strong",`
 font-weight: var(--n-font-weight-strong);
 `),$("italic",{fontStyle:"italic"}),$("underline",{textDecoration:"underline"}),$("code",`
 line-height: 1.4;
 display: inline-block;
 font-family: var(--n-font-famliy-mono);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 box-sizing: border-box;
 padding: .05em .35em 0 .35em;
 border-radius: var(--n-code-border-radius);
 font-size: .9em;
 color: var(--n-code-text-color);
 background-color: var(--n-code-color);
 border: var(--n-code-border);
 `)]),Te=Object.assign(Object.assign({},P.props),{code:Boolean,type:{type:String,default:"default"},delete:Boolean,strong:Boolean,italic:Boolean,underline:Boolean,depth:[String,Number],tag:String,as:{type:String,validator:()=>!0,default:void 0}}),it=j({name:"Text",props:Te,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:n}=T(e),t=P("Typography","-text",We,pe,e,o),s=S(()=>{const{depth:g,type:l}=e,a=l==="default"?g===void 0?"textColor":`textColor${g}Depth`:O("textColor",l),{common:{fontWeightStrong:c,fontFamilyMono:p,cubicBezierEaseInOut:h},self:{codeTextColor:m,codeBorderRadius:d,codeColor:v,codeBorder:u,[a]:k}}=t.value;return{"--n-bezier":h,"--n-text-color":k,"--n-font-weight-strong":c,"--n-font-famliy-mono":p,"--n-code-border-radius":d,"--n-code-text-color":m,"--n-code-color":v,"--n-code-border":u}}),i=n?H("text",S(()=>`${e.type[0]}${e.depth||""}`),s,e):void 0;return{mergedClsPrefix:o,compitableTag:re(e,["as","tag"]),cssVars:n?void 0:s,themeClass:i==null?void 0:i.themeClass,onRender:i==null?void 0:i.onRender}},render(){var e,o,n;const{mergedClsPrefix:t}=this;(e=this.onRender)===null||e===void 0||e.call(this);const s=[`${t}-text`,this.themeClass,{[`${t}-text--code`]:this.code,[`${t}-text--delete`]:this.delete,[`${t}-text--strong`]:this.strong,[`${t}-text--italic`]:this.italic,[`${t}-text--underline`]:this.underline}],i=(n=(o=this.$slots).default)===null||n===void 0?void 0:n.call(o);return this.code?r("code",{class:s,style:this.cssVars},this.delete?r("del",null,i):i):this.delete?r("del",{class:s,style:this.cssVars},i):r(this.compitableTag||"span",{class:s,style:this.cssVars},i)}}),W={news:"/images/business_office_scene.jpg",avatar:"/images/business_office_scene.jpg",logo:"/images/ISO9001质量管理体系认证证书.png",business:"/images/business_office_scene.jpg",technology:"/images/icon_advanced_packaging.jpg",case:"/images/product_development_cycle_chart.jpg",certificate:"/images/ISO9001质量管理体系认证证书.png"},Le={hero:{company_hero:"/images/hero_pictore_company.png",tech_background:"/images/科技背景图片.jpg",third_slide:"/images/company_scene_02.jpg",fourth_slide:"/images/company_scene_03.jpg",tech_concept:"/images/商务科技概念图.png",circuit_background:"/images/科技电路背景图.png",business_office:"/images/business_office_scene.jpg"},about:{office_scene:"/images/company_scene_01.jpg",team_photo:"/images/company_scene_05.jpg",company_culture:"/images/company_scene_06.jpg"},business:{advanced_packaging:"/images/company_scene_07.jpg",hardware_solution:"/images/company_scene_08.jpg",testing_service:"/images/company_scene_09.jpg",production_line:"/images/company_scene_10.jpg"},technology:{lab_equipment:"/images/business_office_scene.jpg",pcb_design:"/images/company_scene_12.jpg",testing_facility:"/images/icon_hardware_design.png",advanced_tech:"/images/technical_chart_circuit.jpg"},cases:{automotive:"/images/company_scene_07.jpg",consumer:"/images/company_scene_08.jpg",industrial:"/images/company_scene_09.jpg",communication:"/images/company_scene_10.jpg"},news:{news_4:"/images/news/第四届全国辐射探测微电子学术年会.png",news_1:"/images/iso_certification_news.png",news_2:"/images/company_scene_05.jpg",news_3:"/images/ICEPT2024.png",company_event:"/images/company_scene_11.jpg"},certificates:{iso9001:"/images/ISO9001质量管理体系认证证书.png",military:"/images/武器装备质量管理体系证书.png"},customers:{avatar_1:"/images/business_office_scene.jpg",avatar_2:"/images/modern_buildings_night_scene.jpg",avatar_3:"/images/product_development_cycle_chart.jpg",avatar_4:"/images/ISO9001质量管理体系认证证书.png"},partners:{sjtu:"/images/partner_sjtu.png",zju:"/images/partner_zju.png",fzu:"/images/partner_fzu.png",xidian:"/images/partner_xidian.png",ihep_cas:"/images/partner_ihep_cas.png",norinco:"/images/partner_norinco.jpg",cetc:"/images/partner_cetc.png",casc:"/images/partner_casc.png"},partnerLogos:{sjtu:"/images/logo_sjtu.png",zju:"/images/logo_zju.png",fzu:"/images/logo_fzu.png",xidian:"/images/logo_xidian.png",ihep_cas:"/images/logo_ihep_cas.png",norinco:"/images/logo_norinco.png",cetc:"/images/logo_cetc.png",casc:"/images/logo_casc.png"}};function nt(e,o,n="business"){try{const t=Le[e];return t&&t[o]?t[o]:W[n]||W.business}catch(t){return console.warn(`图片资源获取失败: ${e}.${o}`,t),W[n]||W.business}}function st(e,o={}){const{immediate:n=!1,resetOnExecute:t=!0,shallow:s=!0,delay:i=0,onError:g=null,onSuccess:l=null}=o,a=D(!1),c=D(!1),p=D(null),h=D(null),m=S(()=>c.value&&!p.value),d=S(()=>!!p.value),v=(...w)=>M(this,null,function*(){t&&(h.value=null,p.value=null),a.value=!0,c.value=!1;try{i>0&&(yield new Promise(C=>setTimeout(C,i)));const y=yield e(...w);return h.value=s?y:JSON.parse(JSON.stringify(y)),l&&l(y),y}catch(y){throw p.value=y,g&&g(y),y}finally{a.value=!1,c.value=!0}}),u=(...w)=>v(...w),k=()=>{a.value=!1,c.value=!1,p.value=null,h.value=null};return n&&v(),{isLoading:a,isFinished:c,isReady:m,hasError:d,error:p,data:h,execute:v,retry:u,reset:k}}const Ee={class:"loading-state"},Ve={key:0,class:"skeleton-container"},qe={key:0,class:"skeleton-card"},Ae={key:1,class:"skeleton-list"},He={style:{flex:"1"}},Me={key:2,class:"skeleton-article"},Ge={key:3,class:"skeleton-grid"},Xe={key:4,class:"skeleton-custom"},Ye={key:1,class:"spinner-container"},Fe={key:0,class:"loading-message"},Ke={key:2,class:"progress-container"},Je={key:0,class:"loading-message"},Ue={key:3,class:"custom-container"},Ze={class:"loading-message"},Qe={__name:"LoadingState",props:{type:{type:String,default:"skeleton",validator:e=>["skeleton","spinner","progress","custom"].includes(e)},variant:{type:String,default:"card",validator:e=>["card","list","article","grid","custom"].includes(e)},message:{type:String,default:""},spinnerSize:{type:String,default:"medium",validator:e=>["small","medium","large"].includes(e)},percentage:{type:Number,default:0,validator:e=>e>=0&&e<=100},showPercentage:{type:Boolean,default:!0},progressStatus:{type:String,default:"default",validator:e=>["default","success","error","warning"].includes(e)},rows:{type:Number,default:3},gridItems:{type:Number,default:6},minHeight:{type:String,default:"200px"}},setup(e){return fe(o=>({c03881ba:e.minHeight})),me(),(o,n)=>{const t=je,s=Oe,i=ye,g=Ce;return x(),_("div",Ee,[e.type==="skeleton"?(x(),_("div",Ve,[e.variant==="card"?(x(),_("div",qe,[b(t,{height:"200px",style:{"margin-bottom":"16px"}}),b(t,{text:"",repeat:3}),b(t,{text:"",style:{width:"60%","margin-top":"8px"}})])):e.variant==="list"?(x(),_("div",Ae,[(x(!0),_(A,null,G(e.rows,l=>(x(),_("div",{key:l,class:"skeleton-list-item"},[b(t,{circle:"",size:"medium",style:{"margin-right":"16px"}}),X("div",He,[b(t,{text:"",style:{width:"80%","margin-bottom":"8px"}}),b(t,{text:"",style:{width:"60%"}})])]))),128))])):e.variant==="article"?(x(),_("div",Me,[b(t,{text:"",style:{width:"80%",height:"32px","margin-bottom":"16px"}}),b(t,{text:"",style:{width:"60%","margin-bottom":"24px"}}),b(t,{height:"200px",style:{"margin-bottom":"16px"}}),b(t,{text:"",repeat:4})])):e.variant==="grid"?(x(),_("div",Ge,[(x(!0),_(A,null,G(e.gridItems,l=>(x(),_("div",{key:l,class:"skeleton-grid-item"},[b(t,{height:"150px",style:{"margin-bottom":"12px"}}),b(t,{text:"",style:{"margin-bottom":"8px"}}),b(t,{text:"",style:{width:"70%"}})]))),128))])):(x(),_("div",Xe,[Y(o.$slots,"skeleton",{},()=>[b(t,{text:"",repeat:3})],!0)]))])):e.type==="spinner"?(x(),_("div",Ye,[b(i,{vertical:"",align:"center",size:20},{default:E(()=>[b(s,{size:e.spinnerSize},null,8,["size"]),e.message?(x(),_("div",Fe,V(e.message),1)):F("",!0)]),_:1})])):e.type==="progress"?(x(),_("div",Ke,[b(i,{vertical:"",size:16},{default:E(()=>[e.message?(x(),_("div",Je,V(e.message),1)):F("",!0),b(g,{type:"line",percentage:e.percentage,"show-indicator":e.showPercentage,status:e.progressStatus},null,8,["percentage","show-indicator","status"])]),_:1})])):(x(),_("div",Ue,[Y(o.$slots,"loading",{},()=>[b(i,{vertical:"",align:"center",size:20},{default:E(()=>[b(s,{size:"large"}),X("div",Ze,V(e.message||o.$t("common.loading")),1)]),_:1})],!0)]))])}}},ot=he(Qe,[["__scopeId","data-v-ab2492bf"]]);export{ot as L,W as P,it as _,Oe as a,Ce as b,nt as g,st as u};
