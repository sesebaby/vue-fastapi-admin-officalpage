import{c8 as t}from"./index-02bf86a2.js";const e=t(!0);export{e as N};
