import{an as L,bK as Be,e as $,E as T,V as ne,d as G,a1 as Q,bL as K,u as J,b as Ee,a5 as ke,a6 as Ne,bx as _e,bM as Me,am as Y,j as v,bN as Te,ao as oe,aG as q,bq as ie,ab as j,bO as Oe,bP as De,bQ as Ie,Z as u,bR as X,k as E,l as O,a0 as F,aI as Fe,b5 as Pe,a as se,ag as Z,ah as U,av as ee,bS as He,n as Ae,b7 as je,b6 as Ge,bT as We,bU as Le,aE as I,ac as Ue,bV as Xe,X as Ve,bW as Ye,aF as H,bI as W,J as qe,Q as Qe,a9 as Ke,W as Je,i as Ze,aa as te}from"./index-ef304653.js";import{g as et}from"./Space-40270cc1.js";function tt(e){if(typeof e=="number")return{"":e.toString()};const t={};return e.split(/ +/).forEach(r=>{if(r==="")return;const[o,n]=r.split(":");n===void 0?t[""]=o:t[o]=n}),t}function P(e,t){var r;if(e==null)return;const o=tt(e);if(t===void 0)return o[""];if(typeof t=="string")return(r=o[t])!==null&&r!==void 0?r:o[""];if(Array.isArray(t)){for(let n=t.length-1;n>=0;--n){const a=t[n];if(a in o)return o[a]}return o[""]}else{let n,a=-1;return Object.keys(o).forEach(s=>{const l=Number(s);!Number.isNaN(l)&&t>=l&&l>=a&&(a=l,n=o[s])}),n}}function rt(e){var t;const r=(t=e.dirs)===null||t===void 0?void 0:t.find(({dir:o})=>o===L);return!!(r&&r.value===!1)}const nt={xs:0,s:640,m:1024,l:1280,xl:1536,"2xl":1920};function ot(e){return`(min-width: ${e}px)`}const A={};function it(e=nt){if(!Be)return $(()=>[]);if(typeof window.matchMedia!="function")return $(()=>[]);const t=T({}),r=Object.keys(e),o=(n,a)=>{n.matches?t.value[a]=!0:t.value[a]=!1};return r.forEach(n=>{const a=e[n];let s,l;A[a]===void 0?(s=window.matchMedia(ot(a)),s.addEventListener?s.addEventListener("change",f=>{l.forEach(h=>{h(f,n)})}):s.addListener&&s.addListener(f=>{l.forEach(h=>{h(f,n)})}),l=new Set,A[a]={mql:s,cbs:l}):(s=A[a].mql,l=A[a].cbs),l.add(o),s.matches&&l.forEach(f=>{f(s,n)})}),ne(()=>{r.forEach(n=>{const{cbs:a}=A[e[n]];a.has(o)&&a.delete(o)})}),$(()=>{const{value:n}=t;return r.filter(a=>n[a])})}const st=G({name:"NDrawerContent",inheritAttrs:!1,props:{blockScroll:Boolean,show:{type:Boolean,default:void 0},displayDirective:{type:String,required:!0},placement:{type:String,required:!0},contentClass:String,contentStyle:[Object,String],nativeScrollbar:{type:Boolean,required:!0},scrollbarProps:Object,trapFocus:{type:Boolean,default:!0},autoFocus:{type:Boolean,default:!0},showMask:{type:[Boolean,String],required:!0},maxWidth:Number,maxHeight:Number,minWidth:Number,minHeight:Number,resizable:Boolean,onClickoutside:Function,onAfterLeave:Function,onAfterEnter:Function,onEsc:Function},setup(e){const t=T(!!e.show),r=T(null),o=Q(K);let n=0,a="",s=null;const l=T(!1),f=T(!1),h=$(()=>e.placement==="top"||e.placement==="bottom"),{mergedClsPrefixRef:k,mergedRtlRef:z}=J(e),C=Ee("Drawer",z,k),R=i,w=d=>{f.value=!0,n=h.value?d.clientY:d.clientX,a=document.body.style.cursor,document.body.style.cursor=h.value?"ns-resize":"ew-resize",document.body.addEventListener("mousemove",g),document.body.addEventListener("mouseleave",R),document.body.addEventListener("mouseup",i)},y=()=>{s!==null&&(window.clearTimeout(s),s=null),f.value?l.value=!0:s=window.setTimeout(()=>{l.value=!0},300)},N=()=>{s!==null&&(window.clearTimeout(s),s=null),l.value=!1},{doUpdateHeight:p,doUpdateWidth:c}=o,_=d=>{const{maxWidth:m}=e;if(m&&d>m)return m;const{minWidth:x}=e;return x&&d<x?x:d},B=d=>{const{maxHeight:m}=e;if(m&&d>m)return m;const{minHeight:x}=e;return x&&d<x?x:d};function g(d){var m,x;if(f.value)if(h.value){let M=((m=r.value)===null||m===void 0?void 0:m.offsetHeight)||0;const D=n-d.clientY;M+=e.placement==="bottom"?D:-D,M=B(M),p(M),n=d.clientY}else{let M=((x=r.value)===null||x===void 0?void 0:x.offsetWidth)||0;const D=n-d.clientX;M+=e.placement==="right"?D:-D,M=_(M),c(M),n=d.clientX}}function i(){f.value&&(n=0,f.value=!1,document.body.style.cursor=a,document.body.removeEventListener("mousemove",g),document.body.removeEventListener("mouseup",i),document.body.removeEventListener("mouseleave",R))}ke(()=>{e.show&&(t.value=!0)}),Ne(()=>e.show,d=>{d||i()}),ne(()=>{i()});const b=$(()=>{const{show:d}=e,m=[[L,d]];return e.showMask||m.push([_e,e.onClickoutside,void 0,{capture:!0}]),m});function S(){var d;t.value=!1,(d=e.onAfterLeave)===null||d===void 0||d.call(e)}return Me($(()=>e.blockScroll&&t.value)),j(Oe,r),j(De,null),j(Ie,null),{bodyRef:r,rtlEnabled:C,mergedClsPrefix:o.mergedClsPrefixRef,isMounted:o.isMountedRef,mergedTheme:o.mergedThemeRef,displayed:t,transitionName:$(()=>({right:"slide-in-from-right-transition",left:"slide-in-from-left-transition",top:"slide-in-from-top-transition",bottom:"slide-in-from-bottom-transition"})[e.placement]),handleAfterLeave:S,bodyDirectives:b,handleMousedownResizeTrigger:w,handleMouseenterResizeTrigger:y,handleMouseleaveResizeTrigger:N,isDragging:f,isHoverOnResizeTrigger:l}},render(){const{$slots:e,mergedClsPrefix:t}=this;return this.displayDirective==="show"||this.displayed||this.show?Y(v("div",{role:"none"},v(Te,{disabled:!this.showMask||!this.trapFocus,active:this.show,autoFocus:this.autoFocus,onEsc:this.onEsc},{default:()=>v(oe,{name:this.transitionName,appear:this.isMounted,onAfterEnter:this.onAfterEnter,onAfterLeave:this.handleAfterLeave},{default:()=>Y(v("div",q(this.$attrs,{role:"dialog",ref:"bodyRef","aria-modal":"true",class:[`${t}-drawer`,this.rtlEnabled&&`${t}-drawer--rtl`,`${t}-drawer--${this.placement}-placement`,this.isDragging&&`${t}-drawer--unselectable`,this.nativeScrollbar&&`${t}-drawer--native-scrollbar`]}),[this.resizable?v("div",{class:[`${t}-drawer__resize-trigger`,(this.isDragging||this.isHoverOnResizeTrigger)&&`${t}-drawer__resize-trigger--hover`],onMouseenter:this.handleMouseenterResizeTrigger,onMouseleave:this.handleMouseleaveResizeTrigger,onMousedown:this.handleMousedownResizeTrigger}):null,this.nativeScrollbar?v("div",{class:[`${t}-drawer-content-wrapper`,this.contentClass],style:this.contentStyle,role:"none"},e):v(ie,Object.assign({},this.scrollbarProps,{contentStyle:this.contentStyle,contentClass:[`${t}-drawer-content-wrapper`,this.contentClass],theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar}),e)]),this.bodyDirectives)})})),[[L,this.displayDirective==="if"||this.displayed||this.show]]):null}}),{cubicBezierEaseIn:at,cubicBezierEaseOut:lt}=X;function dt({duration:e="0.3s",leaveDuration:t="0.2s",name:r="slide-in-from-right"}={}){return[u(`&.${r}-transition-leave-active`,{transition:`transform ${t} ${at}`}),u(`&.${r}-transition-enter-active`,{transition:`transform ${e} ${lt}`}),u(`&.${r}-transition-enter-to`,{transform:"translateX(0)"}),u(`&.${r}-transition-enter-from`,{transform:"translateX(100%)"}),u(`&.${r}-transition-leave-from`,{transform:"translateX(0)"}),u(`&.${r}-transition-leave-to`,{transform:"translateX(100%)"})]}const{cubicBezierEaseIn:ct,cubicBezierEaseOut:ut}=X;function ft({duration:e="0.3s",leaveDuration:t="0.2s",name:r="slide-in-from-left"}={}){return[u(`&.${r}-transition-leave-active`,{transition:`transform ${t} ${ct}`}),u(`&.${r}-transition-enter-active`,{transition:`transform ${e} ${ut}`}),u(`&.${r}-transition-enter-to`,{transform:"translateX(0)"}),u(`&.${r}-transition-enter-from`,{transform:"translateX(-100%)"}),u(`&.${r}-transition-leave-from`,{transform:"translateX(0)"}),u(`&.${r}-transition-leave-to`,{transform:"translateX(-100%)"})]}const{cubicBezierEaseIn:ht,cubicBezierEaseOut:vt}=X;function bt({duration:e="0.3s",leaveDuration:t="0.2s",name:r="slide-in-from-top"}={}){return[u(`&.${r}-transition-leave-active`,{transition:`transform ${t} ${ht}`}),u(`&.${r}-transition-enter-active`,{transition:`transform ${e} ${vt}`}),u(`&.${r}-transition-enter-to`,{transform:"translateY(0)"}),u(`&.${r}-transition-enter-from`,{transform:"translateY(-100%)"}),u(`&.${r}-transition-leave-from`,{transform:"translateY(0)"}),u(`&.${r}-transition-leave-to`,{transform:"translateY(-100%)"})]}const{cubicBezierEaseIn:mt,cubicBezierEaseOut:pt}=X;function gt({duration:e="0.3s",leaveDuration:t="0.2s",name:r="slide-in-from-bottom"}={}){return[u(`&.${r}-transition-leave-active`,{transition:`transform ${t} ${mt}`}),u(`&.${r}-transition-enter-active`,{transition:`transform ${e} ${pt}`}),u(`&.${r}-transition-enter-to`,{transform:"translateY(0)"}),u(`&.${r}-transition-enter-from`,{transform:"translateY(100%)"}),u(`&.${r}-transition-leave-from`,{transform:"translateY(0)"}),u(`&.${r}-transition-leave-to`,{transform:"translateY(100%)"})]}const wt=u([E("drawer",`
 word-break: break-word;
 line-height: var(--n-line-height);
 position: absolute;
 pointer-events: all;
 box-shadow: var(--n-box-shadow);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 background-color: var(--n-color);
 color: var(--n-text-color);
 box-sizing: border-box;
 `,[dt(),ft(),bt(),gt(),O("unselectable",`
 user-select: none; 
 -webkit-user-select: none;
 `),O("native-scrollbar",[E("drawer-content-wrapper",`
 overflow: auto;
 height: 100%;
 `)]),F("resize-trigger",`
 position: absolute;
 background-color: #0000;
 transition: background-color .3s var(--n-bezier);
 `,[O("hover",`
 background-color: var(--n-resize-trigger-color-hover);
 `)]),E("drawer-content-wrapper",`
 box-sizing: border-box;
 `),E("drawer-content",`
 height: 100%;
 display: flex;
 flex-direction: column;
 `,[O("native-scrollbar",[E("drawer-body-content-wrapper",`
 height: 100%;
 overflow: auto;
 `)]),E("drawer-body",`
 flex: 1 0 0;
 overflow: hidden;
 `),E("drawer-body-content-wrapper",`
 box-sizing: border-box;
 padding: var(--n-body-padding);
 `),E("drawer-header",`
 font-weight: var(--n-title-font-weight);
 line-height: 1;
 font-size: var(--n-title-font-size);
 color: var(--n-title-text-color);
 padding: var(--n-header-padding);
 transition: border .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-divider-color);
 border-bottom: var(--n-header-border-bottom);
 display: flex;
 justify-content: space-between;
 align-items: center;
 `,[F("close",`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `)]),E("drawer-footer",`
 display: flex;
 justify-content: flex-end;
 border-top: var(--n-footer-border-top);
 transition: border .3s var(--n-bezier);
 padding: var(--n-footer-padding);
 `)]),O("right-placement",`
 top: 0;
 bottom: 0;
 right: 0;
 border-top-left-radius: var(--n-border-radius);
 border-bottom-left-radius: var(--n-border-radius);
 `,[F("resize-trigger",`
 width: 3px;
 height: 100%;
 top: 0;
 left: 0;
 transform: translateX(-1.5px);
 cursor: ew-resize;
 `)]),O("left-placement",`
 top: 0;
 bottom: 0;
 left: 0;
 border-top-right-radius: var(--n-border-radius);
 border-bottom-right-radius: var(--n-border-radius);
 `,[F("resize-trigger",`
 width: 3px;
 height: 100%;
 top: 0;
 right: 0;
 transform: translateX(1.5px);
 cursor: ew-resize;
 `)]),O("top-placement",`
 top: 0;
 left: 0;
 right: 0;
 border-bottom-left-radius: var(--n-border-radius);
 border-bottom-right-radius: var(--n-border-radius);
 `,[F("resize-trigger",`
 width: 100%;
 height: 3px;
 bottom: 0;
 left: 0;
 transform: translateY(1.5px);
 cursor: ns-resize;
 `)]),O("bottom-placement",`
 left: 0;
 bottom: 0;
 right: 0;
 border-top-left-radius: var(--n-border-radius);
 border-top-right-radius: var(--n-border-radius);
 `,[F("resize-trigger",`
 width: 100%;
 height: 3px;
 top: 0;
 left: 0;
 transform: translateY(-1.5px);
 cursor: ns-resize;
 `)])]),u("body",[u(">",[E("drawer-container",`
 position: fixed;
 `)])]),E("drawer-container",`
 position: relative;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 `,[u("> *",`
 pointer-events: all;
 `)]),E("drawer-mask",`
 background-color: rgba(0, 0, 0, .3);
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `,[O("invisible",`
 background-color: rgba(0, 0, 0, 0)
 `),Fe({enterDuration:"0.2s",leaveDuration:"0.2s",enterCubicBezier:"var(--n-bezier-in)",leaveCubicBezier:"var(--n-bezier-out)"})])]),yt=Object.assign(Object.assign({},se.props),{show:Boolean,width:[Number,String],height:[Number,String],placement:{type:String,default:"right"},maskClosable:{type:Boolean,default:!0},showMask:{type:[Boolean,String],default:!0},to:[String,Object],displayDirective:{type:String,default:"if"},nativeScrollbar:{type:Boolean,default:!0},zIndex:Number,onMaskClick:Function,scrollbarProps:Object,contentClass:String,contentStyle:[Object,String],trapFocus:{type:Boolean,default:!0},onEsc:Function,autoFocus:{type:Boolean,default:!0},closeOnEsc:{type:Boolean,default:!0},blockScroll:{type:Boolean,default:!0},maxWidth:Number,maxHeight:Number,minWidth:Number,minHeight:Number,resizable:Boolean,defaultWidth:{type:[Number,String],default:251},defaultHeight:{type:[Number,String],default:251},onUpdateWidth:[Function,Array],onUpdateHeight:[Function,Array],"onUpdate:width":[Function,Array],"onUpdate:height":[Function,Array],"onUpdate:show":[Function,Array],onUpdateShow:[Function,Array],onAfterEnter:Function,onAfterLeave:Function,drawerStyle:[String,Object],drawerClass:String,target:null,onShow:Function,onHide:Function}),Bt=G({name:"Drawer",inheritAttrs:!1,props:yt,setup(e){const{mergedClsPrefixRef:t,namespaceRef:r,inlineThemeDisabled:o}=J(e),n=Pe(),a=se("Drawer","-drawer",wt,We,e,t),s=T(e.defaultWidth),l=T(e.defaultHeight),f=Z(U(e,"width"),s),h=Z(U(e,"height"),l),k=$(()=>{const{placement:i}=e;return i==="top"||i==="bottom"?"":ee(f.value)}),z=$(()=>{const{placement:i}=e;return i==="left"||i==="right"?"":ee(h.value)}),C=i=>{const{onUpdateWidth:b,"onUpdate:width":S}=e;b&&I(b,i),S&&I(S,i),s.value=i},R=i=>{const{onUpdateHeight:b,"onUpdate:width":S}=e;b&&I(b,i),S&&I(S,i),l.value=i},w=$(()=>[{width:k.value,height:z.value},e.drawerStyle||""]);function y(i){const{onMaskClick:b,maskClosable:S}=e;S&&_(!1),b&&b(i)}function N(i){y(i)}const p=He();function c(i){var b;(b=e.onEsc)===null||b===void 0||b.call(e),e.show&&e.closeOnEsc&&Le(i)&&(p.value||_(!1))}function _(i){const{onHide:b,onUpdateShow:S,"onUpdate:show":d}=e;S&&I(S,i),d&&I(d,i),b&&!i&&I(b,i)}j(K,{isMountedRef:n,mergedThemeRef:a,mergedClsPrefixRef:t,doUpdateShow:_,doUpdateHeight:R,doUpdateWidth:C});const B=$(()=>{const{common:{cubicBezierEaseInOut:i,cubicBezierEaseIn:b,cubicBezierEaseOut:S},self:{color:d,textColor:m,boxShadow:x,lineHeight:M,headerPadding:D,footerPadding:ce,borderRadius:ue,bodyPadding:fe,titleFontSize:he,titleTextColor:ve,titleFontWeight:be,headerBorderBottom:me,footerBorderTop:pe,closeIconColor:ge,closeIconColorHover:we,closeIconColorPressed:ye,closeColorHover:Se,closeColorPressed:$e,closeIconSize:Ce,closeSize:Re,closeBorderRadius:xe,resizableTriggerColorHover:ze}}=a.value;return{"--n-line-height":M,"--n-color":d,"--n-border-radius":ue,"--n-text-color":m,"--n-box-shadow":x,"--n-bezier":i,"--n-bezier-out":S,"--n-bezier-in":b,"--n-header-padding":D,"--n-body-padding":fe,"--n-footer-padding":ce,"--n-title-text-color":ve,"--n-title-font-size":he,"--n-title-font-weight":be,"--n-header-border-bottom":me,"--n-footer-border-top":pe,"--n-close-icon-color":ge,"--n-close-icon-color-hover":we,"--n-close-icon-color-pressed":ye,"--n-close-size":Re,"--n-close-color-hover":Se,"--n-close-color-pressed":$e,"--n-close-icon-size":Ce,"--n-close-border-radius":xe,"--n-resize-trigger-color-hover":ze}}),g=o?Ae("drawer",void 0,B,e):void 0;return{mergedClsPrefix:t,namespace:r,mergedBodyStyle:w,handleOutsideClick:N,handleMaskClick:y,handleEsc:c,mergedTheme:a,cssVars:o?void 0:B,themeClass:g==null?void 0:g.themeClass,onRender:g==null?void 0:g.onRender,isMounted:n}},render(){const{mergedClsPrefix:e}=this;return v(Ge,{to:this.to,show:this.show},{default:()=>{var t;return(t=this.onRender)===null||t===void 0||t.call(this),Y(v("div",{class:[`${e}-drawer-container`,this.namespace,this.themeClass],style:this.cssVars,role:"none"},this.showMask?v(oe,{name:"fade-in-transition",appear:this.isMounted},{default:()=>this.show?v("div",{"aria-hidden":!0,class:[`${e}-drawer-mask`,this.showMask==="transparent"&&`${e}-drawer-mask--invisible`],onClick:this.handleMaskClick}):null}):null,v(st,Object.assign({},this.$attrs,{class:[this.drawerClass,this.$attrs.class],style:[this.mergedBodyStyle,this.$attrs.style],blockScroll:this.blockScroll,contentStyle:this.contentStyle,contentClass:this.contentClass,placement:this.placement,scrollbarProps:this.scrollbarProps,show:this.show,displayDirective:this.displayDirective,nativeScrollbar:this.nativeScrollbar,onAfterEnter:this.onAfterEnter,onAfterLeave:this.onAfterLeave,trapFocus:this.trapFocus,autoFocus:this.autoFocus,resizable:this.resizable,maxHeight:this.maxHeight,minHeight:this.minHeight,maxWidth:this.maxWidth,minWidth:this.minWidth,showMask:this.showMask,onEsc:this.handleEsc,onClickoutside:this.handleOutsideClick}),this.$slots)),[[je,{zIndex:this.zIndex,enabled:this.show}]])}})}}),St={title:String,headerClass:String,headerStyle:[Object,String],footerClass:String,footerStyle:[Object,String],bodyClass:String,bodyStyle:[Object,String],bodyContentClass:String,bodyContentStyle:[Object,String],nativeScrollbar:{type:Boolean,default:!0},scrollbarProps:Object,closable:Boolean},Et=G({name:"DrawerContent",props:St,setup(){const e=Q(K,null);e||Ue("drawer-content","`n-drawer-content` must be placed inside `n-drawer`.");const{doUpdateShow:t}=e;function r(){t(!1)}return{handleCloseClick:r,mergedTheme:e.mergedThemeRef,mergedClsPrefix:e.mergedClsPrefixRef}},render(){const{title:e,mergedClsPrefix:t,nativeScrollbar:r,mergedTheme:o,bodyClass:n,bodyStyle:a,bodyContentClass:s,bodyContentStyle:l,headerClass:f,headerStyle:h,footerClass:k,footerStyle:z,scrollbarProps:C,closable:R,$slots:w}=this;return v("div",{role:"none",class:[`${t}-drawer-content`,r&&`${t}-drawer-content--native-scrollbar`]},w.header||e||R?v("div",{class:[`${t}-drawer-header`,f],style:h,role:"none"},v("div",{class:`${t}-drawer-header__main`,role:"heading","aria-level":"1"},w.header!==void 0?w.header():e),R&&v(Xe,{onClick:this.handleCloseClick,clsPrefix:t,class:`${t}-drawer-header__close`,absolute:!0})):null,r?v("div",{class:[`${t}-drawer-body`,n],style:a,role:"none"},v("div",{class:[`${t}-drawer-body-content-wrapper`,s],style:l,role:"none"},w)):v(ie,Object.assign({themeOverrides:o.peerOverrides.Scrollbar,theme:o.peers.Scrollbar},C,{class:`${t}-drawer-body`,contentClass:[`${t}-drawer-body-content-wrapper`,s],contentStyle:l}),w),w.footer?v("div",{class:[`${t}-drawer-footer`,k],style:z,role:"none"},w.footer()):null)}}),re=1,ae=Ve("n-grid"),le=1,$t={span:{type:[Number,String],default:le},offset:{type:[Number,String],default:0},suffix:Boolean,privateOffset:Number,privateSpan:Number,privateColStart:Number,privateShow:{type:Boolean,default:!0}},kt=G({__GRID_ITEM__:!0,name:"GridItem",alias:["Gi"],props:$t,setup(){const{isSsrRef:e,xGapRef:t,itemStyleRef:r,overflowRef:o,layoutShiftDisabledRef:n}=Q(ae),a=Ye();return{overflow:o,itemStyle:r,layoutShiftDisabled:n,mergedXGap:$(()=>H(t.value||0)),deriveStyle:()=>{e.value;const{privateSpan:s=le,privateShow:l=!0,privateColStart:f=void 0,privateOffset:h=0}=a.vnode.props,{value:k}=t,z=H(k||0);return{display:l?"":"none",gridColumn:`${f!=null?f:`span ${s}`} / span ${s}`,marginLeft:h?`calc((100% - (${s} - 1) * ${z}) / ${s} * ${h} + ${z} * ${h})`:""}}}},render(){var e,t;if(this.layoutShiftDisabled){const{span:r,offset:o,mergedXGap:n}=this;return v("div",{style:{gridColumn:`span ${r} / span ${r}`,marginLeft:o?`calc((100% - (${r} - 1) * ${n}) / ${r} * ${o} + ${n} * ${o})`:""}},this.$slots)}return v("div",{style:[this.itemStyle,this.deriveStyle()]},(t=(e=this.$slots).default)===null||t===void 0?void 0:t.call(e,{overflow:this.overflow}))}}),Ct={xs:0,s:640,m:1024,l:1280,xl:1536,xxl:1920},de=24,V="__ssr__",Rt={layoutShiftDisabled:Boolean,responsive:{type:[String,Boolean],default:"self"},cols:{type:[Number,String],default:de},itemResponsive:Boolean,collapsed:Boolean,collapsedRows:{type:Number,default:1},itemStyle:[Object,String],xGap:{type:[Number,String],default:0},yGap:{type:[Number,String],default:0}},Nt=G({name:"Grid",inheritAttrs:!1,props:Rt,setup(e){const{mergedClsPrefixRef:t,mergedBreakpointsRef:r}=J(e),o=/^\d+$/,n=T(void 0),a=it((r==null?void 0:r.value)||Ct),s=W(()=>!!(e.itemResponsive||!o.test(e.cols.toString())||!o.test(e.xGap.toString())||!o.test(e.yGap.toString()))),l=$(()=>{if(s.value)return e.responsive==="self"?n.value:a.value}),f=W(()=>{var p;return(p=Number(P(e.cols.toString(),l.value)))!==null&&p!==void 0?p:de}),h=W(()=>P(e.xGap.toString(),l.value)),k=W(()=>P(e.yGap.toString(),l.value)),z=p=>{n.value=p.contentRect.width},C=p=>{Je(z,p)},R=T(!1),w=$(()=>{if(e.responsive==="self")return C}),y=T(!1),N=T();return qe(()=>{const{value:p}=N;p&&p.hasAttribute(V)&&(p.removeAttribute(V),y.value=!0)}),j(ae,{layoutShiftDisabledRef:U(e,"layoutShiftDisabled"),isSsrRef:y,itemStyleRef:U(e,"itemStyle"),xGapRef:h,overflowRef:R}),{isSsr:!Qe,contentEl:N,mergedClsPrefix:t,style:$(()=>e.layoutShiftDisabled?{width:"100%",display:"grid",gridTemplateColumns:`repeat(${e.cols}, minmax(0, 1fr))`,columnGap:H(e.xGap),rowGap:H(e.yGap)}:{width:"100%",display:"grid",gridTemplateColumns:`repeat(${f.value}, minmax(0, 1fr))`,columnGap:H(h.value),rowGap:H(k.value)}),isResponsive:s,responsiveQuery:l,responsiveCols:f,handleResize:w,overflow:R}},render(){if(this.layoutShiftDisabled)return v("div",q({ref:"contentEl",class:`${this.mergedClsPrefix}-grid`,style:this.style},this.$attrs),this.$slots);const e=()=>{var t,r,o,n,a,s,l;this.overflow=!1;const f=Ze(et(this)),h=[],{collapsed:k,collapsedRows:z,responsiveCols:C,responsiveQuery:R}=this;f.forEach(c=>{var _,B,g,i,b;if(((_=c==null?void 0:c.type)===null||_===void 0?void 0:_.__GRID_ITEM__)!==!0)return;if(rt(c)){const m=te(c);m.props?m.props.privateShow=!1:m.props={privateShow:!1},h.push({child:m,rawChildSpan:0});return}c.dirs=((B=c.dirs)===null||B===void 0?void 0:B.filter(({dir:m})=>m!==L))||null,((g=c.dirs)===null||g===void 0?void 0:g.length)===0&&(c.dirs=null);const S=te(c),d=Number((b=P((i=S.props)===null||i===void 0?void 0:i.span,R))!==null&&b!==void 0?b:re);d!==0&&h.push({child:S,rawChildSpan:d})});let w=0;const y=(t=h[h.length-1])===null||t===void 0?void 0:t.child;if(y!=null&&y.props){const c=(r=y.props)===null||r===void 0?void 0:r.suffix;c!==void 0&&c!==!1&&(w=Number((n=P((o=y.props)===null||o===void 0?void 0:o.span,R))!==null&&n!==void 0?n:re),y.props.privateSpan=w,y.props.privateColStart=C+1-w,y.props.privateShow=(a=y.props.privateShow)!==null&&a!==void 0?a:!0)}let N=0,p=!1;for(const{child:c,rawChildSpan:_}of h){if(p&&(this.overflow=!0),!p){const B=Number((l=P((s=c.props)===null||s===void 0?void 0:s.offset,R))!==null&&l!==void 0?l:0),g=Math.min(_+B,C);if(c.props?(c.props.privateSpan=g,c.props.privateOffset=B):c.props={privateSpan:g,privateOffset:B},k){const i=N%C;g+i>C&&(N+=C-i),g+N+w>z*C?p=!0:N+=g}}p&&(c.props?c.props.privateShow!==!0&&(c.props.privateShow=!1):c.props={privateShow:!1})}return v("div",q({ref:"contentEl",class:`${this.mergedClsPrefix}-grid`,style:this.style,[V]:this.isSsr||void 0},this.$attrs),h.map(({child:c})=>c))};return this.isResponsive&&this.responsive==="self"?v(Ke,{onResize:this.handleResize},{default:e}):e()}});export{kt as N,Nt as a,Et as b,Bt as c};
