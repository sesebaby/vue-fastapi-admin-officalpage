function n(e,o){if(!e)return;const d=document.createElement("a");d.href=e,o!==void 0&&(d.download=o),document.body.appendChild(d),d.click(),document.body.removeChild(d)}export{n as d};
