import{c8 as t}from"./index-35a90bb6.js";const e=t(!0);export{e as N};
