var H=(e,a,i)=>new Promise((t,n)=>{var o=s=>{try{l(i.next(s))}catch(c){n(c)}},u=s=>{try{l(i.throw(s))}catch(c){n(c)}},l=s=>s.done?t(s.value):Promise.resolve(s.value).then(o,u);l((i=i.apply(e,a)).next())});import{aM as re,a0 as C,k as p,l as $,d as R,e as k,aN as j,j as r,ay as K,aO as U,aP as Z,aQ as Q,aR as ee,u as V,a as I,aS as ie,f as W,n as te,au as ne,aT as E,aU as se,aV as oe,F as A,aW as ae,aX as le,aY as ce,H as D,a7 as ge,aZ as de,aq as ue,_ as pe,a_ as he,o as me,q as _,z as x,s as v,G as M,C as G,aI as X,w as T,y as q,A as Y}from"./index-35a90bb6.js";import{N as fe}from"./Space-bcef978a.js";let F=!1;function ye(){if(re&&window.CSS&&!F&&(F=!0,"registerProperty"in(window==null?void 0:window.CSS)))try{CSS.registerProperty({name:"--n-color-start",syntax:"<color>",inherits:!1,initialValue:"#0000"}),CSS.registerProperty({name:"--n-color-end",syntax:"<color>",inherits:!1,initialValue:"#0000"})}catch(e){}}const ve=C([p("progress",{display:"inline-block"},[p("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),$("line",`
 width: 100%;
 display: block;
 `,[p("progress-content",`
 display: flex;
 align-items: center;
 `,[p("progress-graph",{flex:1})]),p("progress-custom-content",{marginLeft:"14px"}),p("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[$("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),$("circle, dashboard",{width:"120px"},[p("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),p("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),p("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),$("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[p("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),p("progress-content",{position:"relative"}),p("progress-graph",{position:"relative"},[p("progress-graph-circle",[C("svg",{verticalAlign:"bottom"}),p("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[$("empty",{opacity:0})]),p("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),p("progress-graph-line",[$("indicator-inside",[p("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[p("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),p("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),$("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[p("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),p("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),p("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[p("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[$("processing",[C("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),C("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),be={success:r(U,null),error:r(Z,null),warning:r(Q,null),info:r(ee,null)},_e=R({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:a}){const i=k(()=>j(e.height)),t=k(()=>e.railBorderRadius!==void 0?j(e.railBorderRadius):e.height!==void 0?j(e.height,{c:.5}):""),n=k(()=>e.fillBorderRadius!==void 0?j(e.fillBorderRadius):e.railBorderRadius!==void 0?j(e.railBorderRadius):e.height!==void 0?j(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:o,railColor:u,railStyle:l,percentage:s,unit:c,indicatorTextColor:h,status:m,showIndicator:y,fillColor:g,processing:b,clsPrefix:d}=e;return r("div",{class:`${d}-progress-content`,role:"none"},r("div",{class:`${d}-progress-graph`,"aria-hidden":!0},r("div",{class:[`${d}-progress-graph-line`,{[`${d}-progress-graph-line--indicator-${o}`]:!0}]},r("div",{class:`${d}-progress-graph-line-rail`,style:[{backgroundColor:u,height:i.value,borderRadius:t.value},l]},r("div",{class:[`${d}-progress-graph-line-fill`,b&&`${d}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:g,height:i.value,lineHeight:i.value,borderRadius:n.value}},o==="inside"?r("div",{class:`${d}-progress-graph-line-indicator`,style:{color:h}},a.default?a.default():`${s}${c}`):null)))),y&&o==="outside"?r("div",null,a.default?r("div",{class:`${d}-progress-custom-content`,style:{color:h},role:"none"},a.default()):m==="default"?r("div",{role:"none",class:`${d}-progress-icon ${d}-progress-icon--as-text`,style:{color:h}},s,c):r("div",{class:`${d}-progress-icon`,"aria-hidden":!0},r(K,{clsPrefix:d},{default:()=>be[m]}))):null)}}}),xe={success:r(U,null),error:r(Z,null),warning:r(Q,null),info:r(ee,null)},Se=R({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:a}){function i(t,n,o){const{gapDegree:u,viewBoxWidth:l,strokeWidth:s}=e,c=50,h=0,m=c,y=0,g=2*c,b=50+s/2,d=`M ${b},${b} m ${h},${m}
      a ${c},${c} 0 1 1 ${y},${-g}
      a ${c},${c} 0 1 1 ${-y},${g}`,w=Math.PI*2*c,S={stroke:o,strokeDasharray:`${t/100*(w-u)}px ${l*8}px`,strokeDashoffset:`-${u/2}px`,transformOrigin:n?"center":void 0,transform:n?`rotate(${n}deg)`:void 0};return{pathString:d,pathStyle:S}}return()=>{const{fillColor:t,railColor:n,strokeWidth:o,offsetDegree:u,status:l,percentage:s,showIndicator:c,indicatorTextColor:h,unit:m,gapOffsetDegree:y,clsPrefix:g}=e,{pathString:b,pathStyle:d}=i(100,0,n),{pathString:w,pathStyle:S}=i(s,u,t),f=100+o;return r("div",{class:`${g}-progress-content`,role:"none"},r("div",{class:`${g}-progress-graph`,"aria-hidden":!0},r("div",{class:`${g}-progress-graph-circle`,style:{transform:y?`rotate(${y}deg)`:void 0}},r("svg",{viewBox:`0 0 ${f} ${f}`},r("g",null,r("path",{class:`${g}-progress-graph-circle-rail`,d:b,"stroke-width":o,"stroke-linecap":"round",fill:"none",style:d})),r("g",null,r("path",{class:[`${g}-progress-graph-circle-fill`,s===0&&`${g}-progress-graph-circle-fill--empty`],d:w,"stroke-width":o,"stroke-linecap":"round",fill:"none",style:S}))))),c?r("div",null,a.default?r("div",{class:`${g}-progress-custom-content`,role:"none"},a.default()):l!=="default"?r("div",{class:`${g}-progress-icon`,"aria-hidden":!0},r(K,{clsPrefix:g},{default:()=>xe[l]})):r("div",{class:`${g}-progress-text`,style:{color:h},role:"none"},r("span",{class:`${g}-progress-text__percentage`},s),r("span",{class:`${g}-progress-text__unit`},m))):null)}}});function J(e,a,i=100){return`m ${i/2} ${i/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const ke=R({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:a}){const i=k(()=>e.percentage.map((n,o)=>`${Math.PI*n/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*o)-e.circleGap*o)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:t,strokeWidth:n,circleGap:o,showIndicator:u,fillColor:l,railColor:s,railStyle:c,percentage:h,clsPrefix:m}=e;return r("div",{class:`${m}-progress-content`,role:"none"},r("div",{class:`${m}-progress-graph`,"aria-hidden":!0},r("div",{class:`${m}-progress-graph-circle`},r("svg",{viewBox:`0 0 ${t} ${t}`},h.map((y,g)=>r("g",{key:g},r("path",{class:`${m}-progress-graph-circle-rail`,d:J(t/2-n/2*(1+2*g)-o*g,n,t),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:s[g]},c[g]]}),r("path",{class:[`${m}-progress-graph-circle-fill`,y===0&&`${m}-progress-graph-circle-fill--empty`],d:J(t/2-n/2*(1+2*g)-o*g,n,t),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:i.value[g],strokeDashoffset:0,stroke:l[g]}})))))),u&&a.default?r("div",null,r("div",{class:`${m}-progress-text`},a.default())):null)}}}),we=Object.assign(Object.assign({},I.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),$e=R({name:"Progress",props:we,setup(e){const a=k(()=>e.indicatorPlacement||e.indicatorPosition),i=k(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:t,inlineThemeDisabled:n}=V(e),o=I("Progress","-progress",ve,ie,e,t),u=k(()=>{const{status:s}=e,{common:{cubicBezierEaseInOut:c},self:{fontSize:h,fontSizeCircle:m,railColor:y,railHeight:g,iconSizeCircle:b,iconSizeLine:d,textColorCircle:w,textColorLineInner:S,textColorLineOuter:f,lineBgProcessing:z,fontWeightCircle:P,[W("iconColor",s)]:B,[W("fillColor",s)]:N}}=o.value;return{"--n-bezier":c,"--n-fill-color":N,"--n-font-size":h,"--n-font-size-circle":m,"--n-font-weight-circle":P,"--n-icon-color":B,"--n-icon-size-circle":b,"--n-icon-size-line":d,"--n-line-bg-processing":z,"--n-rail-color":y,"--n-rail-height":g,"--n-text-color-circle":w,"--n-text-color-line-inner":S,"--n-text-color-line-outer":f}}),l=n?te("progress",k(()=>e.status[0]),u,e):void 0;return{mergedClsPrefix:t,mergedIndicatorPlacement:a,gapDeg:i,cssVars:n?void 0:u,themeClass:l==null?void 0:l.themeClass,onRender:l==null?void 0:l.onRender}},render(){const{type:e,cssVars:a,indicatorTextColor:i,showIndicator:t,status:n,railColor:o,railStyle:u,color:l,percentage:s,viewBoxWidth:c,strokeWidth:h,mergedIndicatorPlacement:m,unit:y,borderRadius:g,fillBorderRadius:b,height:d,processing:w,circleGap:S,mergedClsPrefix:f,gapDeg:z,gapOffsetDegree:P,themeClass:B,$slots:N,onRender:L}=this;return L==null||L(),r("div",{class:[B,`${f}-progress`,`${f}-progress--${e}`,`${f}-progress--${n}`],style:a,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":s,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?r(Se,{clsPrefix:f,status:n,showIndicator:t,indicatorTextColor:i,railColor:o,fillColor:l,railStyle:u,offsetDegree:this.offsetDegree,percentage:s,viewBoxWidth:c,strokeWidth:h,gapDegree:z===void 0?e==="dashboard"?75:0:z,gapOffsetDegree:P,unit:y},N):e==="line"?r(_e,{clsPrefix:f,status:n,showIndicator:t,indicatorTextColor:i,railColor:o,fillColor:l,railStyle:u,percentage:s,processing:w,indicatorPlacement:m,unit:y,fillBorderRadius:b,railBorderRadius:g,height:d},N):e==="multiple-circle"?r(ke,{clsPrefix:f,strokeWidth:h,railColor:o,fillColor:l,railStyle:u,viewBoxWidth:c,percentage:s,showIndicator:t,circleGap:S},N):null)}});function ze(e){const{heightSmall:a,heightMedium:i,heightLarge:t,borderRadius:n}=e;return{color:"#eee",colorEnd:"#ddd",borderRadius:n,heightSmall:a,heightMedium:i,heightLarge:t}}const Ce={name:"Skeleton",common:ne,self:ze},Pe=C([p("skeleton",`
 height: 1em;
 width: 100%;
 transition:
 --n-color-start .3s var(--n-bezier),
 --n-color-end .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 animation: 2s skeleton-loading infinite cubic-bezier(0.36, 0, 0.64, 1);
 background-color: var(--n-color-start);
 `),C("@keyframes skeleton-loading",`
 0% {
 background: var(--n-color-start);
 }
 40% {
 background: var(--n-color-end);
 }
 80% {
 background: var(--n-color-start);
 }
 100% {
 background: var(--n-color-start);
 }
 `)]),Be=Object.assign(Object.assign({},I.props),{text:Boolean,round:Boolean,circle:Boolean,height:[String,Number],width:[String,Number],size:String,repeat:{type:Number,default:1},animated:{type:Boolean,default:!0},sharp:{type:Boolean,default:!0}}),je=R({name:"Skeleton",inheritAttrs:!1,props:Be,setup(e){ye();const{mergedClsPrefixRef:a}=V(e),i=I("Skeleton","-skeleton",Pe,Ce,e,a);return{mergedClsPrefix:a,style:k(()=>{var t,n;const o=i.value,{common:{cubicBezierEaseInOut:u}}=o,l=o.self,{color:s,colorEnd:c,borderRadius:h}=l;let m;const{circle:y,sharp:g,round:b,width:d,height:w,size:S,text:f,animated:z}=e;S!==void 0&&(m=l[W("height",S)]);const P=y?(t=d!=null?d:w)!==null&&t!==void 0?t:m:d,B=(n=y&&d!=null?d:w)!==null&&n!==void 0?n:m;return{display:f?"inline-block":"",verticalAlign:f?"-0.125em":"",borderRadius:y?"50%":b?"4096px":g?"":h,width:typeof P=="number"?E(P):P,height:typeof B=="number"?E(B):B,animation:z?"":"none","--n-bezier":u,"--n-color-start":s,"--n-color-end":c}})}},render(){const{repeat:e,style:a,mergedClsPrefix:i,$attrs:t}=this,n=r("div",se({class:`${i}-skeleton`,style:a},t));return e>1?r(A,null,oe(e,null).map(o=>[n,`
`])):n}}),Re=C([C("@keyframes spin-rotate",`
 from {
 transform: rotate(0);
 }
 to {
 transform: rotate(360deg);
 }
 `),p("spin-container",`
 position: relative;
 `,[p("spin-body",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[ae()])]),p("spin-body",`
 display: inline-flex;
 align-items: center;
 justify-content: center;
 flex-direction: column;
 `),p("spin",`
 display: inline-flex;
 height: var(--n-size);
 width: var(--n-size);
 font-size: var(--n-size);
 color: var(--n-color);
 `,[$("rotate",`
 animation: spin-rotate 2s linear infinite;
 `)]),p("spin-description",`
 display: inline-block;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 margin-top: 8px;
 `),p("spin-content",`
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 pointer-events: all;
 `,[$("spinning",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: none;
 opacity: var(--n-opacity-spinning);
 `)])]),Ie={small:20,medium:18,large:16},Ne=Object.assign(Object.assign({},I.props),{contentClass:String,contentStyle:[Object,String],description:String,stroke:String,size:{type:[String,Number],default:"medium"},show:{type:Boolean,default:!0},strokeWidth:Number,rotate:{type:Boolean,default:!0},spinning:{type:Boolean,validator:()=>!0,default:void 0},delay:Number}),De=R({name:"Spin",props:Ne,setup(e){const{mergedClsPrefixRef:a,inlineThemeDisabled:i}=V(e),t=I("Spin","-spin",Re,le,e,a),n=k(()=>{const{size:s}=e,{common:{cubicBezierEaseInOut:c},self:h}=t.value,{opacitySpinning:m,color:y,textColor:g}=h,b=typeof s=="number"?E(s):h[W("size",s)];return{"--n-bezier":c,"--n-opacity-spinning":m,"--n-size":b,"--n-color":y,"--n-text-color":g}}),o=i?te("spin",k(()=>{const{size:s}=e;return typeof s=="number"?String(s):s[0]}),n,e):void 0,u=ce(e,["spinning","show"]),l=D(!1);return ge(s=>{let c;if(u.value){const{delay:h}=e;if(h){c=window.setTimeout(()=>{l.value=!0},h),s(()=>{clearTimeout(c)});return}}l.value=u.value}),{mergedClsPrefix:a,active:l,mergedStrokeWidth:k(()=>{const{strokeWidth:s}=e;if(s!==void 0)return s;const{size:c}=e;return Ie[typeof c=="number"?"medium":c]}),cssVars:i?void 0:n,themeClass:o==null?void 0:o.themeClass,onRender:o==null?void 0:o.onRender}},render(){var e,a;const{$slots:i,mergedClsPrefix:t,description:n}=this,o=i.icon&&this.rotate,u=(n||i.description)&&r("div",{class:`${t}-spin-description`},n||((e=i.description)===null||e===void 0?void 0:e.call(i))),l=i.icon?r("div",{class:[`${t}-spin-body`,this.themeClass]},r("div",{class:[`${t}-spin`,o&&`${t}-spin--rotate`],style:i.default?"":this.cssVars},i.icon()),u):r("div",{class:[`${t}-spin-body`,this.themeClass]},r(de,{clsPrefix:t,style:i.default?"":this.cssVars,stroke:this.stroke,"stroke-width":this.mergedStrokeWidth,class:`${t}-spin`}),u);return(a=this.onRender)===null||a===void 0||a.call(this),i.default?r("div",{class:[`${t}-spin-container`,this.themeClass],style:this.cssVars},r("div",{class:[`${t}-spin-content`,this.active&&`${t}-spin-content--spinning`,this.contentClass],style:this.contentStyle},i),r(ue,{name:"fade-in-transition"},{default:()=>this.active?l:null})):l}}),O={news:"/images/business_office_scene.jpg",avatar:"/images/business_office_scene.jpg",logo:"/images/ISO9001质量管理体系认证证书.png",business:"/images/business_office_scene.jpg",technology:"/images/icon_advanced_packaging.jpg",case:"/images/product_development_cycle_chart.jpg",certificate:"/images/ISO9001质量管理体系认证证书.png"},Oe={hero:{company_hero:"/images/hero_pictore_company.png",tech_background:"/images/科技背景图片.jpg",third_slide:"/images/company_scene_02.jpg",fourth_slide:"/images/company_scene_03.jpg",tech_concept:"/images/商务科技概念图.png",circuit_background:"/images/科技电路背景图.png",business_office:"/images/business_office_scene.jpg"},about:{office_scene:"/images/company_scene_01.jpg",team_photo:"/images/company_scene_05.jpg",company_culture:"/images/company_scene_06.jpg"},business:{advanced_packaging:"/images/company_scene_07.jpg",hardware_solution:"/images/company_scene_08.jpg",testing_service:"/images/company_scene_09.jpg",production_line:"/images/company_scene_10.jpg"},technology:{lab_equipment:"/images/business_office_scene.jpg",pcb_design:"/images/company_scene_12.jpg",testing_facility:"/images/icon_hardware_design.png",advanced_tech:"/images/technical_chart_circuit.jpg"},cases:{automotive:"/images/company_scene_07.jpg",consumer:"/images/company_scene_08.jpg",industrial:"/images/company_scene_09.jpg",communication:"/images/company_scene_10.jpg"},news:{news_4:"/images/news/第四届全国辐射探测微电子学术年会.png",news_1:"/images/iso_certification_news.png",news_2:"/images/company_scene_05.jpg",news_3:"/images/ICEPT2024.png",company_event:"/images/company_scene_11.jpg"},certificates:{iso9001:"/images/ISO9001质量管理体系认证证书.png",military:"/images/武器装备质量管理体系证书.png"},customers:{avatar_1:"/images/business_office_scene.jpg",avatar_2:"/images/modern_buildings_night_scene.jpg",avatar_3:"/images/product_development_cycle_chart.jpg",avatar_4:"/images/ISO9001质量管理体系认证证书.png"},partners:{sjtu:"/images/partner_sjtu.png",zju:"/images/partner_zju.png",fzu:"/images/partner_fzu.png",xidian:"/images/partner_xidian.png",ihep_cas:"/images/partner_ihep_cas.png",norinco:"/images/partner_norinco.jpg",cetc:"/images/partner_cetc.png",casc:"/images/partner_casc.png"},partnerLogos:{sjtu:"/images/logo_sjtu.png",zju:"/images/logo_zju.png",fzu:"/images/logo_fzu.png",xidian:"/images/logo_xidian.png",ihep_cas:"/images/logo_ihep_cas.png",norinco:"/images/logo_norinco.png",cetc:"/images/logo_cetc.png",casc:"/images/logo_casc.png"}};function et(e,a,i="business"){try{const t=Oe[e];return t&&t[a]?t[a]:O[i]||O.business}catch(t){return O[i]||O.business}}function tt(e,a={}){const{immediate:i=!1,resetOnExecute:t=!0,shallow:n=!0,delay:o=0,onError:u=null,onSuccess:l=null}=a,s=D(!1),c=D(!1),h=D(null),m=D(null),y=k(()=>c.value&&!h.value),g=k(()=>!!h.value),b=(...S)=>H(this,null,function*(){t&&(m.value=null,h.value=null),s.value=!0,c.value=!1;try{o>0&&(yield new Promise(z=>setTimeout(z,o)));const f=yield e(...S);return m.value=n?f:JSON.parse(JSON.stringify(f)),l&&l(f),f}catch(f){throw h.value=f,u&&u(f),f}finally{s.value=!1,c.value=!0}}),d=(...S)=>b(...S),w=()=>{s.value=!1,c.value=!1,h.value=null,m.value=null};return i&&b(),{isLoading:s,isFinished:c,isReady:y,hasError:g,error:h,data:m,execute:b,retry:d,reset:w}}const We={class:"loading-state"},Le={key:0,class:"skeleton-container"},Te={key:0,class:"skeleton-card"},qe={key:1,class:"skeleton-list"},Ee={style:{flex:"1"}},Ae={key:2,class:"skeleton-article"},Ve={key:3,class:"skeleton-grid"},He={key:4,class:"skeleton-custom"},Me={key:1,class:"spinner-container"},Ge={key:0,class:"loading-message"},Xe={key:2,class:"progress-container"},Ye={key:0,class:"loading-message"},Fe={key:3,class:"custom-container"},Je={class:"loading-message"},Ke={__name:"LoadingState",props:{type:{type:String,default:"skeleton",validator:e=>["skeleton","spinner","progress","custom"].includes(e)},variant:{type:String,default:"card",validator:e=>["card","list","article","grid","custom"].includes(e)},message:{type:String,default:""},spinnerSize:{type:String,default:"medium",validator:e=>["small","medium","large"].includes(e)},percentage:{type:Number,default:0,validator:e=>e>=0&&e<=100},showPercentage:{type:Boolean,default:!0},progressStatus:{type:String,default:"default",validator:e=>["default","success","error","warning"].includes(e)},rows:{type:Number,default:3},gridItems:{type:Number,default:6},minHeight:{type:String,default:"200px"}},setup(e){return he(a=>({c03881ba:e.minHeight})),me(),(a,i)=>{const t=je,n=De,o=fe,u=$e;return _(),x("div",We,[e.type==="skeleton"?(_(),x("div",Le,[e.variant==="card"?(_(),x("div",Te,[v(t,{height:"200px",style:{"margin-bottom":"16px"}}),v(t,{text:"",repeat:3}),v(t,{text:"",style:{width:"60%","margin-top":"8px"}})])):e.variant==="list"?(_(),x("div",qe,[(_(!0),x(A,null,M(e.rows,l=>(_(),x("div",{key:l,class:"skeleton-list-item"},[v(t,{circle:"",size:"medium",style:{"margin-right":"16px"}}),G("div",Ee,[v(t,{text:"",style:{width:"80%","margin-bottom":"8px"}}),v(t,{text:"",style:{width:"60%"}})])]))),128))])):e.variant==="article"?(_(),x("div",Ae,[v(t,{text:"",style:{width:"80%",height:"32px","margin-bottom":"16px"}}),v(t,{text:"",style:{width:"60%","margin-bottom":"24px"}}),v(t,{height:"200px",style:{"margin-bottom":"16px"}}),v(t,{text:"",repeat:4})])):e.variant==="grid"?(_(),x("div",Ve,[(_(!0),x(A,null,M(e.gridItems,l=>(_(),x("div",{key:l,class:"skeleton-grid-item"},[v(t,{height:"150px",style:{"margin-bottom":"12px"}}),v(t,{text:"",style:{"margin-bottom":"8px"}}),v(t,{text:"",style:{width:"70%"}})]))),128))])):(_(),x("div",He,[X(a.$slots,"skeleton",{},()=>[v(t,{text:"",repeat:3})],!0)]))])):e.type==="spinner"?(_(),x("div",Me,[v(o,{vertical:"",align:"center",size:20},{default:T(()=>[v(n,{size:e.spinnerSize},null,8,["size"]),e.message?(_(),x("div",Ge,q(e.message),1)):Y("",!0)]),_:1})])):e.type==="progress"?(_(),x("div",Xe,[v(o,{vertical:"",size:16},{default:T(()=>[e.message?(_(),x("div",Ye,q(e.message),1)):Y("",!0),v(u,{type:"line",percentage:e.percentage,"show-indicator":e.showPercentage,status:e.progressStatus},null,8,["percentage","show-indicator","status"])]),_:1})])):(_(),x("div",Fe,[X(a.$slots,"loading",{},()=>[v(o,{vertical:"",align:"center",size:20},{default:T(()=>[v(n,{size:"large"}),G("div",Je,q(e.message||a.$t("common.loading")),1)]),_:1})],!0)]))])}}},rt=pe(Ke,[["__scopeId","data-v-ab2492bf"]]);export{rt as L,O as P,De as _,$e as a,et as g,tt as u};
