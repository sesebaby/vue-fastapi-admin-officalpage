var Be=(e,n,i)=>new Promise((s,a)=>{var r=f=>{try{c(i.next(f))}catch(h){a(h)}},p=f=>{try{c(i.throw(f))}catch(h){a(h)}},c=f=>f.done?s(f.value):Promise.resolve(f.value).then(r,p);c((i=i.apply(e,n)).next())});import{Q as Vn,R as Hn,S as Wn,T as An,k as D,l as N,d as Q,u as ne,U as qn,E as j,e as P,J as ge,V as tt,j as v,W as Fn,X as _t,Y as qt,Z as A,$ as Ft,a0 as O,a1 as Qe,a as Z,a2 as Yn,a3 as Xn,f as $e,n as pe,a4 as Yt,a5 as bt,a6 as Ve,a7 as Un,a8 as Kn,a9 as ht,aa as Xt,ab as Ut,ac as Kt,ad as Gn,ae as Zn,af as Nt,ag as Gt,ah as yt,ai as Jn,aj as et,ak as Qn,i as eo,al as Et,am as Zt,an as Jt,ao as Qt,ap as ze,aq as to,ar as De,as as Le,at as en,b as tn,au as no,av as Ne,aw as wt,ax as nn,ay as on,az as sn,aA as an,aB as oo,aC as so,aD as io,C as ue,aE as Mt,aF as vt,aG as ao,aH as ro,F as ce,aI as lo,aJ as co,aK as rn,aL as uo,aM as fo,aN as ln,_ as se,aO as go,K as nt,q as E,x as L,s as t,w as o,A as l,L as V,o as he,D as po,v as k,B as b,aP as cn,N as Se,aQ as _e,G as ve,H as me,aR as ho,t as Ke,r as oe,y as fe,aS as xt,I as dn,aT as vo,aU as mo,aV as mt,aW as _o,aX as bo,aY as yo,M as wo}from"./index-ef304653.js";import{o as xo,i as $o,N as ke}from"./Image-4383e496.js";import{_ as $t}from"./Statistic-7b10b76f.js";import{N as Ce,a as Re,c as zo,b as So}from"./Grid-3c07ebe3.js";import{N as ae}from"./Space-40270cc1.js";import{_ as ko}from"./Divider-b5dfd28a.js";import{_ as ot}from"./Result-1b3bc025.js";import{_ as Co}from"./Ellipsis-76e40001.js";import{u as Ro,_ as Po}from"./BackTop-b8848e0f.js";import"./use-locale-1c850f30.js";import"./download-953ccaa2.js";let Ot=!1;function Io(){if(Vn&&window.CSS&&!Ot&&(Ot=!0,"registerProperty"in(window==null?void 0:window.CSS)))try{CSS.registerProperty({name:"--n-color-start",syntax:"<color>",inherits:!1,initialValue:"#0000"}),CSS.registerProperty({name:"--n-color-end",syntax:"<color>",inherits:!1,initialValue:"#0000"})}catch(e){}}function To(e){return Hn(Wn(e).toLowerCase())}var jo=An(function(e,n,i){return n=n.toLowerCase(),e+(i?To(n):n)});const Dt=jo;function Bo(e){return e instanceof HTMLElement?e.scrollTop:window.scrollY}function No(e){return e instanceof HTMLElement?e.getBoundingClientRect():{top:0,bottom:window.innerHeight}}const Eo=D("affix",[N("affixed",{position:"fixed"},[N("absolute-positioned",{position:"absolute"})])]),Mo={listenTo:[String,Object,Function],top:Number,bottom:Number,triggerTop:Number,triggerBottom:Number,position:{type:String,default:"fixed"},offsetTop:{type:Number,validator:()=>!0,default:void 0},offsetBottom:{type:Number,validator:()=>!0,default:void 0},target:{type:Function,validator:()=>!0,default:void 0}},Oo=Q({name:"Affix",props:Mo,setup(e){const{mergedClsPrefixRef:n}=ne(e);qn("-affix",Eo,n);let i=null;const s=j(!1),a=j(!1),r=j(null),p=j(null),c=P(()=>a.value||s.value),f=P(()=>{var C,g;return(g=(C=e.triggerTop)!==null&&C!==void 0?C:e.offsetTop)!==null&&g!==void 0?g:e.top}),h=P(()=>{var C,g;return(g=(C=e.top)!==null&&C!==void 0?C:e.triggerTop)!==null&&g!==void 0?g:e.offsetTop}),d=P(()=>{var C,g;return(g=(C=e.bottom)!==null&&C!==void 0?C:e.triggerBottom)!==null&&g!==void 0?g:e.offsetBottom}),x=P(()=>{var C,g;return(g=(C=e.triggerBottom)!==null&&C!==void 0?C:e.offsetBottom)!==null&&g!==void 0?g:e.bottom}),_=j(null),$=()=>{const{target:C,listenTo:g}=e;C?i=C():g?i=Ro(g):i=document,i&&(i.addEventListener("scroll",y),y())};function y(){Fn(z)}function z(){const{value:C}=_;if(!i||!C)return;const g=Bo(i);if(c.value){p.value!==null&&g<p.value&&(s.value=!1,p.value=null),r.value!==null&&g>r.value&&(a.value=!1,r.value=null);return}const u=No(i),w=C.getBoundingClientRect(),S=w.top-u.top,I=u.bottom-w.bottom,T=f.value,B=x.value;T!==void 0&&S<=T?(s.value=!0,p.value=g-(T-S)):(s.value=!1,p.value=null),B!==void 0&&I<=B?(a.value=!0,r.value=g+B-I):(a.value=!1,r.value=null)}return ge(()=>{$()}),tt(()=>{i&&i.removeEventListener("scroll",y)}),{selfRef:_,affixed:c,mergedClsPrefix:n,mergedstyle:P(()=>{const C={};return s.value&&f.value!==void 0&&h.value!==void 0&&(C.top=`${h.value}px`),a.value&&x.value!==void 0&&d.value!==void 0&&(C.bottom=`${d.value}px`),C})}},render(){const{mergedClsPrefix:e}=this;return v("div",{ref:"selfRef",class:[`${e}-affix`,{[`${e}-affix--affixed`]:this.affixed,[`${e}-affix--absolute-positioned`]:this.position==="absolute"}],style:this.mergedstyle},this.$slots)}}),Do=_t("n-avatar-group"),Lo=D("avatar",`
 width: var(--n-merged-size);
 height: var(--n-merged-size);
 color: #FFF;
 font-size: var(--n-font-size);
 display: inline-flex;
 position: relative;
 overflow: hidden;
 text-align: center;
 border: var(--n-border);
 border-radius: var(--n-border-radius);
 --n-merged-color: var(--n-color);
 background-color: var(--n-merged-color);
 transition:
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[qt(A("&","--n-merged-color: var(--n-color-modal);")),Ft(A("&","--n-merged-color: var(--n-color-popover);")),A("img",`
 width: 100%;
 height: 100%;
 `),O("text",`
 white-space: nowrap;
 display: inline-block;
 position: absolute;
 left: 50%;
 top: 50%;
 `),D("icon",`
 vertical-align: bottom;
 font-size: calc(var(--n-merged-size) - 6px);
 `),O("text","line-height: 1.25")]),Vo=Object.assign(Object.assign({},Z.props),{size:[String,Number],src:String,circle:{type:Boolean,default:void 0},objectFit:String,round:{type:Boolean,default:void 0},bordered:{type:Boolean,default:void 0},onError:Function,fallbackSrc:String,intersectionObserverOptions:Object,lazy:Boolean,onLoad:Function,renderPlaceholder:Function,renderFallback:Function,imgProps:Object,color:String}),zt=Q({name:"Avatar",props:Vo,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:i}=ne(e),s=j(!1);let a=null;const r=j(null),p=j(null),c=()=>{const{value:u}=r;if(u&&(a===null||a!==u.innerHTML)){a=u.innerHTML;const{value:w}=p;if(w){const{offsetWidth:S,offsetHeight:I}=w,{offsetWidth:T,offsetHeight:B}=u,F=.9,te=Math.min(S/T*F,I/B*F,1);u.style.transform=`translateX(-50%) translateY(-50%) scale(${te})`}}},f=Qe(Do,null),h=P(()=>{const{size:u}=e;if(u)return u;const{size:w}=f||{};return w||"medium"}),d=Z("Avatar","-avatar",Lo,Yn,e,n),x=Qe(Xn,null),_=P(()=>{if(f)return!0;const{round:u,circle:w}=e;return u!==void 0||w!==void 0?u||w:x?x.roundRef.value:!1}),$=P(()=>f?!0:e.bordered||!1),y=P(()=>{const u=h.value,w=_.value,S=$.value,{color:I}=e,{self:{borderRadius:T,fontSize:B,color:F,border:te,colorModal:J,colorPopover:X},common:{cubicBezierEaseInOut:K}}=d.value;let re;return typeof u=="number"?re=`${u}px`:re=d.value.self[$e("height",u)],{"--n-font-size":B,"--n-border":S?te:"none","--n-border-radius":w?"50%":T,"--n-color":I||F,"--n-color-modal":I||J,"--n-color-popover":I||X,"--n-bezier":K,"--n-merged-size":`var(--n-avatar-size-override, ${re})`}}),z=i?pe("avatar",P(()=>{const u=h.value,w=_.value,S=$.value,{color:I}=e;let T="";return u&&(typeof u=="number"?T+=`a${u}`:T+=u[0]),w&&(T+="b"),S&&(T+="c"),I&&(T+=Yt(I)),T}),y,e):void 0,C=j(!e.lazy);ge(()=>{if(e.lazy&&e.intersectionObserverOptions){let u;const w=bt(()=>{u==null||u(),u=void 0,e.lazy&&(u=xo(p.value,e.intersectionObserverOptions,C))});tt(()=>{w(),u==null||u()})}}),Ve(()=>{var u;return e.src||((u=e.imgProps)===null||u===void 0?void 0:u.src)},()=>{s.value=!1});const g=j(!e.lazy);return{textRef:r,selfRef:p,mergedRoundRef:_,mergedClsPrefix:n,fitTextTransform:c,cssVars:i?void 0:y,themeClass:z==null?void 0:z.themeClass,onRender:z==null?void 0:z.onRender,hasLoadError:s,shouldStartLoading:C,loaded:g,mergedOnError:u=>{if(!C.value)return;s.value=!0;const{onError:w,imgProps:{onError:S}={}}=e;w==null||w(u),S==null||S(u)},mergedOnLoad:u=>{const{onLoad:w,imgProps:{onLoad:S}={}}=e;w==null||w(u),S==null||S(u),g.value=!0}}},render(){var e,n;const{$slots:i,src:s,mergedClsPrefix:a,lazy:r,onRender:p,loaded:c,hasLoadError:f,imgProps:h={}}=this;p==null||p();let d;const x=!c&&!f&&(this.renderPlaceholder?this.renderPlaceholder():(n=(e=this.$slots).placeholder)===null||n===void 0?void 0:n.call(e));return this.hasLoadError?d=this.renderFallback?this.renderFallback():Un(i.fallback,()=>[v("img",{src:this.fallbackSrc,style:{objectFit:this.objectFit}})]):d=Kn(i.default,_=>{if(_)return v(ht,{onResize:this.fitTextTransform},{default:()=>v("span",{ref:"textRef",class:`${a}-avatar__text`},_)});if(s||h.src){const $=this.src||h.src;return v("img",Object.assign(Object.assign({},h),{loading:$o&&!this.intersectionObserverOptions&&r?"lazy":"eager",src:r&&this.intersectionObserverOptions?this.shouldStartLoading?$:void 0:$,"data-image-src":$,onLoad:this.mergedOnLoad,onError:this.mergedOnError,style:[h.style||"",{objectFit:this.objectFit},x?{height:"0",width:"0",visibility:"hidden",position:"absolute"}:""]}))}}),v("span",{ref:"selfRef",class:[`${a}-avatar`,this.themeClass],style:this.cssVars},d,r&&x)}});function Ho(e){const{length:n}=e;return n>1&&(e.push(Lt(e[0],0,"append")),e.unshift(Lt(e[n-1],n-1,"prepend"))),e}function Lt(e,n,i){return Xt(e,{key:`carousel-item-duplicate-${n}-${i}`})}function Vt(e,n,i){return n===1?0:i?e===0?n-3:e===n-1?0:e-1:e}function ft(e,n){return n?e+1:e}function Wo(e,n,i){return e<0?null:e===0?i?n-1:null:e-1}function Ao(e,n,i){return e>n-1?null:e===n-1?i?0:null:e+1}function qo(e,n){return n&&e>3?e-2:e}function Ht(e){return window.TouchEvent&&e instanceof window.TouchEvent}function Wt(e,n){let{offsetWidth:i,offsetHeight:s}=e;if(n){const a=getComputedStyle(e);i=i-Number.parseFloat(a.getPropertyValue("padding-left"))-Number.parseFloat(a.getPropertyValue("padding-right")),s=s-Number.parseFloat(a.getPropertyValue("padding-top"))-Number.parseFloat(a.getPropertyValue("padding-bottom"))}return{width:i,height:s}}function Ge(e,n,i){return e<n?n:e>i?i:e}function Fo(e){if(e===void 0)return 0;if(typeof e=="number")return e;const n=/^((\d+)?\.?\d+?)(ms|s)?$/,i=e.match(n);if(i){const[,s,,a="ms"]=i;return Number(s)*(a==="ms"?1:1e3)}return 0}const un=_t("n-carousel-methods");function Yo(e){Ut(un,e)}function St(e="unknown",n="component"){const i=Qe(un);return i||Kt(e,`\`${n}\` must be placed inside \`n-carousel\`.`),i}const Xo={total:{type:Number,default:0},currentIndex:{type:Number,default:0},dotType:{type:String,default:"dot"},trigger:{type:String,default:"click"},keyboard:Boolean},Uo=Q({name:"CarouselDots",props:Xo,setup(e){const{mergedClsPrefixRef:n}=ne(e),i=j([]),s=St();function a(h,d){switch(h.key){case"Enter":case" ":h.preventDefault(),s.to(d);return}e.keyboard&&c(h)}function r(h){e.trigger==="hover"&&s.to(h)}function p(h){e.trigger==="click"&&s.to(h)}function c(h){var d;if(h.shiftKey||h.altKey||h.ctrlKey||h.metaKey)return;const x=(d=document.activeElement)===null||d===void 0?void 0:d.nodeName.toLowerCase();if(x==="input"||x==="textarea")return;const{code:_}=h,$=_==="PageUp"||_==="ArrowUp",y=_==="PageDown"||_==="ArrowDown",z=_==="PageUp"||_==="ArrowRight",C=_==="PageDown"||_==="ArrowLeft",g=s.isVertical(),u=g?$:z,w=g?y:C;!u&&!w||(h.preventDefault(),u&&!s.isNextDisabled()?(s.next(),f(s.currentIndexRef.value)):w&&!s.isPrevDisabled()&&(s.prev(),f(s.currentIndexRef.value)))}function f(h){var d;(d=i.value[h])===null||d===void 0||d.focus()}return Gn(()=>i.value.length=0),{mergedClsPrefix:n,dotEls:i,handleKeydown:a,handleMouseenter:r,handleClick:p}},render(){const{mergedClsPrefix:e,dotEls:n}=this;return v("div",{class:[`${e}-carousel__dots`,`${e}-carousel__dots--${this.dotType}`],role:"tablist"},Zn(this.total,i=>{const s=i===this.currentIndex;return v("div",{"aria-selected":s,ref:a=>n.push(a),role:"button",tabindex:"0",class:[`${e}-carousel__dot`,s&&`${e}-carousel__dot--active`],key:i,onClick:()=>{this.handleClick(i)},onMouseenter:()=>{this.handleMouseenter(i)},onKeydown:a=>{this.handleKeydown(a,i)}})}))}}),Ko=v("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},v("g",{fill:"none"},v("path",{d:"M10.26 3.2a.75.75 0 0 1 .04 1.06L6.773 8l3.527 3.74a.75.75 0 1 1-1.1 1.02l-4-4.25a.75.75 0 0 1 0-1.02l4-4.25a.75.75 0 0 1 1.06-.04z",fill:"currentColor"}))),Go=v("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},v("g",{fill:"none"},v("path",{d:"M5.74 3.2a.75.75 0 0 0-.04 1.06L9.227 8L5.7 11.74a.75.75 0 1 0 1.1 1.02l4-4.25a.75.75 0 0 0 0-1.02l-4-4.25a.75.75 0 0 0-1.06-.04z",fill:"currentColor"}))),Zo=Q({name:"CarouselArrow",setup(e){const{mergedClsPrefixRef:n}=ne(e),{isVertical:i,isPrevDisabled:s,isNextDisabled:a,prev:r,next:p}=St();return{mergedClsPrefix:n,isVertical:i,isPrevDisabled:s,isNextDisabled:a,prev:r,next:p}},render(){const{mergedClsPrefix:e}=this;return v("div",{class:`${e}-carousel__arrow-group`},v("div",{class:[`${e}-carousel__arrow`,this.isPrevDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.prev},Ko),v("div",{class:[`${e}-carousel__arrow`,this.isNextDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.next},Go))}}),Je="CarouselItem";function Jo(e){var n;return((n=e.type)===null||n===void 0?void 0:n.name)===Je}const Qo=Q({name:Je,setup(e){const{mergedClsPrefixRef:n}=ne(e),i=St(Dt(Je),`n-${Dt(Je)}`),s=j(),a=P(()=>{const{value:d}=s;return d?i.getSlideIndex(d):-1}),r=P(()=>i.isPrev(a.value)),p=P(()=>i.isNext(a.value)),c=P(()=>i.isActive(a.value)),f=P(()=>i.getSlideStyle(a.value));ge(()=>{i.addSlide(s.value)}),tt(()=>{i.removeSlide(s.value)});function h(d){const{value:x}=a;x!==void 0&&(i==null||i.onCarouselItemClick(x,d))}return{mergedClsPrefix:n,selfElRef:s,isPrev:r,isNext:p,isActive:c,index:a,style:f,handleClick:h}},render(){var e;const{$slots:n,mergedClsPrefix:i,isPrev:s,isNext:a,isActive:r,index:p,style:c}=this,f=[`${i}-carousel__slide`,{[`${i}-carousel__slide--current`]:r,[`${i}-carousel__slide--prev`]:s,[`${i}-carousel__slide--next`]:a}];return v("div",{ref:"selfElRef",class:f,role:"option",tabindex:"-1","data-index":p,"aria-hidden":!r,style:c,onClickCapture:this.handleClick},(e=n.default)===null||e===void 0?void 0:e.call(n,{isPrev:s,isNext:a,isActive:r,index:p}))}}),es=D("carousel",`
 position: relative;
 width: 100%;
 height: 100%;
 touch-action: pan-y;
 overflow: hidden;
`,[O("slides",`
 display: flex;
 width: 100%;
 height: 100%;
 transition-timing-function: var(--n-bezier);
 transition-property: transform;
 `,[O("slide",`
 flex-shrink: 0;
 position: relative;
 width: 100%;
 height: 100%;
 outline: none;
 overflow: hidden;
 `,[A("> img",`
 display: block;
 `)])]),O("dots",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `,[N("dot",[O("dot",`
 height: var(--n-dot-size);
 width: var(--n-dot-size);
 background-color: var(--n-dot-color);
 border-radius: 50%;
 cursor: pointer;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[A("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),N("active",`
 background-color: var(--n-dot-color-active);
 `)])]),N("line",[O("dot",`
 border-radius: 9999px;
 width: var(--n-dot-line-width);
 height: 4px;
 background-color: var(--n-dot-color);
 cursor: pointer;
 transition:
 width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[A("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),N("active",`
 width: var(--n-dot-line-width-active);
 background-color: var(--n-dot-color-active);
 `)])])]),O("arrow",`
 transition: background-color .3s var(--n-bezier);
 cursor: pointer;
 height: 28px;
 width: 28px;
 display: flex;
 align-items: center;
 justify-content: center;
 background-color: rgba(255, 255, 255, .2);
 color: var(--n-arrow-color);
 border-radius: 8px;
 user-select: none;
 -webkit-user-select: none;
 font-size: 18px;
 `,[A("svg",`
 height: 1em;
 width: 1em;
 `),A("&:hover",`
 background-color: rgba(255, 255, 255, .3);
 `)]),N("vertical",`
 touch-action: pan-x;
 `,[O("slides",`
 flex-direction: column;
 `),N("fade",[O("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%);
 `)]),N("card",[O("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%) translateZ(-400px);
 `,[N("current",`
 transform: translateY(-50%) translateZ(0);
 `),N("prev",`
 transform: translateY(-100%) translateZ(-200px);
 `),N("next",`
 transform: translateY(0%) translateZ(-200px);
 `)])])]),N("usercontrol",[O("slides",[A(">",[A("div",`
 position: absolute;
 top: 50%;
 left: 50%;
 width: 100%;
 height: 100%;
 transform: translate(-50%, -50%);
 `)])])]),N("left",[O("dots",`
 transform: translateY(-50%);
 top: 50%;
 left: 12px;
 flex-direction: column;
 `,[N("line",[O("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[N("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),O("dot",`
 margin: 4px 0;
 `)]),O("arrow-group",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `),N("vertical",[O("arrow",`
 transform: rotate(90deg);
 `)]),N("show-arrow",[N("bottom",[O("dots",`
 transform: translateX(0);
 bottom: 18px;
 left: 18px;
 `)]),N("top",[O("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),N("left",[O("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),N("right",[O("dots",`
 transform: translateX(0);
 top: 18px;
 right: 18px;
 `)])]),N("left",[O("arrow-group",`
 bottom: 12px;
 left: 12px;
 flex-direction: column;
 `,[A("> *:first-child",`
 margin-bottom: 12px;
 `)])]),N("right",[O("dots",`
 transform: translateY(-50%);
 top: 50%;
 right: 12px;
 flex-direction: column;
 `,[N("line",[O("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[N("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),O("dot",`
 margin: 4px 0;
 `),O("arrow-group",`
 bottom: 12px;
 right: 12px;
 flex-direction: column;
 `,[A("> *:first-child",`
 margin-bottom: 12px;
 `)])]),N("top",[O("dots",`
 transform: translateX(-50%);
 top: 12px;
 left: 50%;
 `,[N("line",[O("dot",`
 margin: 0 4px;
 `)])]),O("dot",`
 margin: 0 4px;
 `),O("arrow-group",`
 top: 12px;
 right: 12px;
 `,[A("> *:first-child",`
 margin-right: 12px;
 `)])]),N("bottom",[O("dots",`
 transform: translateX(-50%);
 bottom: 12px;
 left: 50%;
 `,[N("line",[O("dot",`
 margin: 0 4px;
 `)])]),O("dot",`
 margin: 0 4px;
 `),O("arrow-group",`
 bottom: 12px;
 right: 12px;
 `,[A("> *:first-child",`
 margin-right: 12px;
 `)])]),N("fade",[O("slide",`
 position: absolute;
 opacity: 0;
 transition-property: opacity;
 pointer-events: none;
 `,[N("current",`
 opacity: 1;
 pointer-events: auto;
 `)])]),N("card",[O("slides",`
 perspective: 1000px;
 `),O("slide",`
 position: absolute;
 left: 50%;
 opacity: 0;
 transform: translateX(-50%) translateZ(-400px);
 transition-property: opacity, transform;
 `,[N("current",`
 opacity: 1;
 transform: translateX(-50%) translateZ(0);
 z-index: 1;
 `),N("prev",`
 opacity: 0.4;
 transform: translateX(-100%) translateZ(-200px);
 `),N("next",`
 opacity: 0.4;
 transform: translateX(0%) translateZ(-200px);
 `)])])]),ts=["transitionDuration","transitionTimingFunction"],ns=Object.assign(Object.assign({},Z.props),{defaultIndex:{type:Number,default:0},currentIndex:Number,showArrow:Boolean,dotType:{type:String,default:"dot"},dotPlacement:{type:String,default:"bottom"},slidesPerView:{type:[Number,String],default:1},spaceBetween:{type:Number,default:0},centeredSlides:Boolean,direction:{type:String,default:"horizontal"},autoplay:Boolean,interval:{type:Number,default:5e3},loop:{type:Boolean,default:!0},effect:{type:String,default:"slide"},showDots:{type:Boolean,default:!0},trigger:{type:String,default:"click"},transitionStyle:{type:Object,default:()=>({transitionDuration:"300ms"})},transitionProps:Object,draggable:Boolean,prevSlideStyle:[Object,String],nextSlideStyle:[Object,String],touchable:{type:Boolean,default:!0},mousewheel:Boolean,keyboard:Boolean,"onUpdate:currentIndex":Function,onUpdateCurrentIndex:Function});let gt=!1;const fn=Q({name:"Carousel",props:ns,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:i}=ne(e),s=j(null),a=j(null),r=j([]),p={value:[]},c=P(()=>e.direction==="vertical"),f=P(()=>c.value?"height":"width"),h=P(()=>c.value?"bottom":"right"),d=P(()=>e.effect==="slide"),x=P(()=>e.loop&&e.slidesPerView===1&&d.value),_=P(()=>e.effect==="custom"),$=P(()=>!d.value||e.centeredSlides?1:e.slidesPerView),y=P(()=>_.value?1:e.slidesPerView),z=P(()=>$.value==="auto"||e.slidesPerView==="auto"&&e.centeredSlides),C=j({width:0,height:0}),g=P(()=>{const{value:m}=r;if(!m.length)return[];const{value:R}=z;if(R)return m.map(G=>Wt(G));const{value:M}=y,{value:W}=C,{value:q}=f;let H=W[q];if(M!=="auto"){const{spaceBetween:G}=e,ie=H-(M-1)*G,Ue=1/Math.max(1,M);H=ie*Ue}const U=Object.assign(Object.assign({},W),{[q]:H});return m.map(()=>U)}),u=P(()=>{const{value:m}=g;if(!m.length)return[];const{centeredSlides:R,spaceBetween:M}=e,{value:W}=f,{[W]:q}=C.value;let H=0;return m.map(({[W]:U})=>{let G=H;return R&&(G+=(U-q)/2),H+=U+M,G})}),w=j(!1),S=P(()=>{const{transitionStyle:m}=e;return m?Nt(m,ts):{}}),I=P(()=>_.value?0:Fo(S.value.transitionDuration)),T=P(()=>{const{value:m}=r;if(!m.length)return[];const R=!(z.value||y.value===1),M=U=>{if(R){const{value:G}=f;return{[G]:`${g.value[U][G]}px`}}};if(_.value)return m.map((U,G)=>M(G));const{effect:W,spaceBetween:q}=e,{value:H}=h;return m.reduce((U,G,ie)=>{const Ue=Object.assign(Object.assign({},M(ie)),{[`margin-${H}`]:`${q}px`});return U.push(Ue),w.value&&(W==="fade"||W==="card")&&Object.assign(Ue,S.value),U},[])}),B=P(()=>{const{value:m}=$,{length:R}=r.value;if(m!=="auto")return Math.max(R-m,0)+1;{const{value:M}=g,{length:W}=M;if(!W)return R;const{value:q}=u,{value:H}=f,U=C.value[H];let G=M[M.length-1][H],ie=W;for(;ie>1&&G<U;)ie--,G+=q[ie]-q[ie-1];return Ge(ie+1,1,W)}}),F=P(()=>qo(B.value,x.value)),te=ft(e.defaultIndex,x.value),J=j(Vt(te,B.value,x.value)),X=Gt(yt(e,"currentIndex"),J),K=P(()=>ft(X.value,x.value));function re(m){var R,M;m=Ge(m,0,B.value-1);const W=Vt(m,B.value,x.value),{value:q}=X;W!==X.value&&(J.value=W,(R=e["onUpdate:currentIndex"])===null||R===void 0||R.call(e,W,q),(M=e.onUpdateCurrentIndex)===null||M===void 0||M.call(e,W,q))}function Ee(m=K.value){return Wo(m,B.value,e.loop)}function He(m=K.value){return Ao(m,B.value,e.loop)}function yn(m){const R=Pe(m);return R!==null&&Ee()===R}function wn(m){const R=Pe(m);return R!==null&&He()===R}function kt(m){return K.value===Pe(m)}function xn(m){return X.value===m}function Ct(){return Ee()===null}function Rt(){return He()===null}function st(m){const R=Ge(ft(m,x.value),0,B.value);(m!==X.value||R!==K.value)&&re(R)}function it(){const m=Ee();m!==null&&re(m)}function We(){const m=He();m!==null&&re(m)}let le=!1;function $n(){(!le||!x.value)&&it()}function zn(){(!le||!x.value)&&We()}let xe=0;const at=j({});function Ae(m,R=0){at.value=Object.assign({},S.value,{transform:c.value?`translateY(${-m}px)`:`translateX(${-m}px)`,transitionDuration:`${R}ms`})}function Me(m=0){d.value?rt(K.value,m):xe!==0&&(!le&&m>0&&(le=!0),Ae(xe=0,m))}function rt(m,R){const M=Pt(m);M!==xe&&R>0&&(le=!0),xe=Pt(K.value),Ae(M,R)}function Pt(m){let R;return m>=B.value-1?R=It():R=u.value[m]||0,R}function It(){if($.value==="auto"){const{value:m}=f,{[m]:R}=C.value,{value:M}=u,W=M[M.length-1];let q;if(W===void 0)q=R;else{const{value:H}=g;q=W+H[H.length-1][m]}return q-R}else{const{value:m}=u;return m[B.value-1]||0}}const Oe={currentIndexRef:X,to:st,prev:$n,next:zn,isVertical:()=>c.value,isHorizontal:()=>!c.value,isPrev:yn,isNext:wn,isActive:kt,isPrevDisabled:Ct,isNextDisabled:Rt,getSlideIndex:Pe,getSlideStyle:Cn,addSlide:Sn,removeSlide:kn,onCarouselItemClick:Rn};Yo(Oe);function Sn(m){m&&r.value.push(m)}function kn(m){if(!m)return;const R=Pe(m);R!==-1&&r.value.splice(R,1)}function Pe(m){return typeof m=="number"?m:m?r.value.indexOf(m):-1}function Cn(m){const R=Pe(m);if(R!==-1){const M=[T.value[R]],W=Oe.isPrev(R),q=Oe.isNext(R);return W&&M.push(e.prevSlideStyle||""),q&&M.push(e.nextSlideStyle||""),ze(M)}}let lt=0,ct=0,de=0,dt=0,qe=!1,ut=!1;function Rn(m,R){let M=!le&&!qe&&!ut;e.effect==="card"&&M&&!kt(m)&&(st(m),M=!1),M||(R.preventDefault(),R.stopPropagation())}let Fe=null;function Ye(){Fe&&(clearInterval(Fe),Fe=null)}function Ie(){Ye(),!e.autoplay||F.value<2||(Fe=window.setInterval(We,e.interval))}function Tt(m){var R;if(gt||!(!((R=a.value)===null||R===void 0)&&R.contains(to(m))))return;gt=!0,qe=!0,ut=!1,dt=Date.now(),Ye(),m.type!=="touchstart"&&!m.target.isContentEditable&&m.preventDefault();const M=Ht(m)?m.touches[0]:m;c.value?ct=M.clientY:lt=M.clientX,e.touchable&&(De("touchmove",document,Xe),De("touchend",document,Te),De("touchcancel",document,Te)),e.draggable&&(De("mousemove",document,Xe),De("mouseup",document,Te))}function Xe(m){const{value:R}=c,{value:M}=f,W=Ht(m)?m.touches[0]:m,q=R?W.clientY-ct:W.clientX-lt,H=C.value[M];de=Ge(q,-H,H),m.cancelable&&m.preventDefault(),d.value&&Ae(xe-de,0)}function Te(){const{value:m}=K;let R=m;if(!le&&de!==0&&d.value){const M=xe-de,W=[...u.value.slice(0,B.value-1),It()];let q=null;for(let H=0;H<W.length;H++){const U=Math.abs(W[H]-M);if(q!==null&&q<U)break;q=U,R=H}}if(R===m){const M=Date.now()-dt,{value:W}=f,q=C.value[W];de>q/2||de/M>.4?R=Ee(m):(de<-q/2||de/M<-.4)&&(R=He(m))}R!==null&&R!==m?(ut=!0,re(R),et(()=>{(!x.value||J.value!==X.value)&&Me(I.value)})):Me(I.value),jt(),Ie()}function jt(){qe&&(gt=!1),qe=!1,lt=0,ct=0,de=0,dt=0,Le("touchmove",document,Xe),Le("touchend",document,Te),Le("touchcancel",document,Te),Le("mousemove",document,Xe),Le("mouseup",document,Te)}function Pn(){if(d.value&&le){const{value:m}=K;rt(m,0)}else Ie();d.value&&(at.value.transitionDuration="0ms"),le=!1}function In(m){if(m.preventDefault(),le)return;let{deltaX:R,deltaY:M}=m;m.shiftKey&&!R&&(R=M);const W=-1,q=1,H=(R||M)>0?q:W;let U=0,G=0;c.value?G=H:U=H;const ie=10;(G*M>=ie||U*R>=ie)&&(H===q&&!Rt()?We():H===W&&!Ct()&&it())}function Tn(){C.value=Wt(s.value,!0),Ie()}function jn(){var m,R;z.value&&((R=(m=g.effect).scheduler)===null||R===void 0||R.call(m),g.effect.run())}function Bn(){e.autoplay&&Ye()}function Nn(){e.autoplay&&Ie()}ge(()=>{bt(Ie),requestAnimationFrame(()=>w.value=!0)}),tt(()=>{jt(),Ye()}),Jn(()=>{const{value:m}=r,{value:R}=p,M=new Map,W=H=>M.has(H)?M.get(H):-1;let q=!1;for(let H=0;H<m.length;H++){const U=R.findIndex(G=>G.el===m[H]);U!==H&&(q=!0),M.set(m[H],U)}q&&m.sort((H,U)=>W(H)-W(U))}),Ve(K,(m,R)=>{if(m!==R)if(Ie(),d.value){if(x.value){const{value:M}=B;F.value>2&&m===M-2&&R===1?m=0:m===1&&R===M-2&&(m=M-1)}rt(m,I.value)}else Me()},{immediate:!0}),Ve([x,$],()=>void et(()=>{re(K.value)})),Ve(u,()=>{d.value&&Me()},{deep:!0}),Ve(d,m=>{m?Me():(le=!1,Ae(xe=0))});const En=P(()=>({onTouchstartPassive:e.touchable?Tt:void 0,onMousedown:e.draggable?Tt:void 0,onWheel:e.mousewheel?In:void 0})),Mn=P(()=>Object.assign(Object.assign({},Nt(Oe,["to","prev","next","isPrevDisabled","isNextDisabled"])),{total:F.value,currentIndex:X.value})),On=P(()=>({total:F.value,currentIndex:X.value,to:Oe.to})),Dn={getCurrentIndex:()=>X.value,to:st,prev:it,next:We},Ln=Z("Carousel","-carousel",es,Qn,e,n),Bt=P(()=>{const{common:{cubicBezierEaseInOut:m},self:{dotSize:R,dotColor:M,dotColorActive:W,dotColorFocus:q,dotLineWidth:H,dotLineWidthActive:U,arrowColor:G}}=Ln.value;return{"--n-bezier":m,"--n-dot-color":M,"--n-dot-color-focus":q,"--n-dot-color-active":W,"--n-dot-size":R,"--n-dot-line-width":H,"--n-dot-line-width-active":U,"--n-arrow-color":G}}),je=i?pe("carousel",void 0,Bt,e):void 0;return Object.assign(Object.assign({mergedClsPrefix:n,selfElRef:s,slidesElRef:a,slideVNodes:p,duplicatedable:x,userWantsControl:_,autoSlideSize:z,realIndex:K,slideStyles:T,translateStyle:at,slidesControlListeners:En,handleTransitionEnd:Pn,handleResize:Tn,handleSlideResize:jn,handleMouseenter:Bn,handleMouseleave:Nn,isActive:xn,arrowSlotProps:Mn,dotSlotProps:On},Dn),{cssVars:i?void 0:Bt,themeClass:je==null?void 0:je.themeClass,onRender:je==null?void 0:je.onRender})},render(){var e;const{mergedClsPrefix:n,showArrow:i,userWantsControl:s,slideStyles:a,dotType:r,dotPlacement:p,slidesControlListeners:c,transitionProps:f={},arrowSlotProps:h,dotSlotProps:d,$slots:{default:x,dots:_,arrow:$}}=this,y=x&&eo(x())||[];let z=os(y);return z.length||(z=y.map(C=>v(Qo,null,{default:()=>Xt(C)}))),this.duplicatedable&&(z=Ho(z)),this.slideVNodes.value=z,this.autoSlideSize&&(z=z.map(C=>v(ht,{onResize:this.handleSlideResize},{default:()=>C}))),(e=this.onRender)===null||e===void 0||e.call(this),v("div",Object.assign({ref:"selfElRef",class:[this.themeClass,`${n}-carousel`,this.direction==="vertical"&&`${n}-carousel--vertical`,this.showArrow&&`${n}-carousel--show-arrow`,`${n}-carousel--${p}`,`${n}-carousel--${this.direction}`,`${n}-carousel--${this.effect}`,s&&`${n}-carousel--usercontrol`],style:this.cssVars},c,{onMouseenter:this.handleMouseenter,onMouseleave:this.handleMouseleave}),v(ht,{onResize:this.handleResize},{default:()=>v("div",{ref:"slidesElRef",class:`${n}-carousel__slides`,role:"listbox",style:this.translateStyle,onTransitionend:this.handleTransitionEnd},s?z.map((C,g)=>v("div",{style:a[g],key:g},Zt(v(Qt,Object.assign({},f),{default:()=>C}),[[Jt,this.isActive(g)]]))):z)}),this.showDots&&d.total>1&&Et(_,d,()=>[v(Uo,{key:r+p,total:d.total,currentIndex:d.currentIndex,dotType:r,trigger:this.trigger,keyboard:this.keyboard})]),i&&Et($,h,()=>[v(Zo,null)]))}});function os(e){return e.reduce((n,i)=>(Jo(i)&&n.push(i),n),[])}function ss(e){const{railColor:n}=e;return{itemColor:n,itemColorActive:"#FFCC33",sizeSmall:"16px",sizeMedium:"20px",sizeLarge:"24px"}}const is={name:"Rate",common:en,self:ss},as=is,rs=A([D("list",`
 --n-merged-border-color: var(--n-border-color);
 --n-merged-color: var(--n-color);
 --n-merged-color-hover: var(--n-color-hover);
 margin: 0;
 font-size: var(--n-font-size);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 padding: 0;
 list-style-type: none;
 color: var(--n-text-color);
 background-color: var(--n-merged-color);
 `,[N("show-divider",[D("list-item",[A("&:not(:last-child)",[O("divider",`
 background-color: var(--n-merged-border-color);
 `)])])]),N("clickable",[D("list-item",`
 cursor: pointer;
 `)]),N("bordered",`
 border: 1px solid var(--n-merged-border-color);
 border-radius: var(--n-border-radius);
 `),N("hoverable",[D("list-item",`
 border-radius: var(--n-border-radius);
 `,[A("&:hover",`
 background-color: var(--n-merged-color-hover);
 `,[O("divider",`
 background-color: transparent;
 `)])])]),N("bordered, hoverable",[D("list-item",`
 padding: 12px 20px;
 `),O("header, footer",`
 padding: 12px 20px;
 `)]),O("header, footer",`
 padding: 12px 0;
 box-sizing: border-box;
 transition: border-color .3s var(--n-bezier);
 `,[A("&:not(:last-child)",`
 border-bottom: 1px solid var(--n-merged-border-color);
 `)]),D("list-item",`
 position: relative;
 padding: 12px 0; 
 box-sizing: border-box;
 display: flex;
 flex-wrap: nowrap;
 align-items: center;
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[O("prefix",`
 margin-right: 20px;
 flex: 0;
 `),O("suffix",`
 margin-left: 20px;
 flex: 0;
 `),O("main",`
 flex: 1;
 `),O("divider",`
 height: 1px;
 position: absolute;
 bottom: 0;
 left: 0;
 right: 0;
 background-color: transparent;
 transition: background-color .3s var(--n-bezier);
 pointer-events: none;
 `)])]),qt(D("list",`
 --n-merged-color-hover: var(--n-color-hover-modal);
 --n-merged-color: var(--n-color-modal);
 --n-merged-border-color: var(--n-border-color-modal);
 `)),Ft(D("list",`
 --n-merged-color-hover: var(--n-color-hover-popover);
 --n-merged-color: var(--n-color-popover);
 --n-merged-border-color: var(--n-border-color-popover);
 `))]),ls=Object.assign(Object.assign({},Z.props),{size:{type:String,default:"medium"},bordered:Boolean,clickable:Boolean,hoverable:Boolean,showDivider:{type:Boolean,default:!0}}),gn=_t("n-list"),cs=Q({name:"List",props:ls,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:i,mergedRtlRef:s}=ne(e),a=tn("List",s,n),r=Z("List","-list",rs,no,e,n);Ut(gn,{showDividerRef:yt(e,"showDivider"),mergedClsPrefixRef:n});const p=P(()=>{const{common:{cubicBezierEaseInOut:f},self:{fontSize:h,textColor:d,color:x,colorModal:_,colorPopover:$,borderColor:y,borderColorModal:z,borderColorPopover:C,borderRadius:g,colorHover:u,colorHoverModal:w,colorHoverPopover:S}}=r.value;return{"--n-font-size":h,"--n-bezier":f,"--n-text-color":d,"--n-color":x,"--n-border-radius":g,"--n-border-color":y,"--n-border-color-modal":z,"--n-border-color-popover":C,"--n-color-modal":_,"--n-color-popover":$,"--n-color-hover":u,"--n-color-hover-modal":w,"--n-color-hover-popover":S}}),c=i?pe("list",void 0,p,e):void 0;return{mergedClsPrefix:n,rtlEnabled:a,cssVars:i?void 0:p,themeClass:c==null?void 0:c.themeClass,onRender:c==null?void 0:c.onRender}},render(){var e;const{$slots:n,mergedClsPrefix:i,onRender:s}=this;return s==null||s(),v("ul",{class:[`${i}-list`,this.rtlEnabled&&`${i}-list--rtl`,this.bordered&&`${i}-list--bordered`,this.showDivider&&`${i}-list--show-divider`,this.hoverable&&`${i}-list--hoverable`,this.clickable&&`${i}-list--clickable`,this.themeClass],style:this.cssVars},n.header?v("div",{class:`${i}-list__header`},n.header()):null,(e=n.default)===null||e===void 0?void 0:e.call(n),n.footer?v("div",{class:`${i}-list__footer`},n.footer()):null)}}),ds=Q({name:"ListItem",setup(){const e=Qe(gn,null);return e||Kt("list-item","`n-list-item` must be placed in `n-list`."),{showDivider:e.showDividerRef,mergedClsPrefix:e.mergedClsPrefixRef}},render(){const{$slots:e,mergedClsPrefix:n}=this;return v("li",{class:`${n}-list-item`},e.prefix?v("div",{class:`${n}-list-item__prefix`},e.prefix()):null,e.default?v("div",{class:`${n}-list-item__main`},e):null,e.suffix?v("div",{class:`${n}-list-item__suffix`},e.suffix()):null,this.showDivider&&v("div",{class:`${n}-list-item__divider`}))}}),us=A([D("progress",{display:"inline-block"},[D("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),N("line",`
 width: 100%;
 display: block;
 `,[D("progress-content",`
 display: flex;
 align-items: center;
 `,[D("progress-graph",{flex:1})]),D("progress-custom-content",{marginLeft:"14px"}),D("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[N("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),N("circle, dashboard",{width:"120px"},[D("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),D("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),D("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),N("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[D("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),D("progress-content",{position:"relative"}),D("progress-graph",{position:"relative"},[D("progress-graph-circle",[A("svg",{verticalAlign:"bottom"}),D("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[N("empty",{opacity:0})]),D("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),D("progress-graph-line",[N("indicator-inside",[D("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[D("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),D("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),N("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[D("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),D("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),D("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[D("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[N("processing",[A("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),A("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),fs={success:v(nn,null),error:v(on,null),warning:v(sn,null),info:v(an,null)},gs=Q({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:n}){const i=P(()=>Ne(e.height)),s=P(()=>e.railBorderRadius!==void 0?Ne(e.railBorderRadius):e.height!==void 0?Ne(e.height,{c:.5}):""),a=P(()=>e.fillBorderRadius!==void 0?Ne(e.fillBorderRadius):e.railBorderRadius!==void 0?Ne(e.railBorderRadius):e.height!==void 0?Ne(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:r,railColor:p,railStyle:c,percentage:f,unit:h,indicatorTextColor:d,status:x,showIndicator:_,fillColor:$,processing:y,clsPrefix:z}=e;return v("div",{class:`${z}-progress-content`,role:"none"},v("div",{class:`${z}-progress-graph`,"aria-hidden":!0},v("div",{class:[`${z}-progress-graph-line`,{[`${z}-progress-graph-line--indicator-${r}`]:!0}]},v("div",{class:`${z}-progress-graph-line-rail`,style:[{backgroundColor:p,height:i.value,borderRadius:s.value},c]},v("div",{class:[`${z}-progress-graph-line-fill`,y&&`${z}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:$,height:i.value,lineHeight:i.value,borderRadius:a.value}},r==="inside"?v("div",{class:`${z}-progress-graph-line-indicator`,style:{color:d}},n.default?n.default():`${f}${h}`):null)))),_&&r==="outside"?v("div",null,n.default?v("div",{class:`${z}-progress-custom-content`,style:{color:d},role:"none"},n.default()):x==="default"?v("div",{role:"none",class:`${z}-progress-icon ${z}-progress-icon--as-text`,style:{color:d}},f,h):v("div",{class:`${z}-progress-icon`,"aria-hidden":!0},v(wt,{clsPrefix:z},{default:()=>fs[x]}))):null)}}}),ps={success:v(nn,null),error:v(on,null),warning:v(sn,null),info:v(an,null)},hs=Q({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:n}){function i(s,a,r){const{gapDegree:p,viewBoxWidth:c,strokeWidth:f}=e,h=50,d=0,x=h,_=0,$=2*h,y=50+f/2,z=`M ${y},${y} m ${d},${x}
      a ${h},${h} 0 1 1 ${_},${-$}
      a ${h},${h} 0 1 1 ${-_},${$}`,C=Math.PI*2*h,g={stroke:r,strokeDasharray:`${s/100*(C-p)}px ${c*8}px`,strokeDashoffset:`-${p/2}px`,transformOrigin:a?"center":void 0,transform:a?`rotate(${a}deg)`:void 0};return{pathString:z,pathStyle:g}}return()=>{const{fillColor:s,railColor:a,strokeWidth:r,offsetDegree:p,status:c,percentage:f,showIndicator:h,indicatorTextColor:d,unit:x,gapOffsetDegree:_,clsPrefix:$}=e,{pathString:y,pathStyle:z}=i(100,0,a),{pathString:C,pathStyle:g}=i(f,p,s),u=100+r;return v("div",{class:`${$}-progress-content`,role:"none"},v("div",{class:`${$}-progress-graph`,"aria-hidden":!0},v("div",{class:`${$}-progress-graph-circle`,style:{transform:_?`rotate(${_}deg)`:void 0}},v("svg",{viewBox:`0 0 ${u} ${u}`},v("g",null,v("path",{class:`${$}-progress-graph-circle-rail`,d:y,"stroke-width":r,"stroke-linecap":"round",fill:"none",style:z})),v("g",null,v("path",{class:[`${$}-progress-graph-circle-fill`,f===0&&`${$}-progress-graph-circle-fill--empty`],d:C,"stroke-width":r,"stroke-linecap":"round",fill:"none",style:g}))))),h?v("div",null,n.default?v("div",{class:`${$}-progress-custom-content`,role:"none"},n.default()):c!=="default"?v("div",{class:`${$}-progress-icon`,"aria-hidden":!0},v(wt,{clsPrefix:$},{default:()=>ps[c]})):v("div",{class:`${$}-progress-text`,style:{color:d},role:"none"},v("span",{class:`${$}-progress-text__percentage`},f),v("span",{class:`${$}-progress-text__unit`},x))):null)}}});function At(e,n,i=100){return`m ${i/2} ${i/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const vs=Q({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:n}){const i=P(()=>e.percentage.map((a,r)=>`${Math.PI*a/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*r)-e.circleGap*r)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:s,strokeWidth:a,circleGap:r,showIndicator:p,fillColor:c,railColor:f,railStyle:h,percentage:d,clsPrefix:x}=e;return v("div",{class:`${x}-progress-content`,role:"none"},v("div",{class:`${x}-progress-graph`,"aria-hidden":!0},v("div",{class:`${x}-progress-graph-circle`},v("svg",{viewBox:`0 0 ${s} ${s}`},d.map((_,$)=>v("g",{key:$},v("path",{class:`${x}-progress-graph-circle-rail`,d:At(s/2-a/2*(1+2*$)-r*$,a,s),"stroke-width":a,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:f[$]},h[$]]}),v("path",{class:[`${x}-progress-graph-circle-fill`,_===0&&`${x}-progress-graph-circle-fill--empty`],d:At(s/2-a/2*(1+2*$)-r*$,a,s),"stroke-width":a,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:i.value[$],strokeDashoffset:0,stroke:c[$]}})))))),p&&n.default?v("div",null,v("div",{class:`${x}-progress-text`},n.default())):null)}}}),ms=Object.assign(Object.assign({},Z.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),pn=Q({name:"Progress",props:ms,setup(e){const n=P(()=>e.indicatorPlacement||e.indicatorPosition),i=P(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:s,inlineThemeDisabled:a}=ne(e),r=Z("Progress","-progress",us,oo,e,s),p=P(()=>{const{status:f}=e,{common:{cubicBezierEaseInOut:h},self:{fontSize:d,fontSizeCircle:x,railColor:_,railHeight:$,iconSizeCircle:y,iconSizeLine:z,textColorCircle:C,textColorLineInner:g,textColorLineOuter:u,lineBgProcessing:w,fontWeightCircle:S,[$e("iconColor",f)]:I,[$e("fillColor",f)]:T}}=r.value;return{"--n-bezier":h,"--n-fill-color":T,"--n-font-size":d,"--n-font-size-circle":x,"--n-font-weight-circle":S,"--n-icon-color":I,"--n-icon-size-circle":y,"--n-icon-size-line":z,"--n-line-bg-processing":w,"--n-rail-color":_,"--n-rail-height":$,"--n-text-color-circle":C,"--n-text-color-line-inner":g,"--n-text-color-line-outer":u}}),c=a?pe("progress",P(()=>e.status[0]),p,e):void 0;return{mergedClsPrefix:s,mergedIndicatorPlacement:n,gapDeg:i,cssVars:a?void 0:p,themeClass:c==null?void 0:c.themeClass,onRender:c==null?void 0:c.onRender}},render(){const{type:e,cssVars:n,indicatorTextColor:i,showIndicator:s,status:a,railColor:r,railStyle:p,color:c,percentage:f,viewBoxWidth:h,strokeWidth:d,mergedIndicatorPlacement:x,unit:_,borderRadius:$,fillBorderRadius:y,height:z,processing:C,circleGap:g,mergedClsPrefix:u,gapDeg:w,gapOffsetDegree:S,themeClass:I,$slots:T,onRender:B}=this;return B==null||B(),v("div",{class:[I,`${u}-progress`,`${u}-progress--${e}`,`${u}-progress--${a}`],style:n,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":f,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?v(hs,{clsPrefix:u,status:a,showIndicator:s,indicatorTextColor:i,railColor:r,fillColor:c,railStyle:p,offsetDegree:this.offsetDegree,percentage:f,viewBoxWidth:h,strokeWidth:d,gapDegree:w===void 0?e==="dashboard"?75:0:w,gapOffsetDegree:S,unit:_},T):e==="line"?v(gs,{clsPrefix:u,status:a,showIndicator:s,indicatorTextColor:i,railColor:r,fillColor:c,railStyle:p,percentage:f,processing:C,indicatorPlacement:x,unit:_,fillBorderRadius:y,railBorderRadius:$,height:z},T):e==="multiple-circle"?v(vs,{clsPrefix:u,strokeWidth:d,railColor:r,fillColor:c,railStyle:p,viewBoxWidth:h,percentage:f,showIndicator:s,circleGap:g},T):null)}}),_s=v("svg",{viewBox:"0 0 512 512"},v("path",{d:"M394 480a16 16 0 01-9.39-3L256 383.76 127.39 477a16 16 0 01-24.55-18.08L153 310.35 23 221.2a16 16 0 019-29.2h160.38l48.4-148.95a16 16 0 0130.44 0l48.4 149H480a16 16 0 019.05 29.2L359 310.35l50.13 148.53A16 16 0 01394 480z"})),bs=D("rate",{display:"inline-flex",flexWrap:"nowrap"},[A("&:hover",[O("item",`
 transition:
 transform .1s var(--n-bezier),
 color .3s var(--n-bezier);
 `)]),O("item",`
 position: relative;
 display: flex;
 transition:
 transform .1s var(--n-bezier),
 color .3s var(--n-bezier);
 transform: scale(1);
 font-size: var(--n-item-size);
 color: var(--n-item-color);
 `,[A("&:not(:first-child)",`
 margin-left: 6px;
 `),N("active",`
 color: var(--n-item-color-active);
 `)]),so("readonly",`
 cursor: pointer;
 `,[O("item",[A("&:hover",`
 transform: scale(1.05);
 `),A("&:active",`
 transform: scale(0.96);
 `)])]),O("half",`
 display: flex;
 transition: inherit;
 position: absolute;
 top: 0;
 left: 0;
 bottom: 0;
 width: 50%;
 overflow: hidden;
 color: rgba(255, 255, 255, 0);
 `,[N("active",`
 color: var(--n-item-color-active);
 `)])]),ys=Object.assign(Object.assign({},Z.props),{allowHalf:Boolean,count:{type:Number,default:5},value:Number,defaultValue:{type:Number,default:null},readonly:Boolean,size:{type:[String,Number],default:"medium"},clearable:Boolean,color:String,onClear:Function,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array]}),ws=Q({name:"Rate",props:ys,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:i}=ne(e),s=Z("Rate","-rate",bs,as,e,n),a=yt(e,"value"),r=j(e.defaultValue),p=j(null),c=io(e),f=Gt(a,r);function h(w){const{"onUpdate:value":S,onUpdateValue:I}=e,{nTriggerFormChange:T,nTriggerFormInput:B}=c;S&&Mt(S,w),I&&Mt(I,w),r.value=w,T(),B()}function d(w,S){return e.allowHalf?S.offsetX>=Math.floor(S.currentTarget.offsetWidth/2)?w+1:w+.5:w+1}let x=!1;function _(w,S){x||(p.value=d(w,S))}function $(){p.value=null}function y(w,S){var I;const{clearable:T}=e,B=d(w,S);T&&B===f.value?(x=!0,(I=e.onClear)===null||I===void 0||I.call(e),p.value=null,h(null)):h(B)}function z(){x=!1}const C=P(()=>{const{size:w}=e,{self:S}=s.value;return typeof w=="number"?`${w}px`:S[$e("size",w)]}),g=P(()=>{const{common:{cubicBezierEaseInOut:w},self:S}=s.value,{itemColor:I,itemColorActive:T}=S,{color:B}=e;return{"--n-bezier":w,"--n-item-color":I,"--n-item-color-active":B||T,"--n-item-size":C.value}}),u=i?pe("rate",P(()=>{const w=C.value,{color:S}=e;let I="";return w&&(I+=w[0]),S&&(I+=Yt(S)),I}),g,e):void 0;return{mergedClsPrefix:n,mergedValue:f,hoverIndex:p,handleMouseMove:_,handleClick:y,handleMouseLeave:$,handleMouseEnterSomeStar:z,cssVars:i?void 0:g,themeClass:u==null?void 0:u.themeClass,onRender:u==null?void 0:u.onRender}},render(){const{readonly:e,hoverIndex:n,mergedValue:i,mergedClsPrefix:s,onRender:a,$slots:{default:r}}=this;return a==null||a(),v("div",{class:[`${s}-rate`,{[`${s}-rate--readonly`]:e},this.themeClass],style:this.cssVars,onMouseleave:this.handleMouseLeave},ue(this.count,(p,c)=>{const f=r?r({index:c}):v(wt,{clsPrefix:s},{default:()=>_s}),h=n!==null?c+1<=n:c+1<=(i||0);return v("div",{key:c,class:[`${s}-rate__item`,h&&`${s}-rate__item--active`],onClick:e?void 0:d=>{this.handleClick(c,d)},onMouseenter:this.handleMouseEnterSomeStar,onMousemove:e?void 0:d=>{this.handleMouseMove(c,d)}},f,this.allowHalf?v("div",{class:[`${s}-rate__half`,{[`${s}-rate__half--active`]:!h&&n!==null?c+.5<=n:c+.5<=(i||0)}]},f):null)}))}});function xs(e){const{heightSmall:n,heightMedium:i,heightLarge:s,borderRadius:a}=e;return{color:"#eee",colorEnd:"#ddd",borderRadius:a,heightSmall:n,heightMedium:i,heightLarge:s}}const $s={name:"Skeleton",common:en,self:xs},zs=A([D("skeleton",`
 height: 1em;
 width: 100%;
 transition:
 --n-color-start .3s var(--n-bezier),
 --n-color-end .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 animation: 2s skeleton-loading infinite cubic-bezier(0.36, 0, 0.64, 1);
 background-color: var(--n-color-start);
 `),A("@keyframes skeleton-loading",`
 0% {
 background: var(--n-color-start);
 }
 40% {
 background: var(--n-color-end);
 }
 80% {
 background: var(--n-color-start);
 }
 100% {
 background: var(--n-color-start);
 }
 `)]),Ss=Object.assign(Object.assign({},Z.props),{text:Boolean,round:Boolean,circle:Boolean,height:[String,Number],width:[String,Number],size:String,repeat:{type:Number,default:1},animated:{type:Boolean,default:!0},sharp:{type:Boolean,default:!0}}),ks=Q({name:"Skeleton",inheritAttrs:!1,props:Ss,setup(e){Io();const{mergedClsPrefixRef:n}=ne(e),i=Z("Skeleton","-skeleton",zs,$s,e,n);return{mergedClsPrefix:n,style:P(()=>{var s,a;const r=i.value,{common:{cubicBezierEaseInOut:p}}=r,c=r.self,{color:f,colorEnd:h,borderRadius:d}=c;let x;const{circle:_,sharp:$,round:y,width:z,height:C,size:g,text:u,animated:w}=e;g!==void 0&&(x=c[$e("height",g)]);const S=_?(s=z!=null?z:C)!==null&&s!==void 0?s:x:z,I=(a=_&&z!=null?z:C)!==null&&a!==void 0?a:x;return{display:u?"inline-block":"",verticalAlign:u?"-0.125em":"",borderRadius:_?"50%":y?"4096px":$?"":d,width:typeof S=="number"?vt(S):S,height:typeof I=="number"?vt(I):I,animation:w?"":"none","--n-bezier":p,"--n-color-start":f,"--n-color-end":h}})}},render(){const{repeat:e,style:n,mergedClsPrefix:i,$attrs:s}=this,a=v("div",ao({class:`${i}-skeleton`,style:n},s));return e>1?v(ce,null,ro(e,null).map(r=>[a,`
`])):a}}),Cs=A([A("@keyframes spin-rotate",`
 from {
 transform: rotate(0);
 }
 to {
 transform: rotate(360deg);
 }
 `),D("spin-container",`
 position: relative;
 `,[D("spin-body",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[lo()])]),D("spin-body",`
 display: inline-flex;
 align-items: center;
 justify-content: center;
 flex-direction: column;
 `),D("spin",`
 display: inline-flex;
 height: var(--n-size);
 width: var(--n-size);
 font-size: var(--n-size);
 color: var(--n-color);
 `,[N("rotate",`
 animation: spin-rotate 2s linear infinite;
 `)]),D("spin-description",`
 display: inline-block;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 margin-top: 8px;
 `),D("spin-content",`
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 pointer-events: all;
 `,[N("spinning",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: none;
 opacity: var(--n-opacity-spinning);
 `)])]),Rs={small:20,medium:18,large:16},Ps=Object.assign(Object.assign({},Z.props),{contentClass:String,contentStyle:[Object,String],description:String,stroke:String,size:{type:[String,Number],default:"medium"},show:{type:Boolean,default:!0},strokeWidth:Number,rotate:{type:Boolean,default:!0},spinning:{type:Boolean,validator:()=>!0,default:void 0},delay:Number}),hn=Q({name:"Spin",props:Ps,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:i}=ne(e),s=Z("Spin","-spin",Cs,co,e,n),a=P(()=>{const{size:f}=e,{common:{cubicBezierEaseInOut:h},self:d}=s.value,{opacitySpinning:x,color:_,textColor:$}=d,y=typeof f=="number"?vt(f):d[$e("size",f)];return{"--n-bezier":h,"--n-opacity-spinning":x,"--n-size":y,"--n-color":_,"--n-text-color":$}}),r=i?pe("spin",P(()=>{const{size:f}=e;return typeof f=="number"?String(f):f[0]}),a,e):void 0,p=rn(e,["spinning","show"]),c=j(!1);return bt(f=>{let h;if(p.value){const{delay:d}=e;if(d){h=window.setTimeout(()=>{c.value=!0},d),f(()=>{clearTimeout(h)});return}}c.value=p.value}),{mergedClsPrefix:n,active:c,mergedStrokeWidth:P(()=>{const{strokeWidth:f}=e;if(f!==void 0)return f;const{size:h}=e;return Rs[typeof h=="number"?"medium":h]}),cssVars:i?void 0:a,themeClass:r==null?void 0:r.themeClass,onRender:r==null?void 0:r.onRender}},render(){var e,n;const{$slots:i,mergedClsPrefix:s,description:a}=this,r=i.icon&&this.rotate,p=(a||i.description)&&v("div",{class:`${s}-spin-description`},a||((e=i.description)===null||e===void 0?void 0:e.call(i))),c=i.icon?v("div",{class:[`${s}-spin-body`,this.themeClass]},v("div",{class:[`${s}-spin`,r&&`${s}-spin--rotate`],style:i.default?"":this.cssVars},i.icon()),p):v("div",{class:[`${s}-spin-body`,this.themeClass]},v(uo,{clsPrefix:s,style:i.default?"":this.cssVars,stroke:this.stroke,"stroke-width":this.mergedStrokeWidth,class:`${s}-spin`}),p);return(n=this.onRender)===null||n===void 0||n.call(this),i.default?v("div",{class:[`${s}-spin-container`,this.themeClass],style:this.cssVars},v("div",{class:[`${s}-spin-content`,this.active&&`${s}-spin-content--spinning`,this.contentClass],style:this.contentStyle},i),v(Qt,{name:"fade-in-transition"},{default:()=>this.active?c:null})):c}}),Is=D("thing",`
 display: flex;
 transition: color .3s var(--n-bezier);
 font-size: var(--n-font-size);
 color: var(--n-text-color);
`,[D("thing-avatar",`
 margin-right: 12px;
 margin-top: 2px;
 `),D("thing-avatar-header-wrapper",`
 display: flex;
 flex-wrap: nowrap;
 `,[D("thing-header-wrapper",`
 flex: 1;
 `)]),D("thing-main",`
 flex-grow: 1;
 `,[D("thing-header",`
 display: flex;
 margin-bottom: 4px;
 justify-content: space-between;
 align-items: center;
 `,[O("title",`
 font-size: 16px;
 font-weight: var(--n-title-font-weight);
 transition: color .3s var(--n-bezier);
 color: var(--n-title-text-color);
 `)]),O("description",[A("&:not(:last-child)",`
 margin-bottom: 4px;
 `)]),O("content",[A("&:not(:first-child)",`
 margin-top: 12px;
 `)]),O("footer",[A("&:not(:first-child)",`
 margin-top: 12px;
 `)]),O("action",[A("&:not(:first-child)",`
 margin-top: 12px;
 `)])])]),Ts=Object.assign(Object.assign({},Z.props),{title:String,titleExtra:String,description:String,descriptionClass:String,descriptionStyle:[String,Object],content:String,contentClass:String,contentStyle:[String,Object],contentIndented:Boolean}),js=Q({name:"Thing",props:Ts,setup(e,{slots:n}){const{mergedClsPrefixRef:i,inlineThemeDisabled:s,mergedRtlRef:a}=ne(e),r=Z("Thing","-thing",Is,fo,e,i),p=tn("Thing",a,i),c=P(()=>{const{self:{titleTextColor:h,textColor:d,titleFontWeight:x,fontSize:_},common:{cubicBezierEaseInOut:$}}=r.value;return{"--n-bezier":$,"--n-font-size":_,"--n-text-color":d,"--n-title-font-weight":x,"--n-title-text-color":h}}),f=s?pe("thing",void 0,c,e):void 0;return()=>{var h;const{value:d}=i,x=p?p.value:!1;return(h=f==null?void 0:f.onRender)===null||h===void 0||h.call(f),v("div",{class:[`${d}-thing`,f==null?void 0:f.themeClass,x&&`${d}-thing--rtl`],style:s?void 0:c.value},n.avatar&&e.contentIndented?v("div",{class:`${d}-thing-avatar`},n.avatar()):null,v("div",{class:`${d}-thing-main`},!e.contentIndented&&(n.header||e.title||n["header-extra"]||e.titleExtra||n.avatar)?v("div",{class:`${d}-thing-avatar-header-wrapper`},n.avatar?v("div",{class:`${d}-thing-avatar`},n.avatar()):null,n.header||e.title||n["header-extra"]||e.titleExtra?v("div",{class:`${d}-thing-header-wrapper`},v("div",{class:`${d}-thing-header`},n.header||e.title?v("div",{class:`${d}-thing-header__title`},n.header?n.header():e.title):null,n["header-extra"]||e.titleExtra?v("div",{class:`${d}-thing-header__extra`},n["header-extra"]?n["header-extra"]():e.titleExtra):null),n.description||e.description?v("div",{class:[`${d}-thing-main__description`,e.descriptionClass],style:e.descriptionStyle},n.description?n.description():e.description):null):null):v(ce,null,n.header||e.title||n["header-extra"]||e.titleExtra?v("div",{class:`${d}-thing-header`},n.header||e.title?v("div",{class:`${d}-thing-header__title`},n.header?n.header():e.title):null,n["header-extra"]||e.titleExtra?v("div",{class:`${d}-thing-header__extra`},n["header-extra"]?n["header-extra"]():e.titleExtra):null):null,n.description||e.description?v("div",{class:[`${d}-thing-main__description`,e.descriptionClass],style:e.descriptionStyle},n.description?n.description():e.description):null),n.default||e.content?v("div",{class:[`${d}-thing-main__content`,e.contentClass],style:e.contentStyle},n.default?n.default():e.content):null,n.footer?v("div",{class:`${d}-thing-main__footer`},n.footer()):null,n.action?v("div",{class:`${d}-thing-main__action`},n.action()):null))}}}),Bs=D("blockquote",`
 font-size: var(--n-font-size);
 line-height: var(--n-line-height);
 margin: 0;
 margin-top: 12px;
 margin-bottom: 12px;
 box-sizing: border-box;
 padding-left: 12px;
 border-left: 4px solid var(--n-prefix-color);
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
`,[A("&:first-child",{marginTop:0}),A("&:last-child",{marginBottom:0}),N("align-text",{marginLeft:"-16px"})]),Ns=Object.assign(Object.assign({},Z.props),{alignText:Boolean}),Es=Q({name:"Blockquote",props:Ns,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:i}=ne(e),s=Z("Typography","-blockquote",Bs,ln,e,n),a=P(()=>{const{common:{cubicBezierEaseInOut:p},self:{blockquoteTextColor:c,blockquotePrefixColor:f,blockquoteLineHeight:h,blockquoteFontSize:d}}=s.value;return{"--n-bezier":p,"--n-font-size":d,"--n-line-height":h,"--n-prefix-color":f,"--n-text-color":c}}),r=i?pe("blockquote",void 0,a,e):void 0;return{mergedClsPrefix:n,cssVars:i?void 0:a,themeClass:r==null?void 0:r.themeClass,onRender:r==null?void 0:r.onRender}},render(){var e;const{mergedClsPrefix:n}=this;return(e=this.onRender)===null||e===void 0||e.call(this),v("blockquote",{class:[`${n}-blockquote`,this.themeClass,this.alignText&&`${n}-blockquote--align-text`],style:this.cssVars},this.$slots)}}),Ms=D("text",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
`,[N("strong",`
 font-weight: var(--n-font-weight-strong);
 `),N("italic",{fontStyle:"italic"}),N("underline",{textDecoration:"underline"}),N("code",`
 line-height: 1.4;
 display: inline-block;
 font-family: var(--n-font-famliy-mono);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 box-sizing: border-box;
 padding: .05em .35em 0 .35em;
 border-radius: var(--n-code-border-radius);
 font-size: .9em;
 color: var(--n-code-text-color);
 background-color: var(--n-code-color);
 border: var(--n-code-border);
 `)]),Os=Object.assign(Object.assign({},Z.props),{code:Boolean,type:{type:String,default:"default"},delete:Boolean,strong:Boolean,italic:Boolean,underline:Boolean,depth:[String,Number],tag:String,as:{type:String,validator:()=>!0,default:void 0}}),be=Q({name:"Text",props:Os,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:i}=ne(e),s=Z("Typography","-text",Ms,ln,e,n),a=P(()=>{const{depth:p,type:c}=e,f=c==="default"?p===void 0?"textColor":`textColor${p}Depth`:$e("textColor",c),{common:{fontWeightStrong:h,fontFamilyMono:d,cubicBezierEaseInOut:x},self:{codeTextColor:_,codeBorderRadius:$,codeColor:y,codeBorder:z,[f]:C}}=s.value;return{"--n-bezier":x,"--n-text-color":C,"--n-font-weight-strong":h,"--n-font-famliy-mono":d,"--n-code-border-radius":$,"--n-code-text-color":_,"--n-code-color":y,"--n-code-border":z}}),r=i?pe("text",P(()=>`${e.type[0]}${e.depth||""}`),a,e):void 0;return{mergedClsPrefix:n,compitableTag:rn(e,["as","tag"]),cssVars:i?void 0:a,themeClass:r==null?void 0:r.themeClass,onRender:r==null?void 0:r.onRender}},render(){var e,n,i;const{mergedClsPrefix:s}=this;(e=this.onRender)===null||e===void 0||e.call(this);const a=[`${s}-text`,this.themeClass,{[`${s}-text--code`]:this.code,[`${s}-text--delete`]:this.delete,[`${s}-text--strong`]:this.strong,[`${s}-text--italic`]:this.italic,[`${s}-text--underline`]:this.underline}],r=(i=(n=this.$slots).default)===null||i===void 0?void 0:i.call(n);return this.code?v("code",{class:a,style:this.cssVars},this.delete?v("del",null,r):r):this.delete?v("del",{class:a,style:this.cssVars},r):v(this.compitableTag||"span",{class:a,style:this.cssVars},r)}}),ee={news:"/images/business_office_scene.jpg",avatar:"/images/business_office_scene.jpg",logo:"/images/ISO9001质量管理体系认证证书.png",business:"/images/business_office_scene.jpg",technology:"/images/icon_advanced_packaging.jpg",case:"/images/product_development_cycle_chart.jpg",certificate:"/images/ISO9001质量管理体系认证证书.png"},Ds={hero:{company_hero:"/images/hero_pictore_company.png",tech_background:"/images/科技背景图片.jpg",tech_concept:"/images/商务科技概念图.png",circuit_background:"/images/科技电路背景图.png",business_office:"/images/business_office_scene.jpg"},about:{office_scene:"/images/business_office_scene.jpg",team_photo:"/images/business_office_scene.jpg"},business:{advanced_packaging:"/images/icon_advanced_packaging.jpg",hardware_solution:"/images/icon_hardware_design.jpg",testing_service:"/images/icon_hardware_design.jpg"},technology:{lab_equipment:"/images/business_office_scene.jpg",pcb_design:"/images/icon_advanced_packaging.jpg",testing_facility:"/images/icon_hardware_design.jpg"},cases:{automotive:"/images/business_office_scene.jpg",consumer:"/images/modern_buildings_night_scene.jpg",industrial:"/images/product_development_cycle_chart.jpg"},news:{news_1:"/images/business_office_scene.jpg",news_2:"/images/modern_buildings_night_scene.jpg",news_3:"/images/product_development_cycle_chart.jpg"},certificates:{iso9001:"/images/ISO9001质量管理体系认证证书.png",military:"/images/武器装备质量管理体系证书.png"},customers:{avatar_1:"/images/business_office_scene.jpg",avatar_2:"/images/modern_buildings_night_scene.jpg",avatar_3:"/images/product_development_cycle_chart.jpg",avatar_4:"/images/ISO9001质量管理体系认证证书.png"},partners:{huawei:"/images/ISO9001质量管理体系认证证书.png",zte:"/images/武器装备质量管理体系证书.png",xiaomi:"/images/business_office_scene.jpg",lenovo:"/images/modern_buildings_night_scene.jpg",hikvision:"/images/product_development_cycle_chart.jpg",dji:"/images/icon_advanced_packaging.jpg"}};function Y(e,n,i="business"){try{const s=Ds[e];return s&&s[n]?s[n]:ee[i]||ee.business}catch(s){return console.warn(`图片资源获取失败: ${e}.${n}`,s),ee[i]||ee.business}}const Ls={id:"home",class:"hero-banner section-full"},Vs={class:"hero-slide"},Hs={class:"hero-slide"},Ws={__name:"HeroSection",setup(e){const n=j(null),i=j(!1),s=j(6e3),a=j(0),r=j(0),p=j(2),{width:c,height:f}=go(),h=()=>{r.value++,console.log(`图片加载完成: ${r.value}/${p.value}`),r.value>=p.value&&setTimeout(()=>{i.value=!0,console.log("所有图片加载完成，启动轮播自动播放")},500)},d=_=>{a.value=_,console.log(`轮播切换到第 ${_+1} 张图片`)},x=P(()=>{const _=c.value/f.value;let $="cover",y="center center",z="";return _>2.2?($="contain",y="center center",z="background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);"):_>1.6?($="cover",y="center 45%"):_>1.2?($="cover",y="center center"):($="cover",y="center 30%"),{objectFit:$,objectPosition:y,additionalStyles:z}});return ge(()=>{setTimeout(()=>{n.value&&(n.value.to(0),console.log("轮播组件初始化完成"))},100)}),nt(()=>{i.value=!1}),(_,$)=>{const y=ke,z=fn;return E(),L("section",Ls,[t(z,{ref_key:"carouselRef",ref:n,autoplay:i.value,interval:s.value,"default-index":0,"show-dots":!0,"show-arrow":!0,keyboard:!1,mousewheel:!1,trigger:"hover","transition-style":{transitionDuration:"500ms"},effect:"slide",style:{height:"100vh"},"onUpdate:currentIndex":d},{default:o(()=>[l("div",Vs,[t(y,{src:V(Y)("hero","company_hero"),"fallback-src":V(ee).business,alt:"公司主图","object-fit":x.value.objectFit,"preview-disabled":!0,style:ze(`position: absolute; top: 0; left: 0; z-index: 1; display: block; width: 100%; height: 100vh; ${x.value.additionalStyles}`),"img-props":{style:`width: 100%; height: 100%; object-fit: ${x.value.objectFit}; object-position: ${x.value.objectPosition}; filter: brightness(1.1) contrast(1.05);`},onLoad:h,onError:h},null,8,["src","fallback-src","object-fit","style","img-props"])]),l("div",Hs,[t(y,{src:V(Y)("hero","tech_background"),"fallback-src":V(ee).technology,alt:"科技背景","object-fit":x.value.objectFit,"preview-disabled":!0,style:ze(`position: absolute; top: 0; left: 0; z-index: 1; display: block; width: 100%; height: 100vh; ${x.value.additionalStyles}`),"img-props":{style:`width: 100%; height: 100%; object-fit: ${x.value.objectFit}; object-position: ${x.value.objectPosition}; filter: brightness(1.2) contrast(1.1);`},onLoad:h,onError:h},null,8,["src","fallback-src","object-fit","style","img-props"])])]),_:1},8,["autoplay","interval"])])}}},As=se(Ws,[["__scopeId","data-v-c35c25cc"]]);const qs=e=>(ve("data-v-6c2489ff"),e=e(),me(),e),Fs={id:"about",class:"about-section section-half"},Ys={class:"section-container"},Xs=qs(()=>l("div",{class:"title-underline"},null,-1)),Us={class:"about-image-container height-match-container"},Ks={__name:"AboutSection",setup(e){he(),po();const n=()=>{const s=document.getElementById("about");s&&s.scrollIntoView({behavior:"smooth",block:"start"}),console.log("用户点击了解更多按钮")},i=()=>{const s=document.getElementById("contact");s&&s.scrollIntoView({behavior:"smooth",block:"start"}),console.log("用户点击联系我们按钮")};return(s,a)=>{const r=be,p=ae,c=cn,f=ko,h=Se,d=$t,x=Ce,_=Re,$=ke,y=_e;return E(),L("section",Fs,[l("div",Ys,[t(_,{cols:2,collapsed:!0,"collapsed-rows":1,"x-gap":80,"y-gap":40,responsive:"screen","align-items":"stretch",class:"about-grid-container"},{default:o(()=>[t(x,null,{default:o(()=>[t(p,{vertical:"",size:40},{default:o(()=>[t(p,{vertical:"",size:20},{default:o(()=>[t(r,{style:{fontSize:"var(--sipumtech-font-size-h1)",fontWeight:"var(--sipumtech-font-weight-bold)",color:"var(--sipumtech-primary-blue)",lineHeight:"var(--sipumtech-line-height-tight)"}},{default:o(()=>[k(b(s.$t("website.about.title")),1)]),_:1}),Xs]),_:1}),t(p,{size:12,wrap:""},{default:o(()=>[t(c,{type:"info",size:"large",bordered:!1,style:{background:"linear-gradient(135deg, #1e3a8a, #3b82f6)",color:"white","font-weight":"600",padding:"8px 16px"}},{default:o(()=>[k(b(s.$t("website.about.tag_founded")),1)]),_:1}),t(c,{type:"info",size:"large",bordered:!1,style:{background:"linear-gradient(135deg, #059669, #10b981)",color:"white","font-weight":"600",padding:"8px 16px"}},{default:o(()=>[k(b(s.$t("website.about.tag_location")),1)]),_:1}),t(c,{type:"info",size:"large",bordered:!1,style:{background:"linear-gradient(135deg, #dc2626, #ef4444)",color:"white","font-weight":"600",padding:"8px 16px"}},{default:o(()=>[k(b(s.$t("website.about.tag_positioning")),1)]),_:1})]),_:1}),t(p,{vertical:"",size:24},{default:o(()=>[t(r,{style:{fontSize:"var(--sipumtech-font-size-h4)",fontWeight:"var(--sipumtech-font-weight-semibold)",color:"var(--sipumtech-primary-blue)",lineHeight:"var(--sipumtech-line-height-relaxed)"}},{default:o(()=>[k(b(s.$t("website.about.intro_highlight")),1)]),_:1}),t(r,{style:{fontSize:"var(--sipumtech-font-size-body)",color:"var(--sipumtech-text-secondary)",lineHeight:"var(--sipumtech-line-height-relaxed)"}},{default:o(()=>[k(b(s.$t("website.about.intro_description")),1)]),_:1})]),_:1}),t(f,{style:{margin:"20px 0"}}),t(p,null,{default:o(()=>[t(h,{type:"primary",size:"large",onClick:n,style:{padding:"12px 32px","font-size":"16px","font-weight":"600"}},{default:o(()=>[k(b(s.$t("website.about.cta_learn_more")),1)]),_:1}),t(h,{type:"default",size:"large",onClick:i,style:{padding:"12px 32px","font-size":"16px"}},{default:o(()=>[k(b(s.$t("website.about.cta_contact")),1)]),_:1})]),_:1}),t(_,{cols:3,"x-gap":30},{default:o(()=>[t(x,null,{default:o(()=>[t(d,{label:s.$t("website.about.stat_founded"),value:2019,"value-style":{fontSize:"32px",fontWeight:"bold",color:"#1e3a8a"}},null,8,["label"])]),_:1}),t(x,null,{default:o(()=>[t(d,{label:s.$t("website.about.stat_clients"),value:"100+","value-style":{fontSize:"32px",fontWeight:"bold",color:"#1e3a8a"}},null,8,["label"])]),_:1}),t(x,null,{default:o(()=>[t(d,{label:s.$t("website.about.stat_team"),value:"5+","value-style":{fontSize:"32px",fontWeight:"bold",color:"#1e3a8a"}},null,8,["label"])]),_:1})]),_:1})]),_:1})]),_:1}),t(x,null,{default:o(()=>[l("div",Us,[t($,{src:V(Y)("about","office_scene"),"fallback-src":V(ee).business,alt:"办公场景","object-fit":"cover",class:"responsive-image height-adaptive-image","img-props":{style:"width: 100%; height: 100%; object-fit: cover; object-position: center;"}},null,8,["src","fallback-src"]),t(y,{class:"image-overlay-card",bordered:!1,style:{position:"absolute",bottom:"20px",left:"20px",right:"20px",background:"rgba(255, 255, 255, 0.95)","backdrop-filter":"blur(10px)","z-index":"2"}},{default:o(()=>[t(p,{vertical:"",size:8},{default:o(()=>[t(r,{style:{fontSize:"18px",fontWeight:"var(--sipumtech-font-weight-semibold)",color:"var(--sipumtech-primary-blue)"}},{default:o(()=>[k(b(s.$t("website.about.team_overlay_title")),1)]),_:1}),t(r,{style:{fontSize:"var(--sipumtech-font-size-small)",color:"var(--sipumtech-text-secondary)"}},{default:o(()=>[k(b(s.$t("website.about.team_overlay_desc")),1)]),_:1})]),_:1})]),_:1})])]),_:1})]),_:1})])])}}},Gs=se(Ks,[["__scopeId","data-v-6c2489ff"]]);const Zs=e=>(ve("data-v-b86789f0"),e=e(),me(),e),Js={id:"business",class:"main-services-section section-full"},Qs={class:"section-container"},ei=Zs(()=>l("div",{class:"title-underline"},null,-1)),ti={__name:"BusinessSection",emits:["start-hover","end-hover","get-solution","tech-consultation"],setup(e,{emit:n}){return he(),(i,s)=>{const a=be,r=ae,p=ke,c=js,f=ds,h=cs,d=Se,x=_e,_=Ce,$=Re;return E(),L("div",null,[l("section",Js,[l("div",Qs,[t(r,{vertical:"",align:"center",size:20,style:{"margin-bottom":"60px"}},{default:o(()=>[t(a,{style:{fontSize:"var(--sipumtech-font-size-h1)",fontWeight:"var(--sipumtech-font-weight-bold)",color:"var(--sipumtech-primary-blue)",lineHeight:"var(--sipumtech-line-height-tight)"}},{default:o(()=>[k(b(i.$t("website.business.title")),1)]),_:1}),ei,t(a,{style:{fontSize:"18px",color:"var(--sipumtech-text-secondary)",lineHeight:"var(--sipumtech-line-height-relaxed)"}},{default:o(()=>[k(b(i.$t("website.business.subtitle")),1)]),_:1})]),_:1}),t($,{cols:2,"x-gap":40,"y-gap":40,"item-responsive":"",responsive:"screen"},{default:o(()=>[t(_,null,{default:o(()=>[t(x,{hoverable:"",class:"service-card",onMouseenter:s[2]||(s[2]=y=>i.$emit("start-hover")),onMouseleave:s[3]||(s[3]=y=>i.$emit("end-hover"))},{default:o(()=>[t(r,{vertical:"",size:20},{default:o(()=>[t(r,{justify:"center"},{default:o(()=>[t(p,{src:V(Y)("business","advanced_packaging"),"fallback-src":V(ee).technology,alt:"先进封装",width:"80",height:"80","object-fit":"cover",style:{"border-radius":"8px"}},null,8,["src","fallback-src"])]),_:1}),t(r,{vertical:"",align:"center",size:12},{default:o(()=>[t(a,{style:{fontSize:"var(--sipumtech-font-size-small)",fontWeight:"var(--sipumtech-font-weight-semibold)",color:"var(--sipumtech-accent-orange)",textTransform:"uppercase",letterSpacing:"1px"}},{default:o(()=>[k(b(i.$t("website.business.advanced_packaging.brand")),1)]),_:1}),t(a,{style:{fontSize:"var(--sipumtech-font-size-body)",fontWeight:"var(--sipumtech-font-weight-semibold)",color:"var(--sipumtech-text-secondary)"}},{default:o(()=>[k(b(i.$t("website.business.advanced_packaging.subtitle")),1)]),_:1}),t(a,{style:{fontSize:"var(--sipumtech-font-size-h4)",fontWeight:"var(--sipumtech-font-weight-bold)",color:"var(--sipumtech-primary-blue)",lineHeight:"1.3"}},{default:o(()=>[k(b(i.$t("website.business.advanced_packaging.title")),1)]),_:1}),t(a,{style:{fontSize:"var(--sipumtech-font-size-body)",color:"var(--sipumtech-text-secondary)",lineHeight:"var(--sipumtech-line-height-relaxed)",textAlign:"center"}},{default:o(()=>[k(b(i.$t("website.business.advanced_packaging.description")),1)]),_:1})]),_:1}),t(h,null,{default:o(()=>[t(f,null,{default:o(()=>[t(c,null,{description:o(()=>[k(" ✓ "+b(i.$t("website.business.advanced_packaging.feature_1")),1)]),_:1})]),_:1}),t(f,null,{default:o(()=>[t(c,null,{description:o(()=>[k(" ✓ "+b(i.$t("website.business.advanced_packaging.feature_2")),1)]),_:1})]),_:1}),t(f,null,{default:o(()=>[t(c,null,{description:o(()=>[k(" ✓ "+b(i.$t("website.business.advanced_packaging.feature_3")),1)]),_:1})]),_:1})]),_:1}),t(r,{justify:"center",size:16},{default:o(()=>[t(d,{type:"primary",onClick:s[0]||(s[0]=y=>i.$emit("get-solution","advanced-packaging"))},{default:o(()=>[k(b(i.$t("website.cta.get_solution")),1)]),_:1}),t(d,{type:"default",onClick:s[1]||(s[1]=y=>i.$emit("tech-consultation","advanced-packaging"))},{default:o(()=>[k(b(i.$t("website.cta.tech_consultation")),1)]),_:1})]),_:1})]),_:1})]),_:1})]),_:1}),t(_,null,{default:o(()=>[t(x,{hoverable:"",class:"service-card",onMouseenter:s[6]||(s[6]=y=>i.$emit("start-hover")),onMouseleave:s[7]||(s[7]=y=>i.$emit("end-hover"))},{default:o(()=>[t(r,{vertical:"",size:20},{default:o(()=>[t(r,{justify:"center"},{default:o(()=>[t(p,{src:V(Y)("business","hardware_solution"),"fallback-src":V(ee).technology,alt:"硬件方案",width:"80",height:"80","object-fit":"cover",style:{"border-radius":"8px"}},null,8,["src","fallback-src"])]),_:1}),t(r,{vertical:"",align:"center",size:12},{default:o(()=>[t(a,{style:{fontSize:"var(--sipumtech-font-size-small)",fontWeight:"var(--sipumtech-font-weight-semibold)",color:"var(--sipumtech-accent-orange)",textTransform:"uppercase",letterSpacing:"1px"}},{default:o(()=>[k(b(i.$t("website.business.hardware_solution.brand")),1)]),_:1}),t(a,{style:{fontSize:"var(--sipumtech-font-size-body)",fontWeight:"var(--sipumtech-font-weight-semibold)",color:"var(--sipumtech-text-secondary)"}},{default:o(()=>[k(b(i.$t("website.business.hardware_solution.subtitle")),1)]),_:1}),t(a,{style:{fontSize:"var(--sipumtech-font-size-h4)",fontWeight:"var(--sipumtech-font-weight-bold)",color:"var(--sipumtech-primary-blue)",lineHeight:"1.3"}},{default:o(()=>[k(b(i.$t("website.business.hardware_solution.title")),1)]),_:1}),t(a,{style:{fontSize:"var(--sipumtech-font-size-body)",color:"var(--sipumtech-text-secondary)",lineHeight:"var(--sipumtech-line-height-relaxed)",textAlign:"center"}},{default:o(()=>[k(b(i.$t("website.business.hardware_solution.description")),1)]),_:1})]),_:1}),t(h,null,{default:o(()=>[t(f,null,{default:o(()=>[t(c,null,{description:o(()=>[k(" ✓ "+b(i.$t("website.business.hardware_solution.feature_1")),1)]),_:1})]),_:1}),t(f,null,{default:o(()=>[t(c,null,{description:o(()=>[k(" ✓ "+b(i.$t("website.business.hardware_solution.feature_2")),1)]),_:1})]),_:1}),t(f,null,{default:o(()=>[t(c,null,{description:o(()=>[k(" ✓ "+b(i.$t("website.business.hardware_solution.feature_3")),1)]),_:1})]),_:1})]),_:1}),t(r,{justify:"center",size:16},{default:o(()=>[t(d,{type:"primary",onClick:s[4]||(s[4]=y=>i.$emit("get-solution","hardware-solution"))},{default:o(()=>[k(b(i.$t("website.cta.get_solution")),1)]),_:1}),t(d,{type:"default",onClick:s[5]||(s[5]=y=>i.$emit("tech-consultation","hardware-solution"))},{default:o(()=>[k(b(i.$t("website.cta.tech_consultation")),1)]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})])])])}}},ni=se(ti,[["__scopeId","data-v-b86789f0"]]);const ye=e=>(ve("data-v-39371ae9"),e=e(),me(),e),oi={id:"technology",class:"technology-section section-full"},si={class:"section-container"},ii={class:"section-title"},ai=ye(()=>l("div",{class:"title-underline"},null,-1)),ri={class:"section-subtitle"},li={class:"tech-overview-title"},ci={class:"tech-overview-desc"},di={class:"highlight-title"},ui={class:"highlight-desc"},fi={class:"highlight-title"},gi={class:"highlight-desc"},pi={class:"highlight-title"},hi={class:"highlight-desc"},vi={class:"technology-steps"},mi={class:"custom-steps"},_i={class:"step-item"},bi=ye(()=>l("div",{class:"step-indicator"},[l("div",{class:"step-icon"},[l("svg",{viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},[l("path",{d:"M20 6L9 17L4 12",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"})])])],-1)),yi={class:"step-content"},wi={class:"step-title"},xi={class:"step-description"},$i=ye(()=>l("div",{class:"step-connector"},null,-1)),zi={class:"step-item"},Si=ye(()=>l("div",{class:"step-indicator"},[l("div",{class:"step-icon"},[l("svg",{viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},[l("path",{d:"M20 6L9 17L4 12",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"})])])],-1)),ki={class:"step-content"},Ci={class:"step-title"},Ri={class:"step-description"},Pi=ye(()=>l("div",{class:"step-connector"},null,-1)),Ii={class:"step-item"},Ti=ye(()=>l("div",{class:"step-indicator"},[l("div",{class:"step-icon"},[l("svg",{viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},[l("path",{d:"M20 6L9 17L4 12",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"})])])],-1)),ji={class:"step-content"},Bi={class:"step-title"},Ni={class:"step-description"},Ei=ye(()=>l("div",{class:"step-connector"},null,-1)),Mi={class:"step-item"},Oi=ye(()=>l("div",{class:"step-indicator"},[l("div",{class:"step-icon"},[l("svg",{viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},[l("path",{d:"M20 6L9 17L4 12",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"})])])],-1)),Di={class:"step-content"},Li={class:"step-title"},Vi={class:"step-description"},Hi={__name:"TechnologySection",setup(e){return(n,i)=>{const s=ae,a=$t,r=_e,p=Ce,c=Re,f=ke,h=zt,d=be;return E(),L("section",oi,[l("div",si,[t(s,{vertical:"",align:"center",size:20,style:{"margin-bottom":"80px"}},{default:o(()=>[l("h2",ii,b(n.$t("website.technology.title")),1),ai,l("p",ri,b(n.$t("website.technology.subtitle")),1)]),_:1}),t(s,{vertical:"",size:60,class:"technology-content"},{default:o(()=>[t(c,{cols:"xs:1 s:2 m:4 l:4 xl:4","x-gap":24,"y-gap":24,responsive:"screen",class:"technology-kpi-band"},{default:o(()=>[t(p,null,{default:o(()=>[t(r,{size:"small",class:"kpi-card",hoverable:""},{default:o(()=>[t(a,{"tabular-nums":!0},{label:o(()=>[k(b(n.$t("website.technology.kpi_projects_label")),1)]),default:o(()=>[k(" 120 ")]),suffix:o(()=>[k(" + ")]),_:1})]),_:1})]),_:1}),t(p,null,{default:o(()=>[t(r,{size:"small",class:"kpi-card",hoverable:""},{default:o(()=>[t(a,{"tabular-nums":!0},{label:o(()=>[k(b(n.$t("website.technology.kpi_lead_time_label")),1)]),prefix:o(()=>[k(" ≤ ")]),default:o(()=>[k(" 4 ")]),suffix:o(()=>[k(b(n.$t("website.technology.kpi_lead_time_unit")),1)]),_:1})]),_:1})]),_:1}),t(p,null,{default:o(()=>[t(r,{size:"small",class:"kpi-card",hoverable:""},{default:o(()=>[t(a,{"tabular-nums":!0},{label:o(()=>[k(b(n.$t("website.technology.kpi_csat_label")),1)]),default:o(()=>[k(" 98 ")]),suffix:o(()=>[k(" % ")]),_:1})]),_:1})]),_:1}),t(p,null,{default:o(()=>[t(r,{size:"small",class:"kpi-card",hoverable:""},{default:o(()=>[t(a,{"tabular-nums":!0},{label:o(()=>[k(b(n.$t("website.technology.kpi_patents_label")),1)]),default:o(()=>[k(" 30 ")]),suffix:o(()=>[k(" + ")]),_:1})]),_:1})]),_:1})]),_:1}),t(c,{cols:"xs:1 s:1 m:2 l:2 xl:2","x-gap":"xs:20 s:30 m:40 l:60 xl:60","y-gap":"xs:30 s:30 m:40 l:40 xl:40",responsive:"screen","align-items":"center"},{default:o(()=>[t(p,null,{default:o(()=>[t(f,{src:V(Y)("technology","lab_equipment"),"fallback-src":V(ee).technology,alt:"业务范围","object-fit":"cover",width:"100%",class:"tech-overview-image"},null,8,["src","fallback-src"])]),_:1}),t(p,null,{default:o(()=>[t(s,{vertical:"",size:25,class:"tech-overview-content"},{default:o(()=>[t(s,{vertical:"",size:14},{default:o(()=>[l("h3",li,b(n.$t("website.technology.overview_title")),1),l("p",ci,b(n.$t("website.technology.overview_description")),1)]),_:1}),t(s,{vertical:"",size:18,class:"tech-highlights"},{default:o(()=>[t(s,{align:"flex-start",size:14,class:"highlight-item"},{default:o(()=>[t(h,{size:36,color:"#f0f9ff",style:{background:"#f0f9ff",color:"#1e3a8a"},class:"highlight-avatar"},{default:o(()=>[k(" 🔬 ")]),_:1}),t(s,{vertical:"",size:3},{default:o(()=>[l("h4",di,b(n.$t("website.technology.highlight_1_title")),1),l("p",ui,b(n.$t("website.technology.highlight_1_desc")),1)]),_:1})]),_:1}),t(s,{align:"flex-start",size:14,class:"highlight-item"},{default:o(()=>[t(h,{size:36,color:"#f0f9ff",style:{background:"#f0f9ff",color:"#1e3a8a"},class:"highlight-avatar"},{default:o(()=>[k(" ⚡ ")]),_:1}),t(s,{vertical:"",size:3},{default:o(()=>[l("h4",fi,b(n.$t("website.technology.highlight_2_title")),1),l("p",gi,b(n.$t("website.technology.highlight_2_desc")),1)]),_:1})]),_:1}),t(s,{align:"flex-start",size:14,class:"highlight-item"},{default:o(()=>[t(h,{size:36,color:"#f0f9ff",style:{background:"#f0f9ff",color:"#1e3a8a"},class:"highlight-avatar"},{default:o(()=>[k(" 🎯 ")]),_:1}),t(s,{vertical:"",size:3},{default:o(()=>[l("h4",pi,b(n.$t("website.technology.highlight_3_title")),1),l("p",hi,b(n.$t("website.technology.highlight_3_desc")),1)]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1}),l("div",vi,[l("div",mi,[l("div",_i,[bi,l("div",yi,[l("div",wi,b(n.$t("website.technology.step_discover_title")),1),l("div",xi,b(n.$t("website.technology.step_discover_desc")),1)]),$i]),l("div",zi,[Si,l("div",ki,[l("div",Ci,b(n.$t("website.technology.step_design_title")),1),l("div",Ri,b(n.$t("website.technology.step_design_desc")),1)]),Pi]),l("div",Ii,[Ti,l("div",ji,[l("div",Bi,b(n.$t("website.technology.step_validate_title")),1),l("div",Ni,b(n.$t("website.technology.step_validate_desc")),1)]),Ei]),l("div",Mi,[Oi,l("div",Di,[l("div",Li,b(n.$t("website.technology.step_delivery_title")),1),l("div",Vi,b(n.$t("website.technology.step_delivery_desc")),1)])])])]),t(c,{cols:"xs:1 s:2 m:2 l:4 xl:4","x-gap":"xs:16 s:20 m:24 l:30 xl:30","y-gap":"xs:20 s:24 m:24 l:30 xl:30",responsive:"screen"},{default:o(()=>[t(p,null,{default:o(()=>[t(r,{hoverable:"",class:"capability-card"},{default:o(()=>[t(s,{vertical:"",align:"center",size:20},{default:o(()=>[t(f,{src:V(Y)("technology","pcb_design"),"fallback-src":V(ee).technology,alt:n.$t("website.technology.capability_1_title"),width:"80",height:"80","object-fit":"cover",style:{"border-radius":"8px"},class:"capability-icon"},null,8,["src","fallback-src","alt"]),t(s,{vertical:"",align:"center",size:12},{default:o(()=>[t(d,{class:"capability-title"},{default:o(()=>[k(b(n.$t("website.technology.capability_1_title")),1)]),_:1}),t(d,{class:"capability-desc"},{default:o(()=>[k(b(n.$t("website.technology.capability_1_desc")),1)]),_:1})]),_:1})]),_:1})]),_:1})]),_:1}),t(p,null,{default:o(()=>[t(r,{hoverable:"",class:"capability-card"},{default:o(()=>[t(s,{vertical:"",align:"center",size:20},{default:o(()=>[t(f,{src:V(Y)("technology","testing_facility"),"fallback-src":V(ee).technology,alt:n.$t("website.technology.capability_2_title"),width:"80",height:"80","object-fit":"cover",style:{"border-radius":"8px"},class:"capability-icon"},null,8,["src","fallback-src","alt"]),t(s,{vertical:"",align:"center",size:12},{default:o(()=>[t(d,{class:"capability-title"},{default:o(()=>[k(b(n.$t("website.technology.capability_2_title")),1)]),_:1}),t(d,{class:"capability-desc"},{default:o(()=>[k(b(n.$t("website.technology.capability_2_desc")),1)]),_:1})]),_:1})]),_:1})]),_:1})]),_:1}),t(p,null,{default:o(()=>[t(r,{hoverable:"",class:"capability-card"},{default:o(()=>[t(s,{vertical:"",align:"center",size:20},{default:o(()=>[t(f,{src:"/images/icon_ic_testing.jpg",alt:n.$t("website.technology.capability_3_title"),width:"80",height:"80","object-fit":"cover",style:{"border-radius":"8px"},class:"capability-icon"},null,8,["alt"]),t(s,{vertical:"",align:"center",size:12},{default:o(()=>[t(d,{class:"capability-title"},{default:o(()=>[k(b(n.$t("website.technology.capability_3_title")),1)]),_:1}),t(d,{class:"capability-desc"},{default:o(()=>[k(b(n.$t("website.technology.capability_3_desc")),1)]),_:1})]),_:1})]),_:1})]),_:1})]),_:1}),t(p,null,{default:o(()=>[t(r,{hoverable:"",class:"capability-card"},{default:o(()=>[t(s,{vertical:"",align:"center",size:20},{default:o(()=>[t(f,{src:"/images/technical_chart_circuit.jpg",alt:n.$t("website.technology.capability_4_title"),width:"80",height:"80","object-fit":"cover",style:{"border-radius":"8px"},class:"capability-icon"},null,8,["alt"]),t(s,{vertical:"",align:"center",size:12},{default:o(()=>[t(d,{class:"capability-title"},{default:o(()=>[k(b(n.$t("website.technology.capability_4_title")),1)]),_:1}),t(d,{class:"capability-desc"},{default:o(()=>[k(b(n.$t("website.technology.capability_4_desc")),1)]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})])])}}},Wi=se(Hi,[["__scopeId","data-v-39371ae9"]]);const Ai=e=>(ve("data-v-94a727c9"),e=e(),me(),e),qi={id:"cases",class:"cases-section section-half"},Fi={class:"section-container"},Yi={class:"section-title"},Xi=Ai(()=>l("div",{class:"title-underline"},null,-1)),Ui={class:"section-subtitle"},Ki={class:"center-content"},Gi=["onMouseenter","onMouseleave"],Zi={__name:"CasesSection",setup(e){const n=j(null),i=j(!1),s=j(-1),a=j([{icon:"🔧",key:"service_1"},{icon:"💻",key:"service_2"},{icon:"📊",key:"service_3"},{icon:"🧪",key:"service_4"},{icon:"⚙️",key:"service_5"},{icon:"🛠️",key:"service_6"}]),{stop:r}=ho(n,([{isIntersecting:c}])=>{c&&setTimeout(()=>{i.value=!0},200)},{threshold:.3,rootMargin:"-50px"}),p=(c,f)=>{s.value=f?c:-1};return nt(()=>{r()}),(c,f)=>{const h=ae,d=be,x=zt,_=_e;return E(),L("section",qi,[l("div",Fi,[t(h,{vertical:"",align:"center",size:20,style:{"margin-bottom":"80px"}},{default:o(()=>[l("h2",Yi,b(c.$t("website.cases.title")),1),Xi,l("p",Ui,b(c.$t("website.cases.subtitle")),1)]),_:1}),l("div",{class:"circular-services-container",ref_key:"circularContainer",ref:n},[l("div",{class:Ke(["center-circle",{"animate-in":i.value}])},[l("div",Ki,[t(d,{style:{fontSize:"24px",fontWeight:"var(--sipumtech-font-weight-bold)",color:"#ffffff",lineHeight:"1.3",textAlign:"center",textShadow:"0 2px 4px rgba(0, 0, 0, 0.3)"}},{default:o(()=>[k(b(c.$t("website.cases.center_title")),1)]),_:1}),t(d,{style:{fontSize:"14px",color:"#ffffff",opacity:"0.95",marginTop:"6px",textAlign:"center",fontWeight:"var(--sipumtech-font-weight-medium)",letterSpacing:"1px"}},{default:o(()=>[k(b(c.$t("website.cases.center_subtitle")),1)]),_:1})])],2),(E(!0),L(ce,null,ue(a.value,($,y)=>(E(),L("div",{key:`service-${$.key}-${y}`,class:Ke(["service-item",{"animate-in":i.value}]),style:ze({"--delay":`${y*.1}s`,"--angle":`${360/a.value.length*y}deg`}),onMouseenter:z=>p(y,!0),onMouseleave:z=>p(y,!1)},[t(_,{hoverable:"",class:Ke(["service-card",{hovered:s.value===y}])},{default:o(()=>[t(h,{vertical:"",align:"center",size:12},{default:o(()=>[t(x,{size:60,style:{background:"linear-gradient(135deg, var(--sipumtech-primary-blue), var(--sipumtech-accent-blue))",color:"#ffffff",fontSize:"28px"}},{default:o(()=>[k(b($.icon),1)]),_:2},1024),t(d,{style:{fontSize:"16px",fontWeight:"var(--sipumtech-font-weight-bold)",color:"var(--sipumtech-primary-blue)",textAlign:"center",lineHeight:"1.3"}},{default:o(()=>[k(b(c.$t(`website.cases.service_${y+1}_title`)),1)]),_:2},1024),t(d,{class:"service-description",style:{fontSize:"12px",color:"var(--sipumtech-text-secondary)",textAlign:"center",lineHeight:"1.4",whiteSpace:"pre-line"}},{default:o(()=>[k(b(c.$t(`website.cases.service_${y+1}_desc`)),1)]),_:2},1024)]),_:2},1024)]),_:2},1032,["class"])],46,Gi))),128)),l("div",{class:Ke(["connection-lines",{"animate-in":i.value}])},[(E(!0),L(ce,null,ue(a.value.length,$=>(E(),L("div",{key:`connection-line-${$}`,class:"connection-line",style:ze({"--line-angle":`${360/a.value.length*($-1)}deg`,"--delay":`${.8+$*.05}s`})},null,4))),128))],2)],512)])])}}},Ji=se(Zi,[["__scopeId","data-v-94a727c9"]]);function vn(e,n={}){const{immediate:i=!1,resetOnExecute:s=!0,shallow:a=!0,delay:r=0,onError:p=null,onSuccess:c=null}=n,f=j(!1),h=j(!1),d=j(null),x=j(null),_=P(()=>h.value&&!d.value),$=P(()=>!!d.value),y=(...g)=>Be(this,null,function*(){s&&(x.value=null,d.value=null),f.value=!0,h.value=!1;try{r>0&&(yield new Promise(w=>setTimeout(w,r)));const u=yield e(...g);return x.value=a?u:JSON.parse(JSON.stringify(u)),c&&c(u),u}catch(u){throw d.value=u,p&&p(u),u}finally{f.value=!1,h.value=!0}}),z=(...g)=>y(...g),C=()=>{f.value=!1,h.value=!1,d.value=null,x.value=null};return i&&y(),{isLoading:f,isFinished:h,isReady:_,hasError:$,error:d,data:x,execute:y,retry:z,reset:C}}const Qi=e=>(ve("data-v-c9f08e8d"),e=e(),me(),e),ea={class:"testimonial-wrapper"},ta={class:"quote-icon-wrapper"},na=Qi(()=>l("svg",{viewBox:"0 0 24 24"},[l("path",{fill:"currentColor",d:"M6 17h3l2-4V7H5v6h3zm8 0h3l2-4V7h-6v6h3z"})],-1)),oa={class:"avatar-wrapper"},sa={class:"customer-name"},ia={class:"customer-title"},aa={class:"company-name"},ra={__name:"CustomerTestimonial",props:{quote:{type:String,required:!0},customerName:{type:String,required:!0},customerTitle:{type:String,default:""},companyName:{type:String,required:!0},avatar:{type:String,default:""},projectTags:{type:Array,default:()=>[]},rating:{type:Number,default:5,validator:e=>e>=1&&e<=5}},setup(e){return(n,i)=>{const s=xt,a=ae,r=Es,p=zt,c=cn,f=ws,h=_e;return E(),L("div",ea,[t(h,{hoverable:"",class:"testimonial-card"},{default:o(()=>[t(a,{vertical:"",size:20},{default:o(()=>[t(a,{justify:"center"},{default:o(()=>[l("div",ta,[t(s,{size:32,color:"var(--sipumtech-accent-green)"},{default:o(()=>[na]),_:1})])]),_:1}),t(r,{class:"testimonial-quote"},{default:o(()=>[k(b(e.quote),1)]),_:1}),t(a,{align:"center",size:16},{default:o(()=>[l("div",oa,[t(p,{size:50,src:e.avatar,"fallback-src":"/images/default-avatar.png",round:""},null,8,["src"])]),t(a,{vertical:"",size:4},{default:o(()=>[l("h4",sa,b(e.customerName),1),l("p",ia,b(e.customerTitle),1),l("p",aa,b(e.companyName),1)]),_:1})]),_:1}),e.projectTags&&e.projectTags.length?(E(),oe(a,{key:0,size:8,justify:"center"},{default:o(()=>[(E(!0),L(ce,null,ue(e.projectTags,d=>(E(),oe(c,{key:d,type:"info",size:"small",round:"",class:"project-tag"},{default:o(()=>[k(b(d),1)]),_:2},1024))),128))]),_:1})):fe("",!0),e.rating?(E(),oe(a,{key:1,justify:"center"},{default:o(()=>[t(f,{value:e.rating,readonly:"",size:16,color:"var(--sipumtech-trust-gold)"},null,8,["value"])]),_:1})):fe("",!0)]),_:1})]),_:1})])}}},Ze=se(ra,[["__scopeId","data-v-c9f08e8d"]]);const la=e=>(ve("data-v-3c23ea94"),e=e(),me(),e),ca={class:"stats-wrapper"},da={class:"stats-title"},ua=la(()=>l("div",{class:"title-underline"},null,-1)),fa={class:"stats-data-section"},ga={class:"stat-item"},pa={class:"stat-suffix"},ha={class:"stat-item"},va={class:"stat-item"},ma={class:"stat-item"},_a={class:"stat-suffix"},ba={class:"stat-item"},ya={class:"stat-suffix"},wa={class:"stat-item"},xa={class:"stat-suffix"},$a={class:"certifications-section"},za={class:"cert-container"},Sa={class:"cert-overlay"},ka={class:"cert-container"},Ca={class:"cert-overlay"},Ra={class:"hover-image-container"},Pa={class:"hover-image-header"},Ia={__name:"CompanyStats",props:{title:{type:String,default:""}},setup(e){he();const n=dn({sm:768,md:1024,lg:1200}),i=P(()=>n.md.value?2:1),s=P(()=>n.lg.value?3:(n.md.value||n.sm.value,2)),a=P(()=>n.lg.value?{width:150,height:150}:n.md.value?{width:130,height:130}:{width:110,height:110}),r=P(()=>({fontSize:"36px",fontWeight:"bold",color:"var(--sipumtech-primary-blue)",textShadow:"0 2px 4px rgba(0, 0, 0, 0.1)"})),p=j(!1),c=j(""),f=j(""),h=j({});let d=null;const x=(y,z,C)=>{d&&clearTimeout(d),c.value=Y("certificates",y),f.value=z;const g=C.currentTarget.getBoundingClientRect(),u=window.innerWidth,w=window.innerHeight,S=320,I=380;let T=g.right+20,B=g.top+(g.height-I)/2;T+S>u-20&&(T=g.left-S-20),B<20?B=20:B+I>w-20&&(B=w-I-20),h.value={position:"fixed",left:`${T}px`,top:`${B}px`,zIndex:9999},p.value=!0},_=()=>{d=setTimeout(()=>{p.value=!1,c.value="",f.value=""},100)},$=()=>{d&&(clearTimeout(d),d=null)};return(y,z)=>{const C=ae,g=$t,u=Ce,w=Re,S=ke,I=be,T=vo,B=_e;return E(),L("div",ca,[t(B,{class:"stats-card"},{default:o(()=>[t(C,{vertical:"",size:40},{default:o(()=>[t(C,{vertical:"",align:"center",size:16},{default:o(()=>[l("h3",da,b(e.title||y.$t("website.stats.title")),1),ua]),_:1}),t(w,{cols:i.value,"x-gap":40,"y-gap":40},{default:o(()=>[t(u,null,{default:o(()=>[l("div",fa,[t(w,{cols:s.value,"x-gap":20,"y-gap":30},{default:o(()=>[t(u,null,{default:o(()=>[l("div",ga,[t(g,{label:y.$t("website.stats.founded_year"),value:2019,"value-style":r.value},{suffix:o(()=>[l("span",pa,b(y.$t("website.stats.year")),1)]),_:1},8,["label","value-style"])])]),_:1}),t(u,null,{default:o(()=>[l("div",ha,[t(g,{label:y.$t("website.stats.clients_served"),value:"100+","value-style":r.value},null,8,["label","value-style"])])]),_:1}),t(u,null,{default:o(()=>[l("div",va,[t(g,{label:y.$t("website.stats.projects_completed"),value:"200+","value-style":r.value},null,8,["label","value-style"])])]),_:1}),t(u,null,{default:o(()=>[l("div",ma,[t(g,{label:y.$t("website.stats.team_size"),value:"15+","value-style":r.value},{suffix:o(()=>[l("span",_a,b(y.$t("website.stats.people")),1)]),_:1},8,["label","value-style"])])]),_:1}),t(u,null,{default:o(()=>[l("div",ba,[t(g,{label:y.$t("website.stats.patents"),value:"5+","value-style":r.value},{suffix:o(()=>[l("span",ya,b(y.$t("website.stats.items")),1)]),_:1},8,["label","value-style"])])]),_:1}),t(u,null,{default:o(()=>[l("div",wa,[t(g,{label:y.$t("website.stats.industry_experience"),value:"5+","value-style":r.value},{suffix:o(()=>[l("span",xa,b(y.$t("website.stats.years")),1)]),_:1},8,["label","value-style"])])]),_:1})]),_:1},8,["cols"])])]),_:1}),t(u,null,{default:o(()=>[l("div",$a,[t(C,{size:30,justify:"center",align:"center"},{default:o(()=>[l("div",za,[t(T,{trigger:"hover",placement:"top"},{trigger:o(()=>[l("div",{class:"cert-card",onMouseenter:z[0]||(z[0]=F=>x("iso9001",y.$t("website.stats.iso_certification"),F)),onMouseleave:_},[t(S,{src:V(Y)("certificates","iso9001"),"fallback-src":V(ee).certificate,alt:"ISO9001认证",width:a.value.width,height:a.value.height,"object-fit":"contain",class:"cert-image"},null,8,["src","fallback-src","width","height"]),l("div",Sa,[t(I,{class:"cert-name"},{default:o(()=>[k("ISO9001")]),_:1})])],32)]),default:o(()=>[k(" "+b(y.$t("website.stats.iso_certification")),1)]),_:1})]),l("div",ka,[t(T,{trigger:"hover",placement:"top"},{trigger:o(()=>[l("div",{class:"cert-card",onMouseenter:z[1]||(z[1]=F=>x("military",y.$t("website.stats.military_certification"),F)),onMouseleave:_},[t(S,{src:V(Y)("certificates","military"),"fallback-src":V(ee).certificate,alt:"军工认证",width:a.value.width,height:a.value.height,"object-fit":"contain",class:"cert-image"},null,8,["src","fallback-src","width","height"]),l("div",Ca,[t(I,{class:"cert-name"},{default:o(()=>[k("军工认证")]),_:1})])],32)]),default:o(()=>[k(" "+b(y.$t("website.stats.military_certification")),1)]),_:1})])]),_:1})])]),_:1})]),_:1},8,["cols"])]),_:1})]),_:1}),p.value?(E(),L("div",{key:0,class:"hover-image-overlay",style:ze(h.value),onMouseenter:$,onMouseleave:_},[l("div",Ra,[l("div",Pa,[t(I,{strong:"",class:"hover-image-title"},{default:o(()=>[k(b(f.value),1)]),_:1})]),t(S,{src:c.value,"fallback-src":V(ee).certificate,alt:f.value,"object-fit":"contain",class:"hover-cert-image",width:"300",height:"300"},null,8,["src","fallback-src","alt"])])],36)):fe("",!0)])}}},Ta=se(Ia,[["__scopeId","data-v-3c23ea94"]]);const ja={class:"loading-state"},Ba={key:0,class:"skeleton-container"},Na={key:0,class:"skeleton-card"},Ea={key:1,class:"skeleton-list"},Ma={style:{flex:"1"}},Oa={key:2,class:"skeleton-article"},Da={key:3,class:"skeleton-grid"},La={key:4,class:"skeleton-custom"},Va={key:1,class:"spinner-container"},Ha={key:0,class:"loading-message"},Wa={key:2,class:"progress-container"},Aa={key:0,class:"loading-message"},qa={key:3,class:"custom-container"},Fa={class:"loading-message"},Ya={__name:"LoadingState",props:{type:{type:String,default:"skeleton",validator:e=>["skeleton","spinner","progress","custom"].includes(e)},variant:{type:String,default:"card",validator:e=>["card","list","article","grid","custom"].includes(e)},message:{type:String,default:""},spinnerSize:{type:String,default:"medium",validator:e=>["small","medium","large"].includes(e)},percentage:{type:Number,default:0,validator:e=>e>=0&&e<=100},showPercentage:{type:Boolean,default:!0},progressStatus:{type:String,default:"default",validator:e=>["default","success","error","warning"].includes(e)},rows:{type:Number,default:3},gridItems:{type:Number,default:6},minHeight:{type:String,default:"200px"}},setup(e){return mo(n=>({c03881ba:e.minHeight})),he(),(n,i)=>{const s=ks,a=hn,r=ae,p=pn;return E(),L("div",ja,[e.type==="skeleton"?(E(),L("div",Ba,[e.variant==="card"?(E(),L("div",Na,[t(s,{height:"200px",style:{"margin-bottom":"16px"}}),t(s,{text:"",repeat:3}),t(s,{text:"",style:{width:"60%","margin-top":"8px"}})])):e.variant==="list"?(E(),L("div",Ea,[(E(!0),L(ce,null,ue(e.rows,c=>(E(),L("div",{key:c,class:"skeleton-list-item"},[t(s,{circle:"",size:"medium",style:{"margin-right":"16px"}}),l("div",Ma,[t(s,{text:"",style:{width:"80%","margin-bottom":"8px"}}),t(s,{text:"",style:{width:"60%"}})])]))),128))])):e.variant==="article"?(E(),L("div",Oa,[t(s,{text:"",style:{width:"80%",height:"32px","margin-bottom":"16px"}}),t(s,{text:"",style:{width:"60%","margin-bottom":"24px"}}),t(s,{height:"200px",style:{"margin-bottom":"16px"}}),t(s,{text:"",repeat:4})])):e.variant==="grid"?(E(),L("div",Da,[(E(!0),L(ce,null,ue(e.gridItems,c=>(E(),L("div",{key:c,class:"skeleton-grid-item"},[t(s,{height:"150px",style:{"margin-bottom":"12px"}}),t(s,{text:"",style:{"margin-bottom":"8px"}}),t(s,{text:"",style:{width:"70%"}})]))),128))])):(E(),L("div",La,[mt(n.$slots,"skeleton",{},()=>[t(s,{text:"",repeat:3})],!0)]))])):e.type==="spinner"?(E(),L("div",Va,[t(r,{vertical:"",align:"center",size:20},{default:o(()=>[t(a,{size:e.spinnerSize},null,8,["size"]),e.message?(E(),L("div",Ha,b(e.message),1)):fe("",!0)]),_:1})])):e.type==="progress"?(E(),L("div",Wa,[t(r,{vertical:"",size:16},{default:o(()=>[e.message?(E(),L("div",Aa,b(e.message),1)):fe("",!0),t(p,{type:"line",percentage:e.percentage,"show-indicator":e.showPercentage,status:e.progressStatus},null,8,["percentage","show-indicator","status"])]),_:1})])):(E(),L("div",qa,[mt(n.$slots,"loading",{},()=>[t(r,{vertical:"",align:"center",size:20},{default:o(()=>[t(a,{size:"large"}),l("div",Fa,b(e.message||n.$t("common.loading")),1)]),_:1})],!0)]))])}}},mn=se(Ya,[["__scopeId","data-v-ab2492bf"]]);const Xa={class:"error-boundary"},Ua={key:0,class:"content-wrapper"},Ka={__name:"ErrorBoundary",props:{title:{type:String,default:""},description:{type:String,default:""},showRetry:{type:Boolean,default:!0},showReload:{type:Boolean,default:!0},onError:{type:Function,default:null}},emits:["error","retry"],setup(e,{expose:n,emit:i}){const s=e,a=i,{t:r}=he(),p=j(!1),c=j(null),f=P(()=>s.title?s.title:r("error.component_error_title")),h=P(()=>{var $;return s.description?s.description:($=c.value)!=null&&$.message?`${r("error.component_error_description")}: ${c.value.message}`:r("error.component_error_description")});_o(($,y,z)=>(console.error("ErrorBoundary caught an error:",$,z),p.value=!0,c.value={message:$.message,stack:$.stack,info:z},s.onError&&s.onError($,y,z),a("error",{error:$,instance:y,info:z}),!1));const d=()=>{p.value=!1,c.value=null,a("retry")},x=()=>{window.location.reload()};return n({resetError:()=>{p.value=!1,c.value=null},hasError:P(()=>p.value),errorInfo:P(()=>c.value)}),($,y)=>{const z=Se,C=ae,g=ot;return E(),L("div",Xa,[p.value?(E(),oe(g,{key:1,status:"error",title:f.value,description:h.value,class:"error-result"},{footer:o(()=>[t(C,{size:16},{default:o(()=>[t(z,{type:"primary",onClick:d},{default:o(()=>[k(b($.$t("common.retry")),1)]),_:1}),t(z,{type:"default",onClick:x},{default:o(()=>[k(b($.$t("common.reload_page")),1)]),_:1})]),_:1})]),_:1},8,["title","description"])):(E(),L("div",Ua,[mt($.$slots,"default",{},void 0,!0)]))])}}},_n=se(Ka,[["__scopeId","data-v-f6840b93"]]);const Ga=e=>(ve("data-v-8f73cb1d"),e=e(),me(),e),Za={class:"trust-building-section"},Ja={class:"section-container"},Qa=Ga(()=>l("div",{class:"title-underline"},null,-1)),er={class:"testimonials-title"},tr={class:"testimonials-subtitle"},nr={class:"testimonials-slide"},or={class:"testimonials-slide"},sr={class:"partners-title"},ir={class:"partners-subtitle"},ar={key:2,class:"partners-container"},rr={class:"partner-card"},lr={class:"partner-card-inner"},cr={class:"partner-logo-container"},dr={class:"partner-overlay"},ur={key:0,class:"more-partners-hint"},fr={__name:"TrustBuildingSection",setup(e){he();const n=dn({sm:768,md:1024,lg:1200}),i=P(()=>n.md.value?2:1),s=P(()=>n.lg.value?6:n.md.value?4:n.sm.value?3:2),a=P(()=>n.lg.value?{width:140,height:70}:n.md.value?{width:120,height:60}:{width:100,height:50}),r=P(()=>{if(!c.value||!c.value.length)return[];const _=s.value*2;return c.value.slice(0,_)}),p=()=>Be(this,null,function*(){return yield new Promise(_=>setTimeout(_,800)),[{name:"华为",logo:Y("partners","huawei")},{name:"中兴",logo:Y("partners","zte")},{name:"小米",logo:Y("partners","xiaomi")},{name:"联想",logo:Y("partners","lenovo")},{name:"海康威视",logo:Y("partners","hikvision")},{name:"大疆",logo:Y("partners","dji")},{name:"腾讯",logo:Y("business","advanced_packaging")},{name:"阿里巴巴",logo:Y("business","hardware_solution")},{name:"百度",logo:Y("technology","pcb_design")},{name:"京东",logo:Y("cases","automotive")},{name:"美团",logo:Y("cases","consumer")},{name:"字节跳动",logo:Y("cases","industrial")}]}),{data:c,isLoading:f,hasError:h,execute:d,retry:x}=vn(p,{immediate:!1});return ge(()=>{d()}),(_,$)=>{const y=be,z=ae,C=Ce,g=Re,u=fn,w=Se,S=ot,I=ke;return E(),L("section",Za,[l("div",Ja,[t(z,{vertical:"",align:"center",size:20,style:{"margin-bottom":"80px"}},{default:o(()=>[t(y,{style:{fontSize:"var(--sipumtech-font-size-h1)",fontWeight:"var(--sipumtech-font-weight-bold)",color:"var(--sipumtech-primary-blue)",lineHeight:"var(--sipumtech-line-height-tight)"}},{default:o(()=>[k(b(_.$t("website.trust.title")),1)]),_:1}),Qa,t(y,{style:{fontSize:"18px",color:"var(--sipumtech-text-secondary)",lineHeight:"var(--sipumtech-line-height-relaxed)"}},{default:o(()=>[k(b(_.$t("website.trust.subtitle")),1)]),_:1})]),_:1}),t(z,{vertical:"",size:80},{default:o(()=>[t(Ta),t(z,{vertical:"",size:40},{default:o(()=>[t(z,{vertical:"",align:"center",size:16},{default:o(()=>[l("h3",er,b(_.$t("website.trust.testimonials_title")),1),l("p",tr,b(_.$t("website.trust.testimonials_subtitle")),1)]),_:1}),t(u,{autoplay:!0,interval:6e3,"show-dots":!0,"show-arrow":!1,style:{height:"auto"}},{default:o(()=>[l("div",nr,[t(g,{cols:i.value,"x-gap":30,"y-gap":30},{default:o(()=>[t(C,null,{default:o(()=>[t(Ze,{quote:_.$t("website.trust.testimonial_1_quote"),"customer-name":_.$t("website.trust.testimonial_1_name"),"customer-title":_.$t("website.trust.testimonial_1_title"),"company-name":_.$t("website.trust.testimonial_1_company"),avatar:V(Y)("customers","avatar_1"),"project-tags":[_.$t("website.project_tags.advanced_packaging"),_.$t("website.project_tags.pcb_design")],rating:5},null,8,["quote","customer-name","customer-title","company-name","avatar","project-tags"])]),_:1}),t(C,null,{default:o(()=>[t(Ze,{quote:_.$t("website.trust.testimonial_2_quote"),"customer-name":_.$t("website.trust.testimonial_2_name"),"customer-title":_.$t("website.trust.testimonial_2_title"),"company-name":_.$t("website.trust.testimonial_2_company"),avatar:V(Y)("customers","avatar_2"),"project-tags":[_.$t("website.project_tags.hardware_solution"),_.$t("website.project_tags.system_testing")],rating:5},null,8,["quote","customer-name","customer-title","company-name","avatar","project-tags"])]),_:1})]),_:1},8,["cols"])]),l("div",or,[t(g,{cols:i.value,"x-gap":30,"y-gap":30},{default:o(()=>[t(C,null,{default:o(()=>[t(Ze,{quote:_.$t("website.trust.testimonial_3_quote"),"customer-name":_.$t("website.trust.testimonial_3_name"),"customer-title":_.$t("website.trust.testimonial_3_title"),"company-name":_.$t("website.trust.testimonial_3_company"),avatar:V(Y)("customers","avatar_3"),"project-tags":[_.$t("website.project_tags.tech_consultation"),_.$t("website.project_tags.solution_optimization")],rating:5},null,8,["quote","customer-name","customer-title","company-name","avatar","project-tags"])]),_:1}),t(C,null,{default:o(()=>[t(Ze,{quote:_.$t("website.trust.testimonial_4_quote"),"customer-name":_.$t("website.trust.testimonial_4_name"),"customer-title":_.$t("website.trust.testimonial_4_title"),"company-name":_.$t("website.trust.testimonial_4_company"),avatar:V(Y)("customers","avatar_4"),"project-tags":[_.$t("website.project_tags.one_stop_service"),_.$t("website.project_tags.quality_assurance")],rating:5},null,8,["quote","customer-name","customer-title","company-name","avatar","project-tags"])]),_:1})]),_:1},8,["cols"])])]),_:1})]),_:1}),t(z,{vertical:"",size:30},{default:o(()=>[t(z,{vertical:"",align:"center",size:12},{default:o(()=>[l("h3",sr,b(_.$t("website.trust.partners_title")),1),l("p",ir,b(_.$t("website.trust.partners_subtitle")),1)]),_:1}),t(_n,{onRetry:V(x)},{default:o(()=>[V(f)?(E(),oe(mn,{key:0,type:"skeleton",variant:"grid","grid-items":6,message:"正在加载合作伙伴..."})):V(h)?(E(),oe(S,{key:1,status:"error",title:"合作伙伴加载失败",description:"无法加载合作伙伴信息"},{footer:o(()=>[t(w,{type:"primary",onClick:V(x)},{default:o(()=>[k(b(_.$t("common.retry")),1)]),_:1},8,["onClick"])]),_:1})):V(c)&&V(c).length?(E(),L("div",ar,[t(g,{cols:s.value,"x-gap":10,"y-gap":10,class:"partners-grid"},{default:o(()=>[(E(!0),L(ce,null,ue(r.value,(T,B)=>(E(),oe(C,{key:T.name,class:"partner-grid-item",style:ze({animationDelay:`${B*.05}s`})},{default:o(()=>[l("div",rr,[l("div",lr,[l("div",cr,[t(I,{src:T.logo,alt:T.name,width:a.value.width,height:a.value.height,"object-fit":"contain",class:"partner-logo","fallback-src":V(ee).logo},null,8,["src","alt","width","height","fallback-src"])]),l("div",dr,[t(y,{class:"partner-name"},{default:o(()=>[k(b(T.name),1)]),_:2},1024)])])])]),_:2},1032,["style"]))),128))]),_:1},8,["cols"]),V(c).length>r.value.length?(E(),L("div",ur,[t(y,{class:"more-text"},{default:o(()=>[k(" 还有 "+b(V(c).length-r.value.length)+" 个合作伙伴... ",1)]),_:1})])):fe("",!0)])):fe("",!0)]),_:1},8,["onRetry"])]),_:1})]),_:1})])])}}},gr=se(fr,[["__scopeId","data-v-8f73cb1d"]]);const bn=e=>(ve("data-v-bcb9c008"),e=e(),me(),e),pr={id:"news",class:"news-section section-half"},hr={class:"section-container"},vr=bn(()=>l("div",{class:"title-underline"},null,-1)),mr=bn(()=>l("svg",{viewBox:"0 0 24 24"},[l("path",{fill:"currentColor",d:"M8.59 16.59L13.17 12L8.59 7.41L10 6l6 6l-6 6l-1.41-1.41z"})],-1)),_r={__name:"NewsSection",setup(e){he();const n=j(3),i=j(30),s=j(30),a=j([{id:"news_1",date:"2024-08-06",titleKey:"website.news.news_1_title",excerptKey:"website.news.news_1_excerpt",image:"news_1"},{id:"news_2",date:"2024-07-28",titleKey:"website.news.news_2_title",excerptKey:"website.news.news_2_excerpt",image:"news_2"},{id:"news_3",date:"2024-02-01",titleKey:"website.news.news_3_title",excerptKey:"website.news.news_3_excerpt",image:"news_3"}]),r=()=>Be(this,null,function*(){return yield new Promise(y=>setTimeout(y,1e3)),a.value}),{data:p,isLoading:c,hasError:f,error:h,execute:d,retry:x}=vn(r,{immediate:!1,onError:y=>{console.error("新闻数据加载失败:",y)}});ge(()=>{d()});const _=y=>{console.log("新闻点击:",y)},$=()=>{x()};return(y,z)=>{const C=be,g=ae,u=xt,w=Se,S=ot,I=ke,T=Co,B=_e,F=Ce,te=Re;return E(),L("section",pr,[l("div",hr,[t(g,{justify:"space-between",align:"center",style:{"margin-bottom":"60px"}},{default:o(()=>[t(g,{vertical:"",size:20},{default:o(()=>[t(C,{style:{fontSize:"var(--sipumtech-font-size-h1)",fontWeight:"var(--sipumtech-font-weight-bold)",color:"var(--sipumtech-primary-blue)",lineHeight:"var(--sipumtech-line-height-tight)"}},{default:o(()=>[k(b(y.$t("website.news.title")),1)]),_:1}),vr]),_:1}),t(w,{text:"",tag:"a",href:"#",size:"large",class:"news-more-button"},{default:o(()=>[t(g,{align:"center",size:8},{default:o(()=>[l("span",null,b(y.$t("website.news.more")),1),t(u,{size:16},{default:o(()=>[mr]),_:1})]),_:1})]),_:1})]),_:1}),t(_n,{onRetry:$},{default:o(()=>{var J;return[V(c)?(E(),oe(mn,{key:0,type:"skeleton",variant:"grid","grid-items":3,message:"正在加载新闻..."})):V(f)?(E(),oe(S,{key:1,status:"error",title:y.$t("error.data_load_failed"),description:((J=V(h))==null?void 0:J.message)||y.$t("error.unknown_error")},{footer:o(()=>[t(w,{type:"primary",onClick:$},{default:o(()=>[k(b(y.$t("common.retry")),1)]),_:1})]),_:1},8,["title","description"])):V(p)&&V(p).length?(E(),oe(te,{key:2,cols:n.value,"x-gap":i.value,"y-gap":s.value,"item-responsive":"",responsive:"screen"},{default:o(()=>[(E(!0),L(ce,null,ue(V(p),X=>(E(),oe(F,{key:X.id},{default:o(()=>[t(B,{hoverable:"",class:"news-card",onClick:K=>_(X.id)},{cover:o(()=>[t(I,{src:V(Y)("news",X.image),alt:y.$t(X.titleKey),"fallback-src":V(ee).news,"object-fit":"cover",class:"news-image"},null,8,["src","alt","fallback-src"])]),default:o(()=>[t(g,{vertical:"",size:12},{default:o(()=>[t(C,{class:"news-card-title",style:{fontWeight:"var(--sipumtech-font-weight-semibold)",color:"var(--sipumtech-primary-blue)",lineHeight:"1.4"}},{default:o(()=>[k(b(y.$t(X.titleKey)),1)]),_:2},1024),t(T,{"line-clamp":3,style:{fontSize:"var(--sipumtech-font-size-small)",color:"var(--sipumtech-text-secondary)",lineHeight:"var(--sipumtech-line-height-relaxed)"}},{default:o(()=>[k(b(y.$t(X.excerptKey)),1)]),_:2},1024)]),_:2},1024)]),_:2},1032,["onClick"])]),_:2},1024))),128))]),_:1},8,["cols","x-gap","y-gap"])):(E(),oe(S,{key:3,status:"info",title:"暂无新闻",description:"目前还没有新闻内容"}))]}),_:1})])])}}},br=se(_r,[["__scopeId","data-v-bcb9c008"]]);const we=e=>(ve("data-v-8524e5f3"),e=e(),me(),e),yr={id:"contact",class:"contact-section section-half"},wr={class:"section-container"},xr=we(()=>l("div",{class:"title-underline"},null,-1)),$r={class:"contact-info-section"},zr={class:"contact-info-card modern-glass-card"},Sr=we(()=>l("div",{class:"card-icon-wrapper"},[l("div",{class:"card-icon address-icon"},[l("svg",{viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},[l("path",{d:"M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z",fill:"currentColor"})])])],-1)),kr={class:"card-content"},Cr={class:"card-title"},Rr={class:"card-text"},Pr={class:"contact-info-card modern-glass-card"},Ir=we(()=>l("div",{class:"card-icon-wrapper"},[l("div",{class:"card-icon phone-icon"},[l("svg",{viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},[l("path",{d:"M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z",fill:"currentColor"})])])],-1)),Tr={class:"card-content"},jr={class:"card-title"},Br={class:"card-text"},Nr={class:"contact-info-card modern-glass-card"},Er=we(()=>l("div",{class:"card-icon-wrapper"},[l("div",{class:"card-icon email-icon"},[l("svg",{viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},[l("path",{d:"M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z",fill:"currentColor"})])])],-1)),Mr={class:"card-content"},Or={class:"card-title"},Dr={class:"card-text"},Lr={class:"map-section"},Vr={class:"location-display-container"},Hr=["innerHTML"],Wr={key:0,class:"map-loading"},Ar={key:1,class:"map-error"},qr=we(()=>l("div",{style:{"text-align":"left","max-width":"400px"}},[l("p",null,[l("strong",null,"可能的原因：")]),l("ul",{style:{margin:"8px 0","padding-left":"20px"}},[l("li",null,"百度地图API密钥未配置或无效"),l("li",null,"网络连接问题"),l("li",null,"API密钥权限设置问题")]),l("p",null,[l("strong",null,"解决方法：")]),l("ol",{style:{margin:"8px 0","padding-left":"20px"}},[l("li",null,[k("访问 "),l("a",{href:"https://lbsyun.baidu.com/",target:"_blank",style:{color:"#1890ff"}},"百度地图开放平台"),k(" 申请API密钥")]),l("li",null,[k("在项目根目录的 "),l("code",null,".env.local"),k(" 文件中配置密钥")]),l("li",null,"重启开发服务器")])],-1)),Fr={style:{"font-size":"12px"}},Yr={class:"map-info-overlay"},Xr=we(()=>l("svg",{viewBox:"0 0 24 24"},[l("path",{fill:"currentColor",d:"M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"})],-1)),Ur=we(()=>l("svg",{viewBox:"0 0 24 24"},[l("path",{fill:"currentColor",d:"M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"})],-1)),Kr={class:"address-info"},Gr=we(()=>l("svg",{viewBox:"0 0 24 24"},[l("path",{fill:"currentColor",d:"M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"})],-1)),pt=3,Zr={__name:"ContactSection",setup(e){const{t:n}=he(),i=j(!0),s=j(!1),a=j(null),r=j(null),p=j(!0),c=j(0);j(null);const f=j(!1),h=j('<div id="baidu-map-container" class="map-container"></div>'),d={lng:120.6357,lat:31.1515},x=(g,u=5e3)=>new Promise((w,S)=>{const I=document.querySelector(g);if(I){w(I);return}const T=new MutationObserver(()=>{const B=document.querySelector(g);B&&(T.disconnect(),w(B))});T.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>{T.disconnect(),S(new Error(`DOM元素 ${g} 在 ${u}ms 内未找到`))},u)}),_=()=>new Promise((g,u)=>{if(window.BMap){g(window.BMap);return}const w="8Xf25n2h1lIdYyWt6mBN0oNlCjONQ1vA";console.log("读取到的API密钥:",w,"长度:",w==null?void 0:w.length);const S=document.createElement("script");S.type="text/javascript",S.src=`https://api.map.baidu.com/getscript?v=3.0&ak=${w}&services=&t=${Date.now()}`,S.async=!0,S.onload=()=>{const B=()=>{window.BMap?g(window.BMap):setTimeout(B,100)};B()},S.onerror=()=>{u(new Error("百度地图API网络请求失败"))};const I=setTimeout(()=>{u(new Error("百度地图API加载超时"))},1e4),T=S.onload;S.onload=()=>{clearTimeout(I),T()},document.head.appendChild(S)}),$=(g=0)=>Be(this,null,function*(){var u,w,S,I;if(f.value){console.log("地图正在初始化中，跳过重复请求");return}f.value=!0;try{i.value=!0,s.value=!1;const T="8Xf25n2h1lIdYyWt6mBN0oNlCjONQ1vA";console.log("读取到的API密钥:",T,"长度:",T==null?void 0:T.length),p.value=!0;const B=yield _();yield et(),console.log("等待地图容器DOM元素...");const F=yield x("#baidu-map-container",3e3);console.log("地图容器找到:",F),F.style.height="400px",F.style.minHeight="400px";const te=document.querySelector(".map-wrapper");if(te&&(te.style.height="400px",te.style.minHeight="400px"),a.value)try{a.value.clearOverlays(),F&&F.parentNode&&(F.innerHTML="")}catch(K){console.warn("清理旧地图实例时出错:",K)}a.value=new B.Map(F);const J=new B.Point(d.lng,d.lat);a.value.centerAndZoom(J,16),a.value.enableScrollWheelZoom(!0),a.value.enableDragging(!0),a.value.enableDoubleClickZoom(!0),a.value.addControl(new B.NavigationControl),a.value.addControl(new B.ScaleControl),r.value=new B.Marker(J),a.value.addOverlay(r.value);const X=new B.InfoWindow(`
      <div style="padding: 10px; line-height: 1.5;">
        <h4 style="margin: 0 0 8px 0; color: #1890ff;">${n("company.name")}</h4>
        <p style="margin: 0; color: #666; font-size: 13px;">${n("website.contact.address")}</p>
      </div>
    `,{width:300,height:80});r.value.addEventListener("click",()=>{a.value.openInfoWindow(X,J)}),setTimeout(()=>{a.value.openInfoWindow(X,J)},1e3),i.value=!1,f.value=!1}catch(T){if(console.error(`百度地图初始化失败 (尝试 ${g+1}/${pt}):`,T),T.message.includes("DOM元素")&&g<pt-1){c.value=g+1,console.log(`将在 ${(g+1)*1e3}ms 后重试...`),f.value=!1,setTimeout(()=>{$(g+1)},(g+1)*1e3);return}s.value=!0,i.value=!1,f.value=!1,c.value=0,T.message.includes("API密钥")?(p.value=!1,(u=window.$message)==null||u.warning("请先配置百度地图API密钥")):T.message.includes("DOM元素")?(w=window.$message)==null||w.error("地图容器加载失败，请刷新页面重试"):T.message.includes("超时")?(S=window.$message)==null||S.error("地图API加载超时，请检查网络连接"):(I=window.$message)==null||I.error("地图加载失败，请检查网络连接或API密钥配置")}}),y=()=>{c.value=0,f.value=!1,$()},z=()=>{const g=n("website.contact.address"),u=`https://map.baidu.com/search/${encodeURIComponent(g)}/@13515782.17,3665847.89,19z?querytype=s&da_src=shareurl&wd=${encodeURIComponent(g)}&c=224&src=0&pn=0&sug=0&l=19&b=(13515662,3665727;13515902,3665967)&from=webmap&biz_forward=%7B%22scaler%22:1,%22styles%22:%22pl%22%7D`;window.open(u,"_blank")},C=()=>Be(this,null,function*(){var u,w;const g=n("website.contact.address");try{yield navigator.clipboard.writeText(g),(u=window.$message)==null||u.success(n("website.contact.address_copied"))}catch(S){const I=document.createElement("textarea");I.value=g,document.body.appendChild(I),I.select(),document.execCommand("copy"),document.body.removeChild(I),(w=window.$message)==null||w.success(n("website.contact.address_copied"))}});return ge(()=>{et(()=>{setTimeout(()=>{$()},200)})}),nt(()=>{try{if(f.value=!1,a.value){a.value.removeEventListener("click"),a.value.clearOverlays();const g=document.getElementById("baidu-map-container");if(g&&g.parentNode)try{g.innerHTML=""}catch(u){console.warn("清理地图容器DOM时出错:",u)}a.value=null}r.value&&(r.value=null)}catch(g){console.warn("地图清理时出现错误:",g)}}),(g,u)=>{const w=be,S=ae,I=Ce,T=Re,B=hn,F=Se,te=ot,J=xt,X=_e;return E(),L("section",yr,[l("div",wr,[t(S,{vertical:"",align:"center",size:20,style:{"margin-bottom":"80px"}},{default:o(()=>[t(w,{style:{fontSize:"var(--sipumtech-font-size-h1)",fontWeight:"var(--sipumtech-font-weight-bold)",color:"var(--sipumtech-primary-blue)",lineHeight:"var(--sipumtech-line-height-tight)"}},{default:o(()=>[k(b(g.$t("website.contact.title")),1)]),_:1}),xr,t(w,{style:{fontSize:"18px",color:"var(--sipumtech-text-secondary)",lineHeight:"var(--sipumtech-line-height-relaxed)"}},{default:o(()=>[k(b(g.$t("website.contact.subtitle")),1)]),_:1})]),_:1}),t(S,{vertical:"",size:60},{default:o(()=>[l("div",$r,[t(T,{cols:"1024:3 768:1 480:1","x-gap":24,"y-gap":20,"item-responsive":"",responsive:"screen"},{default:o(()=>[t(I,null,{default:o(()=>[l("div",zr,[Sr,l("div",kr,[l("h3",Cr,b(g.$t("website.contact.address_title")),1),l("p",Rr,b(g.$t("website.contact.address")),1)])])]),_:1}),t(I,null,{default:o(()=>[l("div",Pr,[Ir,l("div",Tr,[l("h3",jr,b(g.$t("website.contact.phone_title")),1),l("p",Br,b(g.$t("website.contact.phone")),1)])])]),_:1}),t(I,null,{default:o(()=>[l("div",Nr,[Er,l("div",Mr,[l("h3",Or,b(g.$t("website.contact.email_title")),1),l("p",Dr,b(g.$t("website.contact.email")),1)])])]),_:1})]),_:1})]),l("div",Lr,[t(X,{key:"map-container-card",class:"map-card map-container-card"},{default:o(()=>[t(S,{key:"map-card-content",vertical:"",size:20},{default:o(()=>[t(w,{style:{fontSize:"18px",fontWeight:"var(--sipumtech-font-weight-semibold)",color:"var(--sipumtech-primary-blue)"}},{default:o(()=>[k(b(g.$t("website.contact.map_title")),1)]),_:1}),l("div",Vr,[Zt(l("div",{innerHTML:h.value,class:"map-wrapper"},null,8,Hr),[[Jt,p.value]]),i.value?(E(),L("div",Wr,[t(B,{size:"large"},{description:o(()=>[k(b(g.$t("website.contact.map_loading_text")),1)]),_:1})])):fe("",!0),s.value?(E(),L("div",Ar,[t(te,{status:"error",title:"地图加载失败"},{description:o(()=>[qr]),footer:o(()=>[t(S,null,{default:o(()=>[t(F,{onClick:y,type:"primary",loading:i.value},bo({default:o(()=>[k(b(g.$t("website.contact.retry_map"))+" ",1)]),_:2},[c.value>0?{name:"icon",fn:o(()=>[l("span",Fr,"("+b(c.value)+"/"+b(pt)+")",1)]),key:"0"}:void 0]),1032,["loading"]),t(F,{onClick:u[0]||(u[0]=()=>g.window.open("https://lbsyun.baidu.com/","_blank")),type:"default"},{default:o(()=>[k(b(g.$t("website.contact.apply_api_key")),1)]),_:1})]),_:1})]),_:1})])):fe("",!0)]),l("div",Yr,[t(X,{bordered:!1,class:"company-info-card"},{default:o(()=>[t(S,{vertical:"",size:12},{default:o(()=>[t(w,{style:{fontSize:"18px",fontWeight:"600",color:"var(--sipumtech-primary-blue)"}},{default:o(()=>[k(b(g.$t("company.name")),1)]),_:1}),t(w,{style:{fontSize:"14px",color:"var(--sipumtech-text-secondary)",lineHeight:"1.5"}},{default:o(()=>[k(b(g.$t("website.contact.address")),1)]),_:1}),t(S,{size:8,class:"contact-action-buttons"},{default:o(()=>[t(F,{type:"primary",size:"tiny",onClick:z,style:{background:"linear-gradient(135deg, var(--sipumtech-accent-green), var(--sipumtech-primary-blue))",border:"none",fontSize:"12px",padding:"4px 8px",height:"28px"}},{icon:o(()=>[t(J,{size:14},{default:o(()=>[Xr]),_:1})]),default:o(()=>[k(" "+b(g.$t("website.contact.view_in_map")),1)]),_:1}),t(F,{size:"tiny",onClick:C,style:{borderColor:"var(--sipumtech-accent-green)",color:"var(--sipumtech-accent-green)",fontSize:"12px",padding:"4px 8px",height:"28px"}},{icon:o(()=>[t(J,{size:14},{default:o(()=>[Ur]),_:1})]),default:o(()=>[k(" "+b(g.$t("website.contact.copy_address")),1)]),_:1})]),_:1})]),_:1})]),_:1})]),l("div",Kr,[t(S,{align:"center",size:12},{default:o(()=>[t(J,{size:20,color:"var(--sipumtech-accent-green)"},{default:o(()=>[Gr]),_:1}),t(w,{style:{fontSize:"var(--sipumtech-font-size-body)",color:"var(--sipumtech-text-primary)",fontWeight:"500"}},{default:o(()=>[k(b(g.$t("website.contact.address")),1)]),_:1})]),_:1})])]),_:1})]),_:1})])]),_:1})])])}}},Jr=se(Zr,[["__scopeId","data-v-8524e5f3"]]);const Qr={class:"home-page"},el={__name:"index",setup(e){const{t:n}=he(),i=j(0),s=j(!1),a=j(!1),r=j(null),p=j(0),c=j(["home","about","business","technology","cases","news","contact"]),f=P(()=>c.value.map((u,w)=>({label:g(u),key:u,props:{onClick:()=>C(u)}}))),h=u=>{C(u),a.value=!1},d=()=>{r.value&&r.value.startHover&&r.value.startHover()},x=()=>{r.value&&r.value.endHover&&r.value.endHover()},_=u=>{console.log("获取方案:",u),C("contact")},$=u=>{console.log("技术咨询:",u),C("contact")},y=()=>{const u=window.pageYOffset||document.documentElement.scrollTop,w=document.documentElement.scrollHeight-window.innerHeight;i.value=u/w*100,s.value=u>300,z()},z=()=>{const u=c.value.map(S=>document.getElementById(S)).filter(Boolean),w=window.pageYOffset+window.innerHeight/2;for(let S=u.length-1;S>=0;S--){const I=u[S];if(I&&I.offsetTop<=w){p.value=S;break}}},C=u=>{const w=document.getElementById(u);if(w){w.scrollIntoView({behavior:"smooth",block:"start"});const S=c.value.indexOf(u);S!==-1&&(p.value=S)}a.value=!1},g=u=>n(`navigation.${u}`)||u;return ge(()=>{window.addEventListener("scroll",y),z()}),nt(()=>{window.removeEventListener("scroll",y)}),j(null),yo({name:"",phone:"",email:"",message:""}),P(()=>({name:{required:!0,message:n("website.form_validation.name_required"),trigger:"blur"},phone:{required:!0,message:n("website.form_validation.phone_required"),trigger:"blur"},email:{required:!0,message:n("website.form_validation.email_required"),trigger:"blur"},message:{required:!0,message:n("website.form_validation.message_required"),trigger:"blur"}})),(u,w)=>{const S=pn,I=Oo,T=Se,B=ae,F=wo,te=So,J=zo,X=Po;return E(),L("div",Qr,[t(I,{top:0,style:{"z-index":"1001"}},{default:o(()=>[t(S,{type:"line",percentage:i.value,"show-indicator":!1,height:4,color:"#1e3a8a",style:{width:"100vw"}},null,8,["percentage"])]),_:1}),t(I,{"trigger-top":100,top:50,position:"fixed",style:{position:"fixed",right:"30px",top:"50%",transform:"translateY(-50%)","z-index":"1000"}},{default:o(()=>[t(B,{vertical:"",size:8},{default:o(()=>[(E(!0),L(ce,null,ue(c.value,(K,re)=>(E(),oe(T,{key:K,circle:"",size:"small",type:p.value===re?"primary":"default",onClick:Ee=>C(K),title:g(K),style:{width:"12px",height:"12px","min-width":"12px"}},null,8,["type","onClick","title"]))),128))]),_:1})]),_:1}),t(J,{show:a.value,"onUpdate:show":w[0]||(w[0]=K=>a.value=K),width:280,placement:"right"},{default:o(()=>[t(te,{title:u.$t("website.ui.navigation_menu"),closable:""},{default:o(()=>[t(F,{value:c.value[p.value],options:f.value,"onUpdate:value":h},null,8,["value","options"])]),_:1},8,["title"])]),_:1},8,["show"]),t(I,{class:"side-nav-trigger","trigger-top":200,top:50,position:"fixed",style:{position:"fixed",right:"30px",bottom:"120px","z-index":"1000"}},{default:o(()=>[t(T,{circle:"",type:"primary",onClick:w[1]||(w[1]=K=>a.value=!0),style:{width:"48px",height:"48px","box-shadow":"0 4px 12px rgba(0, 0, 0, 0.15)"}},{default:o(()=>[k(" ☰ ")]),_:1})]),_:1}),t(As,{ref_key:"heroRef",ref:r,onScrollToSection:C},null,512),t(Gs),t(ni,{onStartHover:d,onEndHover:x,onGetSolution:_,onTechConsultation:$}),t(Wi),t(Ji),t(gr),t(br),t(Jr),t(X,{right:30,bottom:30})])}}},gl=se(el,[["__scopeId","data-v-585e7746"]]);export{gl as default};
